﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Contact.Mgmt.Contracts;
using System.Data.Entity;
using Contact.Mgmt.Models;

namespace Contact.Mgmt.Data
{
    public class DataContext : DbContext, IDataContext
    {
        public DbSet<AppException> AppException { get; set; }

        public DbSet<MstContact> MstContact { get; set; }
    }
}
