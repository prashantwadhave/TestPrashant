﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Web;
using Contact.Mgmt.Contracts;
using Contact.Mgmt.Models;

namespace Contact.Mgmt.Services
{
    public class ExceptionLoggerService : ILogger
    {

        private readonly IUnitOfWork uow;
        private IDataContext dataContext;
        IGenericRepository<AppException> repository;
        public ExceptionLoggerService(IUnitOfWork uow)
        {
            this.uow = uow;
            this.dataContext = uow.DbContext;
            repository = uow.GetRepository<AppException>();
        }

        public IEnumerable<AppException> Get()
        {
            var result = repository.Get();
            return result;
        }
        public IEnumerable<AppException> Get(int records)
        {
            List<AppException> lstExceptionLog = repository.Get().Take(records).ToList();
            return lstExceptionLog;
        }
        public long Log(Exception entity, string uid)
        {
            HttpContext ctxObject = HttpContext.Current;
            string strReqURL = (ctxObject.Request.Url != null) ? ctxObject.Request.Url.ToString() : String.Empty;
            string strUserAgent = (ctxObject.Request.UserAgent != null) ? ctxObject.Request.UserAgent : String.Empty;
            string strUserIP = (ctxObject.Request.UserHostAddress != null) ? ctxObject.Request.UserHostAddress : String.Empty;
            AppException appException = new AppException();
            appException.ErrorMessage = entity.Message;
            appException.StackTrace = entity.StackTrace;
            appException.RequestURL = strReqURL;
            appException.UserIP = strUserIP;
            appException.Created = DateTime.Now;
            repository.Add(appException);
            uow.Commit();
            return appException.Id;
        }

        public long Log(string info, string uid)
        {
            AppException appException = new AppException
            {
                ErrorMessage = info,
                StackTrace = string.Empty,
                RequestURL = string.Empty,
                UserIP = string.Empty,
                Created = DateTime.Now
            };
            repository.Add(appException);
            uow.Commit();
            return appException.Id;
        }

        public long Log(AppException entity)
        {
            HttpContext OHttpContext = HttpContext.Current;
            string strReqURL = (OHttpContext.Request.Url != null) ? OHttpContext.Request.Url.ToString() : String.Empty;
            string strUserAgent = (OHttpContext.Request.UserAgent != null) ? OHttpContext.Request.UserAgent : String.Empty;
            string strUserIP = (OHttpContext.Request.UserHostAddress != null) ? OHttpContext.Request.UserHostAddress : String.Empty;
            AppException appException = new AppException()
            {
                ErrorMessage = entity.ErrorMessage,
                StackTrace = entity.StackTrace,
                RequestURL = entity.RequestURL,
                UserIP = strUserIP,
                Created = DateTime.Now
            };
            repository.Add(appException);
            uow.Commit();
            return appException.Id;
        }
    }
}
