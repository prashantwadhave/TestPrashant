﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contact.Mgmt.Models
{
    public class AppException
    {
        public long Id { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
        public string RequestURL { get; set; }
        public string UserIP { get; set; }
        public DateTime Created { get; set; }
    }
}
