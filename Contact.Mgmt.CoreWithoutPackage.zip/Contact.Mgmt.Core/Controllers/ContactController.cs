﻿using Contact.Mgmt.Contracts;
using Contact.Mgmt.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Contact.Mgmt.Core.Controllers
{
    public class ContactController : ApiController
    {
        private IMstContact _ContactService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public ContactController(IMstContact contactService)
        {
            _ContactService = contactService;
            
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        public HttpResponseMessage GetAllContact()
        {
            IList<MstContact> lstContact = _ContactService.GetAllContacts();
            return Request.CreateResponse(HttpStatusCode.OK, lstContact);
        }
    }
}
