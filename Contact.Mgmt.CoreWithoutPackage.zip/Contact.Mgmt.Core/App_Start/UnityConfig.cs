using Unity.Container;
using Microsoft.Practices.Unity;
using System.Web.Http;
using Unity.WebApi;
using Unity;
using Contact.Mgmt.Contracts;
using Contact.Mgmt.Repositories;
using Contact.Mgmt.Data;
using Contact.Mgmt.Models;
using Unity.Lifetime;
using Contact.Mgmt.Services;

namespace Contact.Mgmt.Core
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            container.RegisterType<IUnitOfWork, UnitOfWork>(new PerResolveLifetimeManager());
            container.RegisterType<IDataContext, DataContext>();
            container.RegisterType<ILogger, Contact.Mgmt.Services.ExceptionLoggerService>();
            container.RegisterType<IMstContact, ContactService>();
           
            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
            //Microsoft.Practices.Unity.Configuration.DependencyElement = new UnityDependencyResolver(container);
        }
    }
}