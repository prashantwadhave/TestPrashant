﻿//using Capita.Core.Models.CustomModels;
//using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constact.Mgmt.Contracts
{
    public interface IContact
    {
        //List<CallsReport> GetCallList(int departmentId, DateTime startDate, DateTime endDate, string lanId);

        //int AddCallActivity(Calls callActivity, int activeNonCoreActivityId, string lanId);

        //int UpdateCallActivity(Calls callActivityJourney, bool isCoreActivtyStarted, bool isWebChatActivityStarted);
    }
}
