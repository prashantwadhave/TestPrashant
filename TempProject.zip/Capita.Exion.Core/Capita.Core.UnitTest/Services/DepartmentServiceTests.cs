﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class DepartmentServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private DepartmentService _DepartmentService = null;

        private Mock<IGenericRepository<MstDepartment>> _MstDepartmentRepository = null;

        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;

        private Mock<IGenericRepository<MappingRoleNavigation>> _MappingRoleNavigationRepository = null;

        private Mock<IGenericRepository<MappingAuxCodeDepartment>> _MappingAuxCodeDepartmentRepository = null;

        private Mock<IUser> _UserService = null;

        IQueryable<MappingUserDepartment> queryMappingUserDepartment = null;

        IQueryable<MstDepartment> queryDepartments = null;

        IQueryable<MappingRoleNavigation> queryMappingRoleNavigation = null;

        [TestInitialize]
        public void Initialize()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment();
            queryDepartments = DataInitializer.GetDepartments();
            queryMappingRoleNavigation = DataInitializer.GetMappingRoleNavigation();
        }

        [TestMethod()]
        public void GetAllDepartmentsTest()
        {

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result = _DepartmentService.GetAllDepartments("capita\\p10359078");

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetDepartmentByIdTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result = _DepartmentService.GetDepartmentById(1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddDepartmentTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _MappingAuxCodeDepartmentRepository = new Mock<IGenericRepository<MappingAuxCodeDepartment>>();
            
            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<MappingAuxCodeDepartment>()).Returns(_MappingAuxCodeDepartmentRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            MstDepartment department = new MstDepartment() { Id = 3, Name="Apps", IsActive = true, CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now };
            UserPrimaryDetails user = new UserPrimaryDetails(){ FirstName = "u4f",LastName = "u4l",LanId = "CAPITA\\P4444",EmployeeId = "4444",DepartmentId = 1,TimeZone = "GMT Standard Time",ManagerId = null,EmailId = "d@d.com",CreatedBy = 1,ModifiedBy = 1,
                                                                CreatedDate = DateTimeHelper.Now,ModifiedDate = DateTimeHelper.Now,IsActive = true};

            var result = _DepartmentService.AddDepartment(department, user);

            Assert.AreEqual(true, result);
        }

        [TestMethod()]
        public void GetAllDepartmentsInAppTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result = _DepartmentService.GetAllDepartmentsInApp().ToList();

            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count);
        }

        [TestMethod()]
        public void CheckDepartmentExistsTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);
            MstDepartment dept = new MstDepartment();
            dept.Id = 1;
            dept.Name = "PCSC";
            MstDepartment dept2 = new MstDepartment();
            dept2.Id = 1;
            dept2.Name = "XXXX";
            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result1 = _DepartmentService.CheckDepartmentExists(dept);
            var result2 = _DepartmentService.CheckDepartmentExists(dept2);

            Assert.AreEqual(true, result1);//same dept name PCSC belongs to other dept already
            Assert.AreEqual(false, result2);//XXXX dept name does not exist
        }

        [TestMethod()]
        public void CheckDepartmentExists1Test()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result = _DepartmentService.CheckDepartmentExists("PCSC");

            Assert.AreEqual(true, result);//same dept name PCSC exists already
        }

        [TestMethod()]
        public void UpdateDepartmentTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            MstDepartment dept1 = new MstDepartment();
            dept1.Id = 1;
            dept1.Name = "SBSS1";
            dept1.IsActive = false;
            MstDepartment dept2 = new MstDepartment();
            dept2.Id = 10;
            dept1.Name = "PCSC1";
            dept2.IsActive = true;

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result1 = _DepartmentService.UpdateDepartment(dept1, new UserPrimaryDetails() { Id = 1 });
            var result2 = _DepartmentService.UpdateDepartment(dept2, new UserPrimaryDetails() { Id = 1 });

            Assert.AreEqual(true, result1);
            Assert.AreEqual(false, result2);
        }

        [TestMethod()]
        public void DeleteDepartmentByIdTest()
        {
            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _DepartmentService = new DepartmentService(uow.Object, _UserService.Object);

            var result1 = _DepartmentService.DeleteDepartmentById(1, new UserPrimaryDetails() { Id = 1 });
            var result2 = _DepartmentService.DeleteDepartmentById(10, new UserPrimaryDetails() { Id = 1 });

            Assert.AreEqual(true, result1);
            Assert.AreEqual(false, result2);
        }
    }
}