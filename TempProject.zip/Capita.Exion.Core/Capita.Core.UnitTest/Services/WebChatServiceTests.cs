﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class WebChatServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private Mock<IUser> _UserService = null;

        private Mock<ICoreActivity> _CoreActivityService = null;

        private WebChatService _WebChatService = null;

        private Mock<IGenericRepository<CoreActivityJourney>> _CoreActivityJourneyRepository = null;

        private Mock<IGenericRepository<NonCoreActivityJourney>> _NonCoreActivityJourneyRepository = null;

        NonCoreActivityJourney queryNonCoreActivityJourney = null;

        public int TeamId = 1;

        [TestInitialize]
        public void Initialize()
        {
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivity();
        }

        [TestMethod()]
        public void AddWebChatActivityValidConditionTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.WebChat, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.AddWebChatActivity(1, string.Empty, 1, "capita\\p10359078", TeamId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddWebChatActivityInValidConditionTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.WebChat, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(3)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.AddWebChatActivity(1, string.Empty, 1, "capita\\p10359078", TeamId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateWebChatActivityWhenExistingCoreActivityIsNullTest()
        {
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };

           
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            
            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(2)).Returns(existingCoreActivity);

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.UpdateWebChatActivity(1, string.Empty, false, false, false);

            Assert.AreEqual(0,result);
        }

        [TestMethod()]
        public void UpdateWebChatActivityWhenCore_CallAndOutBoundNotStartedTest()
        {
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };

            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.UpdateWebChatActivity(1, string.Empty, false, false, false);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateWebChatActivityWhenCore_OutBoundNotStartedAndCallStartedTest()
        {
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };

            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.UpdateWebChatActivity(1, string.Empty,false, true, false);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateWebChatActivityWhenCore_CallNotStartedAndOutBoundStartedTest()
        {
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };

            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.OutbondCall, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.UpdateWebChatActivity(1, string.Empty, false, false, true);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateWebChatActivityWhenCall_OutBoundNotStartedAndCoreStartedTest()
        {
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };

            int userId = 2;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.CoreActivity, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.UpdateWebChatActivity(1, string.Empty, true, false,  false);

            Assert.IsNotNull(result);
        }



        [TestMethod()]
        public void AddWebChatForValidTeamId()
        {
            int userId = 67;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\P10355915")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.OutbondCall, TeamId));


            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(5)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.AddWebChatActivity(1, string.Empty, 1, "capita\\P10355915", TeamId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddWebChatInValidTeamTest()
        {
            int userId = 67;
            TeamId = 0;
            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\P10355915")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.OutbondCall, TeamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(5)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _WebChatService = new WebChatService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _WebChatService.AddWebChatActivity(1, string.Empty, 1, "capita\\P10355915", TeamId);

            Assert.IsNotNull(result);
        }
    }
}