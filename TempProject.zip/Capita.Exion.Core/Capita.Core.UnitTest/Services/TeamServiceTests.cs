﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using Capita.Core.Services.Services;
using Capita.Core.UnitTest.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.UnitTest
{
    [TestClass()]
    public class TeamServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private TeamService _TeamService = null;

        private Mock<IGenericRepository<MstTeam>> _MstTeamRepository = null;
        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;
        IQueryable<MappingUserDepartment> queryMappingUserDepartment = null;

        private Mock<IUser> _UserService = null;
        public int departmentId = 1;
        public int TeamId = 1;
        int userId = 6;

        IQueryable<MstTeam> teamList = null;

        [TestInitialize]
        public void Initialize()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\P10322047")).Returns(userId);
            queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment();
            teamList = DataInitializer.GetTeamList();

        }
        [TestMethod()]
        public void GetAllTeamsByDepartmentTest()
        {            

            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);
            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.GetAllTeamsByDepartment(departmentId);

            Assert.IsNotNull(result);
        }
        [TestMethod()]
        public void GetTeamByIdTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
           

            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.GetTeamById(TeamId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateTeamTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);
            var team = teamList.FirstOrDefault();
            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.UpdateTeam(team, userId.ToString());

            Assert.IsNotNull(result);
        }
        [TestMethod()]
        public void GetAllTeamsByUserIdTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.GetAllTeamsByUserId(userId, departmentId);

            Assert.IsNotNull(result);
        }
        [TestMethod()]
        public void CheckTeamExistsTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.CheckTeamExists("Team A", departmentId);

            Assert.IsNotNull(result);
        }
        [TestMethod()]
        public void CheckTeamExistsTestForModel()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);

            
            var team = teamList.FirstOrDefault();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
           


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.CheckTeamExists(team);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddTeamTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);
                       
            var team = teamList.FirstOrDefault();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);
            
            uow.Setup(m => m.Commit()).Returns(true);


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.AddTeam(team,userId.ToString());

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void DeleteTeamByIdTest()
        {
            _MstTeamRepository = new Mock<IGenericRepository<MstTeam>>();
            _MstTeamRepository.Setup(m => m.Get()).Returns(teamList);

            var team = teamList.FirstOrDefault();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstTeam>()).Returns(_MstTeamRepository.Object);

            uow.Setup(m => m.Commit()).Returns(true);


            _TeamService = new TeamService(uow.Object, _UserService.Object);

            var result = _TeamService.DeleteTeamById(1,userId.ToString());

            Assert.IsNotNull(result);
        }
        
    }
}
