﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using Moq;
using Capita.Core.Models;
using System.Globalization;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models.CustomModels;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class DashboardServiceTests
    {
        private Mock<IUnitOfWork> uow;
        private Mock<IGenericRepository<RealTimeDashboard>> _RealTimeDashboardRepository = null;
        private Mock<IGenericRepository<CoreNonCoreTime>> _CoreNonCoreTimeRepository = null;
        private Mock<IGenericRepository<EmployeesCoreNonCoreData>> _EmployeesCoreNonCoreDataRepository = null;
        private Mock<IGenericRepository<UserCurrentStatistics>> _UserCurrentStatisticsRepository = null;
        private DashboardService _DashboardService = null;
        public int TeamId = 1;

        [TestMethod()]
        public void GetRealTimeDashboardTest()
        {
            string spName = "spRealTimeDashboard";
            int userId = 1;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);

            List<RealTimeDashboard> LstRealTimeDashboard = DataInitializer.GetRealTimeDashboard(startDate, endDate);

            _RealTimeDashboardRepository = new Mock<IGenericRepository<RealTimeDashboard>>();
            _RealTimeDashboardRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstRealTimeDashboard);
            _RealTimeDashboardRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.AddDays(-1).ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.AddDays(-1).ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(new List<RealTimeDashboard>());

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<RealTimeDashboard>()).Returns(_RealTimeDashboardRepository.Object);

            _DashboardService = new DashboardService(uow.Object);

            var result1 = _DashboardService.GetRealTimeDashboard(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);
            var result2 = _DashboardService.GetRealTimeDashboard(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate.AddDays(-1), DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate.AddDays(-1), DateTimeKind.Unspecified), TeamId);

            // Assert           
            Assert.AreEqual(1, result1.Count);
            Assert.AreEqual(0, result2.Count);
        }

        [TestMethod()]
        public void GetCoreNonCoreTimeTest()
        {
            string spName = "spGetCoreNonCoreTime";
            int userId = 1;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);

            List<CoreNonCoreTime> LstCoreNonCoreTime_user1 = DataInitializer.GetLstCoreNonCoreTime_user1();
            List<CoreNonCoreTime> LstCoreNonCoreTime_allUser = DataInitializer.GetLstCoreNonCoreTime_allUser();

            _CoreNonCoreTimeRepository = new Mock<IGenericRepository<CoreNonCoreTime>>();
            _CoreNonCoreTimeRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstCoreNonCoreTime_user1);
            _CoreNonCoreTimeRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == 0.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstCoreNonCoreTime_allUser);//if userid = 0, then we get data for all users in the department

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreNonCoreTime>()).Returns(_CoreNonCoreTimeRepository.Object);

            _DashboardService = new DashboardService(uow.Object);

            var result1 = _DashboardService.GetCoreNonCoreTime(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified),TeamId);
            var result2 = _DashboardService.GetCoreNonCoreTime(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);

            Assert.AreEqual(4, result1.Count);
            Assert.AreEqual(5, result2.Count);
        }

        [TestMethod()]
        public void GetEmployeesCoreNonCoreDataTest()
        {
            string spName = "spGetEmployeesCoreNonCoreData";
            int userId = 1;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);

            List<EmployeesCoreNonCoreData> LstEmployeesCoreNonCoreData_user1 = DataInitializer.GetLstEmployeesCoreNonCoreData_user1();
            List<EmployeesCoreNonCoreData> LstEmployeesCoreNonCoreData_allUser = DataInitializer.GetLstEmployeesCoreNonCoreData_allUser();

            _EmployeesCoreNonCoreDataRepository = new Mock<IGenericRepository<EmployeesCoreNonCoreData>>();
            _EmployeesCoreNonCoreDataRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstEmployeesCoreNonCoreData_user1);
            _EmployeesCoreNonCoreDataRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == 0.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstEmployeesCoreNonCoreData_allUser);//if userid = 0, then we get data for all users in the department

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<EmployeesCoreNonCoreData>()).Returns(_EmployeesCoreNonCoreDataRepository.Object);

            _DashboardService = new DashboardService(uow.Object);

            var result1 = _DashboardService.GetEmployeesCoreNonCoreData(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);
            var result2 = _DashboardService.GetEmployeesCoreNonCoreData(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);

            Assert.AreEqual(1, result1.Count);
            Assert.AreEqual(userId, result1.FirstOrDefault().UserId);
            Assert.AreEqual(2, result2.Count);
        }

        [TestMethod()]
        public void GetUserCurrentStatisticTest()
        {
            string spName = "spGetUserCurrentStatistics";
            int userId = 1;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);

            List<UserCurrentStatistics> LstUserCurrentStatistics_user1 = DataInitializer.GetLstUserCurrentStatistics_user1();
            List<UserCurrentStatistics> LstUserCurrentStatistics_allUser = DataInitializer.GetLstUserCurrentStatistics_allUser();

            _UserCurrentStatisticsRepository = new Mock<IGenericRepository<UserCurrentStatistics>>();
            _UserCurrentStatisticsRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstUserCurrentStatistics_user1);
            _UserCurrentStatisticsRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == 0.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstUserCurrentStatistics_allUser);//if userid = 0, then we get data for all users in the department

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserCurrentStatistics>()).Returns(_UserCurrentStatisticsRepository.Object);

            _DashboardService = new DashboardService(uow.Object);

            var result1 = _DashboardService.GetUserCurrentStatistic(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);
            var result2 = _DashboardService.GetUserCurrentStatistic(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), TeamId);

            Assert.AreEqual(1, result1.Count);
            Assert.AreEqual(true, result1.Where(x => x.ActivityType.ToLower().Trim() != "none".Trim()).Any());
            Assert.AreEqual(4, result2.Count);
            Assert.AreEqual(true, result2.Where(x => x.ActivityType.ToLower().Trim() != "none".Trim()).Any());

        }

        [TestMethod()]
        public void GetRealTimeDashboardLMTest()
        {
            string spName = "spRealTimeDashboard";
            int userId = 1;
            int departmentId = 1;
            int totalCount = 0;
            int totalCount2 = 0;
            int totalCount3 = 0;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);

            List<RealTimeDashboard> LstRealTimeDashboard_user1 = DataInitializer.GetLstRealTimeDashboard_user1(startDate);
            List<RealTimeDashboard> LstRealTimeDashboard_allUser = DataInitializer.GetLstRealTimeDashboard_allUser(startDate);

            _RealTimeDashboardRepository = new Mock<IGenericRepository<RealTimeDashboard>>();
            _RealTimeDashboardRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == userId.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstRealTimeDashboard_user1);
            _RealTimeDashboardRepository.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                            It.Is<List<spParameter>>
                                                                (x =>
                                                                     x[0].Name == "@UserId" && x[0].Value == 0.ToString() &&
                                                                     x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                     x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                     x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                                )
                                                            )).Returns(LstRealTimeDashboard_allUser);//if userid = 0, then we get data for all users in the department

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<RealTimeDashboard>()).Returns(_RealTimeDashboardRepository.Object);

            _DashboardService = new DashboardService(uow.Object);

            var result1 = _DashboardService.GetRealTimeDashboardLM(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 0, 5, "", TeamId, out totalCount);//get first page data
            var result2 = _DashboardService.GetRealTimeDashboardLM(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 5, 5, "", TeamId, out totalCount);//get second page data
            var result3 = _DashboardService.GetRealTimeDashboardLM(userId, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 10, 5, "", TeamId, out totalCount);//get third page data

            var result4 = _DashboardService.GetRealTimeDashboardLM(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 0, 5, "", TeamId, out totalCount2);//get second page data
            var result5 = _DashboardService.GetRealTimeDashboardLM(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 5, 5, "", TeamId, out totalCount2);//get second page data
            var result6 = _DashboardService.GetRealTimeDashboardLM(0, departmentId, "GMT Standard Time", DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), 0, 5, "u2f", TeamId, out totalCount3);//get second page data

            Assert.AreEqual(5, result1.Count);//page size is 5, so we should get first five records
            Assert.AreEqual(6, totalCount); //total 6 records
            Assert.AreEqual(1, result2.Count);//page 2 should have only 1 record
            Assert.AreEqual(0, result3.Count);//page 2 should have only 1 record

            Assert.AreEqual(5, result4.Count);
            Assert.AreEqual(7, totalCount2); //total 7 records
            Assert.AreEqual(2, result5.Count);//page 2 should have 2 records
            Assert.AreEqual(1, result6.Count);//for user 'u2f u2l' only 1 recod is there
            Assert.AreEqual(1, totalCount3); //total 1 records for user 'u2f u2l'
        }
    }
}
