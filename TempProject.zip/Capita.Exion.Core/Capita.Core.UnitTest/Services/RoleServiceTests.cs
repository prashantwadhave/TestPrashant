﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class RoleServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private RoleService _RoleService = null;

        private Mock<IGenericRepository<MstRole>> _MstRoleRepository = null;

        private Mock<IGenericRepository<MappingRoleNavigation>> _MappingRoleNavigationRepository = null;

        IQueryable<MstRole> queryRoles = null;

        IQueryable<MappingRoleNavigation> queryMappingRoleNavigation = null;

        [TestInitialize]
        public void Initialize()
        {
            queryRoles = DataInitializer.GetRoles();
            queryMappingRoleNavigation = DataInitializer.GetMappingRoleNavigation();
        }

        [TestMethod()]
        public void GetAllRolesTest()
        {
            _MstRoleRepository = new Mock<IGenericRepository<MstRole>>();
            _MstRoleRepository.Setup(m => m.Get()).Returns(queryRoles);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstRole>()).Returns(_MstRoleRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);

            _RoleService = new RoleService(uow.Object);

            var result = _RoleService.GetAllRoles(1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetRoleByIdTest()
        {
            _MstRoleRepository = new Mock<IGenericRepository<MstRole>>();
            _MstRoleRepository.Setup(m => m.Get()).Returns(queryRoles);
            
            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstRole>()).Returns(_MstRoleRepository.Object);
            
            _RoleService = new RoleService(uow.Object);

            var result = _RoleService.GetRoleById(1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetRoleByIdNullTest()
        {
            _MstRoleRepository = new Mock<IGenericRepository<MstRole>>();
            _MstRoleRepository.Setup(m => m.Get()).Returns(queryRoles);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstRole>()).Returns(_MstRoleRepository.Object);

            _RoleService = new RoleService(uow.Object);

            var result = _RoleService.GetRoleById(5);

            Assert.IsNull(result);
        }
    }
}