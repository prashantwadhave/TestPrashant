﻿using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using Capita.Core.Services.Services;
using Capita.Core.UnitTest.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.UnitTest.Services
{
    [TestClass()]
    public class UserDepartmentServiceTest
    {
        private Mock<IUnitOfWork> uow;


        private Mock<IUser> _UserService = null;
        private UserDepartmentService _userDepartmentService;
        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;
        private Mock<IGenericRepository<DisplayUserDepartmentRole>> _DisplayUserDepartmentRoleRepos = null;
        //private Mock<IGenericRepository<MstRole>> _RoleRepository = null;
        //private Mock<IGenericRepository<MstDepartment>> _MstDepartmentRepository = null;
       // private Mock<IGenericRepository<MstTeam>> _TeamRepository = null;
       // private Mock<IGenericRepository<UserPrimaryDetails>> _UserRepository = null;

        IQueryable<MappingUserDepartment> queryMappingUserDepartment = null;

        IQueryable<DisplayUserDepartmentRole> displayUserDepartmentRole = null;

        IQueryable<MappingRoleNavigation> queryMappingRoleNavigation = null;


        [TestInitialize]
        public void Initialize()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment();
            displayUserDepartmentRole = DataInitializer.DisplayUserDepartmentRole();
            queryMappingRoleNavigation = DataInitializer.GetMappingRoleNavigation();

        }

        [TestMethod()]
        public void GetAllMappingUserDepartmentTest()
        {

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            uow = new Mock<IUnitOfWork>();            
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _userDepartmentService = new UserDepartmentService(uow.Object, _UserService.Object);

            var result = _userDepartmentService.GetAllMappingUserDepartment();

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetUserDepartmentRolesByUserIdTest()
        {
            string spName = "GetUserDepartmentRoles";
           
            int departmentId = 1, userid=6; 

            _DisplayUserDepartmentRoleRepos = new Mock<IGenericRepository<DisplayUserDepartmentRole>>();
            //loginLogoutReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(loginLogoutlst.ToList());
            _DisplayUserDepartmentRoleRepos.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@UserId" && x[0].Value == userid.ToString() &&
                                                                    x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString()                                                                     
                                                               )
                                                           )).Returns(displayUserDepartmentRole.ToList());

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);


            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<DisplayUserDepartmentRole>()).Returns(_DisplayUserDepartmentRoleRepos.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _UserService = new Mock<IUser>();

            _userDepartmentService = new UserDepartmentService( uow.Object, _UserService.Object);

            var result = _userDepartmentService.GetUserDepartmentRolesByUserId(userid, departmentId);

            Assert.IsNotNull(result);

        }

        [TestMethod()]
        public void GetUserDepartmentRolesByUserIdForAdminTest()
        {
            string spName = "GetUserDepartmentRolesForAdmin";

            int userid = 6;

            _DisplayUserDepartmentRoleRepos = new Mock<IGenericRepository<DisplayUserDepartmentRole>>();
            //loginLogoutReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(loginLogoutlst.ToList());
            _DisplayUserDepartmentRoleRepos.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@UserId" && x[0].Value == userid.ToString() 
                                                                    
                                                               )
                                                           )).Returns(displayUserDepartmentRole.ToList());

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);


            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<DisplayUserDepartmentRole>()).Returns(_DisplayUserDepartmentRoleRepos.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _UserService = new Mock<IUser>();

            _userDepartmentService = new UserDepartmentService(uow.Object, _UserService.Object);

            var result = _userDepartmentService.GetUserDepartmentRolesByUserIdForAdmin(userid);

            Assert.IsNotNull(result);

        }

        [TestMethod()]
        public void AddMappingUserDepartmentTest()
        {

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _userDepartmentService = new UserDepartmentService(uow.Object, _UserService.Object);

            var result = _userDepartmentService.GetAllMappingUserDepartment();

            Assert.IsNotNull(result);
        }
    }
}
