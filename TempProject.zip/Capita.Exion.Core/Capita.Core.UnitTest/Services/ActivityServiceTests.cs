﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using Capita.Core.Services.Services;
using Capita.Core.UnitTest.Helper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Linq;

namespace Capita.Core.UnitTest.Services
{
    [TestClass()]
    public class ActivityServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private ActivityService activityService = null;

        private Mock<IGenericRepository<MstActivity>> mstActivityRepository = null;
        private Mock<IGenericRepository<MstActivityGroup>> mstActivityGroupRepository = null;


        IQueryable<MstActivity> lstActivity = null;
        IQueryable<MstActivityGroup> lstActivityGroup = null;


        [TestInitialize]
        public void Initialize()
        {
            lstActivity = DataInitializer.GetmstActivities();
            lstActivityGroup = DataInitializer.GetActivityGroup();

        }

      
        public void GetAllActivityes()
        {
            int departmentId = 1;

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.GetAllActivities(departmentId);

            Assert.IsNotNull(result);
        }
        [TestMethod()]
        public void GetActivityGroups()
        {

            mstActivityGroupRepository = new Mock<IGenericRepository<MstActivityGroup>>();
            mstActivityGroupRepository.Setup(m => m.Get()).Returns(lstActivityGroup);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivityGroup>()).Returns(mstActivityGroupRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.GetActivityGroups();

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetActivityById()
        {
            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.GetActivityById(1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetActivity()
        {
            int departmentId = 1;

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.GetActivity(departmentId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void CheckActivityExists()
        {
            string ActivityName = "VB";

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.CheckActivityExists(ActivityName);

            Assert.IsTrue(result);
        }

        [TestMethod()]
        public void CheckActivityExistsByObject()
        {
            MstActivity activity = new MstActivity()
            { Id = 7,
                DepartmnetId = 1,
                ParentId = 3,
                ActivityName = "BANKDEC",
                ActivityGroup = "Task",
                STT = 60,
                CreatedBy = 1,
                ModifiedBy = 1,
                IsActive = true,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now };


            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.CheckActivityExists(activity);

            Assert.IsTrue(result);
        }

        [TestMethod()]
        public void GetMaxId()
        {
            
            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);

            var result = activityService.GetMaxId();

            Assert.AreNotEqual(0,result);
        }

        [TestMethod()]
        public void AddActivity()
        {
            MstActivity activity = new MstActivity()
            {              
                DepartmnetId = 1,
                ParentId = 3,
                ActivityName = "BANKDEC",
                ActivityGroup = "Task",
                STT = 60,                
                IsActive = true                
            };
            UserPrimaryDetails user = new UserPrimaryDetails()
            {
                Id=6,
                FirstName = "u4f",
                LastName = "u4l",
                LanId = "CAPITA\\P4444",
                EmployeeId = "4444",
                DepartmentId = 1,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "d@d.com",
                CreatedBy = 1,
                ModifiedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            activityService = new ActivityService(uow.Object);

            var result = activityService.AddActivity(activity, user);

            Assert.IsTrue(result);
        }

        [TestMethod()]
        public void DeleteActivityById()
        {
            int id = 1;
            UserPrimaryDetails user = new UserPrimaryDetails()
            {
                Id = 6,
                FirstName = "Dhananjay",
                LastName = "Hole",
                LanId = "CAPITA\\P10322047",
                EmployeeId = "10322047",
                DepartmentId = 1,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "d@d.com",
                CreatedBy = 1,
                ModifiedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);

            activityService = new ActivityService(uow.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            var result = activityService.DeleteActivityById(id, user);

            Assert.IsTrue(result);
        }

        [TestMethod()]
        public void UpdateActivity()
        {
            MstActivity activity = new MstActivity()
            {
                Id=3,
                DepartmnetId = 1,
                ParentId = 3,
                ActivityName = "BANKDEC",
                ActivityGroup = "Task",
                STT = 60,
                IsActive = true
            };
            UserPrimaryDetails user = new UserPrimaryDetails()
            {
                Id = 6,
                FirstName = "Dhananjay",
                LastName = "Hole",
                LanId = "CAPITA\\P10322047",
                EmployeeId = "10322047",
                DepartmentId = 1,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "d@d.com",
                CreatedBy = 1,
                ModifiedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };

            mstActivityRepository = new Mock<IGenericRepository<MstActivity>>();
            mstActivityRepository.Setup(m => m.Get()).Returns(lstActivity);

            uow = new Mock<IUnitOfWork>();

            uow.Setup(m => m.GetRepository<MstActivity>()).Returns(mstActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            activityService = new ActivityService(uow.Object);

            var result = activityService.UpdateActivity(activity, user);

            Assert.IsTrue(result);
        }       

    }
}
