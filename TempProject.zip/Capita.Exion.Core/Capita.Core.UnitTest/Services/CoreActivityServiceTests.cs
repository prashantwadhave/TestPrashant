﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;

namespace Capita.Core.Services.Services.Tests
{

    [TestClass()]
    public class CoreActivityServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private Mock<IUser> _UserService = null;

        private CoreActivityService _CoreActivityService = null;

        private Mock<IGenericRepository<CoreActivityJourney>> _CARepository = null;

        private Mock<IGenericRepository<NonCoreActivityJourney>> _NCARepository = null;

        //private Mock<IGenericRepository<UserPrimaryDetails>> _UserRepository = null;

        NonCoreActivityJourney queryNonCoreActivityJourney = null;
        private int teamId = 1;

        [TestInitialize]
        public void Initialize()
        {
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivity();
        }

        [TestMethod()]
        public void AddCoreActivityValidTest()
        {
            int userId = 2;
            CoreActivityJourney coreActivity = new CoreActivityJourney() { Id = 1, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty };

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, teamId));

            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.AddCoreActivity(coreActivity, 1, "capita\\p10359078");

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddCoreActivityInValidTest()
        {
            int userId = 2;
            CoreActivityJourney coreActivity = new CoreActivityJourney() { Id = 1, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty };

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, teamId));

            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.AddCoreActivity(coreActivity, 2, "capita\\p10359078");

            Assert.AreEqual(1, result);
        }

        [TestMethod()]
        public void UpdateCoreActivityWhenCoreIsNullTest()
        {
            int userId = 2;
            IQueryable<CoreActivityJourney> coreActivity = new List<CoreActivityJourney>()
            { new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty } }.AsQueryable();

            CoreActivityJourney coreActivityJourney = new CoreActivityJourney() { Id = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2 = string.Empty };

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, teamId));

            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CARepository.Setup(m => m.Get()).Returns(coreActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.UpdateCoreActivity(coreActivityJourney);

            Assert.AreEqual(0, result);
        }

        [TestMethod()]
        public void UpdateCoreActivityWhenCommitReturnsFalse()
        {
            int userId = 2;
            IQueryable<CoreActivityJourney> coreActivity = new List<CoreActivityJourney>()
            { new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty } }.AsQueryable();

            CoreActivityJourney coreActivityJourney = new CoreActivityJourney() { Id = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2 = string.Empty };

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, teamId));

            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CARepository.Setup(m => m.Get()).Returns(coreActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(false);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.UpdateCoreActivity(coreActivityJourney);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetCurrentActivityTest()
        {
            IQueryable<CoreActivityJourney> coreActivity = new List<CoreActivityJourney>()
            {
                new CoreActivityJourney() { ActivityType="Core", Id = 1, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty },
                new CoreActivityJourney() { ActivityType="OutbondCall", Id = 2, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty }
            }.AsQueryable();
            
            _UserService = new Mock<IUser>();
            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CARepository.Setup(m => m.Get()).Returns(coreActivity);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.GetCurrentActivity(2,1,"Core");

            Assert.IsNotNull(result);

        }

        [TestMethod()]
        public void GetCurrentActivityIsNullTest()
        {
            IQueryable<CoreActivityJourney> coreActivity = new List<CoreActivityJourney>()
            {
                new CoreActivityJourney() { ActivityType="Core", Id = 1, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty },
                new CoreActivityJourney() { ActivityType="OutbondCall", Id = 2, UserId = 2, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty, Param2= string.Empty }
            }.AsQueryable();

            _UserService = new Mock<IUser>();
            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CARepository.Setup(m => m.Get()).Returns(coreActivity);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.GetCurrentActivity(2, 1, "Call");

            Assert.IsNull(result);

        }


        [TestMethod()]
        public void AddCoreActivityValidTeamTest()
        {
            int userId = 2;
            CoreActivityJourney coreActivity = new CoreActivityJourney() { Id = 1, DepartmentId = 1, Duration = 0, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Param1 = string.Empty, Remarks = string.Empty , TeamId=3};

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\P10355915")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, string.Empty, teamId));

            _CARepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CARepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CoreActivityService = new CoreActivityService(_UserService.Object, uow.Object);

            var result = _CoreActivityService.AddCoreActivity(coreActivity, 1, "capita\\P10355915");

            Assert.IsNotNull(result);
        }
    }
}