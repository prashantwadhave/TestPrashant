﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models;
using System.Data;

namespace Capita.Core.UnitTest.Services
{
    [TestClass()]
    public class ReportServiceTets
    {
        private Mock<IUnitOfWork> uow;
        private ReportService reportService = null;
        private Mock<IUser> _UserService = null;
        private Mock<IGenericRepository<LoginLogoutReport>> loginLogoutReport = null;
        private Mock<IGenericRepository<ProductivityReport>> productivityReport = null;
        private Mock<IGenericRepository<UserPrimaryDetails>> UserRepository = null;
        private Mock<IGenericRepository<TaskAverageReport>> taskAverageReport = null;
        private Mock<IGenericRepository<CoreActivityJourney>> coreActivityJourneyRepos = null;
        private Mock<IGenericRepository<STTReport>> sttreportRepos = null;
        private Mock<IGenericRepository<TaskTotals>> taskTotalsRespos = null;

        private IQueryable<LoginLogoutReport> loginLogoutlst = null;
        private IQueryable<UserPrimaryDetails> userList = null;
        private IQueryable<ProductivityReport> ProductivityReportlst = null;
        private IQueryable<TaskAverageReport> taskAverageReportlst = null;
        private IQueryable<CoreActivity> coreActivitieslstForSBSS = null;
        private IQueryable<CoreActivityJourney> coreActivityJourneylst = null;
        private IQueryable<STTReport> sttReportlst = null;
        private IQueryable<TaskTotals> taskTotallst = null;

        [TestInitialize]
        public void Initialize()
        {
            loginLogoutlst = DataInitializer.GetLoginLoguttList();
            ProductivityReportlst = DataInitializer.GetProductivityReportList();
            userList = DataInitializer.GetUserPrimaryDetailsForReport().AsQueryable();
            taskAverageReportlst = DataInitializer.GettaskAverageReportList();
            coreActivitieslstForSBSS = DataInitializer.coreActivitiesForSBSSList();
            coreActivityJourneylst = DataInitializer.coreActivitiesList();
            sttReportlst = DataInitializer.GetSttReportList();
            taskTotallst = DataInitializer.GetTaskTotalReportList();

        }

        [TestMethod()]
        public void GetLoginLogoutReportTest()
        {
            string spName = "SpGetLoginLogoutReport";
            string lanId = "CAPITA\\P10322047";
            int userId = 1;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);


            loginLogoutReport = new Mock<IGenericRepository<LoginLogoutReport>>();
            //loginLogoutReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(loginLogoutlst.ToList());
            loginLogoutReport.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@DepartmentId" && x[0].Value == departmentId.ToString() &&
                                                                    x[1].Name == "@StartDate" && x[1].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                    x[2].Name == "@EndDate" && x[2].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                               )
                                                           )).Returns(loginLogoutlst.ToList());

            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<LoginLogoutReport>()).Returns(loginLogoutReport.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);

            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            var result = reportService.GetLoginLogoutReport(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), lanId, userId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetProductivityTest()
        {

            string spName = "GetProductivityReport";
            string lanId = "CAPITA\\P10322047";
            string userId = string.Empty;
            int departmentId = 1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);


            productivityReport = new Mock<IGenericRepository<ProductivityReport>>();
            //productivityReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(ProductivityReportlst.ToList());
            productivityReport.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@EmployeeId" && x[0].Value == userId.ToString() &&
                                                                    x[1].Name == "@DepartmentId" && x[1].Value == departmentId.ToString() &&
                                                                    x[2].Name == "@StartDate" && x[2].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                    x[3].Name == "@EndDate" && x[3].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                               )
                                                           )).Returns(ProductivityReportlst.ToList());

            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<ProductivityReport>()).Returns(productivityReport.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);

            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            var result = reportService.GetProductivity(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), lanId, "0",1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetTaskAverageTest()
        {
            int teamId = 1;
            string spName = "SpGetAverageTaskReport";
            string lanId = "CAPITA\\P10322047";
            string userId = string.Empty;
            int departmentId = 1;
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate = Convert.ToDateTime("2018-03-06 06:50:55.807");
            DateTime endDate= Convert.ToDateTime("2018-03-12 06:53:56.460");

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified).AddDays(-3), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);


            taskAverageReport = new Mock<IGenericRepository<TaskAverageReport>>();
            taskTotalsRespos = new Mock<IGenericRepository<TaskTotals>>();

            //productivityReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(ProductivityReportlst.ToList());
            taskAverageReport.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@DepartmentId" && x[0].Value == departmentId.ToString() &&
                                                                    x[1].Name == "@StartDate" && x[1].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                    x[2].Name == "@EndDate" && x[2].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                    x[3].Name== "@TeamId" && x[3].Value == teamId.ToString()
                                                               )
                                                           )).Returns(taskAverageReportlst.ToList());


            taskTotalsRespos.Setup(m => m.GetSP(It.Is<string>(x => x == "SpGetAverageTaskReportTotals"),
                                                          It.Is<List<spParameter>>
                                                              (x =>
                                                                   x[0].Name == "@DepartmentId" && x[0].Value == departmentId.ToString() &&
                                                                   x[1].Name == "@StartDate" && x[1].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                   x[2].Name == "@EndDate" && x[2].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                   x[3].Name == "@Scheme" && x[3].Value == "C2L" &&
                                                                   x[4].Name == "@TeamId" && x[4].Value == teamId.ToString()
                                                              )
                                                          )).Returns(taskTotallst.ToList());

            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<TaskAverageReport>()).Returns(taskAverageReport.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);
            uow.Setup(m => m.GetRepository<TaskTotals>()).Returns(taskTotalsRespos.Object);


            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            DataSet result = reportService.GetTaskAverage(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), lanId, "VB",1);

            Assert.IsNotNull(result);

        }

        [TestMethod()]
        public void GetCoreActivitiesForSBSSTest()
        {


            string lanId = "CAPITA\\P10322047";
            int userId = 6;
            int departmentId = 1;
            int skip = 0;
            int pageSize = 1;
            string searchValue = string.Empty;
            bool isExport = false;
            string Scheme = "VB";
            string ActivityType = "Core";
            int totalCount = 0;

            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);



            coreActivityJourneyRepos = new Mock<IGenericRepository<CoreActivityJourney>>();
            coreActivityJourneyRepos.Setup(x => x.Get()).Returns(coreActivityJourneylst);


            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(coreActivityJourneyRepos.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);

            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            var result = reportService.GetCoreActivities(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified),lanId,skip,pageSize,searchValue,isExport,Scheme,userId,ActivityType,1,out totalCount);

            Assert.IsNotNull(result);

        }


        [TestMethod()]
        public void GetCoreActivitiesTest()
        {


            string lanId = "CAPITA\\P10322047";
            int departmentId = 1;
            int skip = 0, teamId=1;
            int pageSize = 1;
            string searchValue = string.Empty;
            bool isExport = false;
            int totalCount = 0;

            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);



            coreActivityJourneyRepos = new Mock<IGenericRepository<CoreActivityJourney>>();
            coreActivityJourneyRepos.Setup(x => x.Get()).Returns(coreActivityJourneylst);


            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(coreActivityJourneyRepos.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);

            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            var result = reportService.GetCoreActivitiesReport(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), lanId, skip, pageSize, searchValue, isExport, teamId, out totalCount);

            Assert.IsNotNull(result);

        }

        [TestMethod()]
        public void getTimeTest()
        {
            
            uow = new Mock<IUnitOfWork>();
            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);            

            var result = reportService.getTime(360);

            Assert.AreNotEqual(null, result);
        }

        [TestMethod()]
        public void GetSTTReportTest()
        {
            string spName = "SpGetSTTReport";
            string lanId = "CAPITA\\P10322047";
           
            int departmentId = 1, teamId=1;
            DateTime startDate = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate = DateTime.Now.Date.ToUniversalTime();
            DateTime startDate1 = DateTime.Now.Date.ToUniversalTime();
            DateTime endDate1 = DateTime.Now.Date.ToUniversalTime();

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
            startDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), userTimeZone);
            endDate1 = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified).AddDays(1), userTimeZone);


            sttreportRepos = new Mock<IGenericRepository<STTReport>>();
            //loginLogoutReport.Setup(m => m.GetSP(It.IsAny<string>(), It.IsAny<List<spParameter>>())).Returns(loginLogoutlst.ToList());
            sttreportRepos.Setup(m => m.GetSP(It.Is<string>(x => x == spName),
                                                           It.Is<List<spParameter>>
                                                               (x =>
                                                                    x[0].Name == "@DepartmentId" && x[0].Value == departmentId.ToString() &&
                                                                    x[1].Name == "@StartDate" && x[1].Value == startDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime) &&
                                                                    x[2].Name == "@EndDate" && x[2].Value == endDate1.ToString(Settings.AppSetting.DisplayDateFormatWithTime)
                                                               )
                                                           )).Returns(sttReportlst.ToList());

            UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            UserRepository.Setup(u => u.Get()).Returns(userList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<STTReport>()).Returns(sttreportRepos.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(UserRepository.Object);

            _UserService = new Mock<IUser>();

            reportService = new ReportService(_UserService.Object, uow.Object);

            var result = reportService.GetSTTRepot(departmentId, DateTime.SpecifyKind(startDate, DateTimeKind.Unspecified), DateTime.SpecifyKind(endDate, DateTimeKind.Unspecified), lanId, teamId);

            Assert.IsNotNull(result);
        }


    }
}
