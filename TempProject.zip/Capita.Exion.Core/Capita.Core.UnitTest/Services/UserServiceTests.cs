﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models.CustomModels;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class UserServiceTests
    {
        private Mock<IUnitOfWork> uow;
        private Mock<IGenericRepository<UserPrimaryDetails>> _UserPrimaryDetailsRepository = null;
        private Mock<IGenericRepository<UserLoggedIn>> _UserLoggedInRepository = null;
        private Mock<IGenericRepository<MstDepartment>> _MstDepartmentRepository = null;
        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;
        private UserService _UserService = null;
        private Mock<IAuxCode> _AuxCodeService = null;


        [TestMethod()]
        public void GetAllUsersTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result = _UserService.GetAllUsers();

            Assert.IsNotNull(result);
            Assert.AreEqual(3, result.Count());
        }

        [TestMethod()]
        public void GetAllUsersByDepartmentIdTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();
            IQueryable<MappingUserDepartment> queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment_1().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_department_1 = _UserService.GetAllUsersByDepartmentId(1);
            var result_department_2 = _UserService.GetAllUsersByDepartmentId(2);

            Assert.IsNotNull(result_department_1);
            Assert.AreEqual(2, result_department_1.Count());
            Assert.IsNotNull(result_department_2);
            Assert.AreEqual(1, result_department_2.Count());
        }

        
        [TestMethod()]
        public void GetUserByIdTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_1 = _UserService.GetUserById(1);
            var result_user_2 = _UserService.GetUserById(2);
            var result_user_3 = _UserService.GetUserById(3);

            Assert.IsNotNull(result_user_1);
            Assert.AreEqual(1, result_user_1.Id);
            Assert.AreEqual("u1f", result_user_1.FirstName);

            Assert.IsNotNull(result_user_2);
            Assert.AreEqual(2, result_user_2.Id);
            Assert.AreEqual("u2f", result_user_2.FirstName);

            Assert.IsNotNull(result_user_3);
            Assert.AreEqual(3, result_user_3.Id);
            Assert.AreEqual("u3f", result_user_3.FirstName);
        }
        
        [TestMethod()]
        public void GetUserIdFromLanIdTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_1 = _UserService.GetUserIdFromLanId("CAPITA\\P1111");
            var result_user_2 = _UserService.GetUserIdFromLanId("CAPITA\\P2222");
            var result_user_3 = _UserService.GetUserIdFromLanId("CAPITA\\P3333");

            Assert.AreEqual(1, result_user_1);
            Assert.AreEqual(2, result_user_2);
            Assert.AreEqual(3, result_user_3);

        }
        
        [TestMethod()]
        public void GetUserDetailsFromLanIdTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_1 = _UserService.GetUserDetailsFromLanId("CAPITA\\P1111");
            var result_user_2 = _UserService.GetUserDetailsFromLanId("CAPITA\\P2222");
            var result_user_3 = _UserService.GetUserDetailsFromLanId("CAPITA\\P3333");

            Assert.IsNotNull(result_user_1);
            Assert.AreEqual(1, result_user_1.Id);
            Assert.AreEqual("CAPITA\\P1111", result_user_1.LanId);

            Assert.IsNotNull(result_user_2);
            Assert.AreEqual(2, result_user_2.Id);
            Assert.AreEqual("CAPITA\\P2222", result_user_2.LanId);

            Assert.IsNotNull(result_user_3);
            Assert.AreEqual(3, result_user_3.Id);
            Assert.AreEqual("CAPITA\\P3333", result_user_3.LanId);
        }
        
        [TestMethod()]
        public void AddUserTest()
        {
            UserPrimaryDetails u4 = DataInitializer.GetAddUserData();

            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_4 = _UserService.AddUser(u4,1);

            Assert.AreEqual(true, result_user_4);
        }

        [TestMethod()]
        public void GetActiveSessionOfUsersTest()
        {
            IQueryable<UserLoggedIn> queryUserLoggedIn = DataInitializer.GetLstUserLoggedIn().AsQueryable();
            IQueryable<MstDepartment> queryMstDepartment = DataInitializer.GetLstMstDepartment().AsQueryable();
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            UserPrimaryDetails currentLoggedInUser = DataInitializer.GetCurrentLoggedInUser();

            _UserLoggedInRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoggedInRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryMstDepartment);

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoggedInRepository.Object);
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result = _UserService.GetActiveSessionOfUsers(1, currentLoggedInUser) ;

            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count);
            Assert.AreEqual(1, result.Select(x=> x.DepartmentName).Distinct().Count());
            Assert.AreEqual("SBSS", result.Select(x => x.DepartmentName).FirstOrDefault());

        }

        [TestMethod()]
        public void AddUserAndDeptTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            UserDetails user = DataInitializer.GetAddUserAndDeptData();

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result = _UserService.AddUserAndDept(user);

            Assert.IsNotNull(result);
            Assert.AreEqual(true, result);
            Assert.AreEqual(0, user.DepartmentId);
        }
        
        [TestMethod()]
        public void CheckUserExistsTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_1 = _UserService.CheckUserExists("1111", "CAPITA\\P4444");
            var result_user_2 = _UserService.CheckUserExists("4444", "CAPITA\\P1111");
            var result_user_3 = _UserService.CheckUserExists("1111", "CAPITA\\P1111");
            var result_user_4 = _UserService.CheckUserExists("4444", "CAPITA\\P4444");

            Assert.AreEqual(true, result_user_1);
            Assert.AreEqual(false, result_user_2);
            Assert.AreEqual(true, result_user_3);
            Assert.AreEqual(false, result_user_4);

        }
        
        [TestMethod()]
        public void CheckUserExistsTest1()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            UserPrimaryDetails existingUser1 = DataInitializer.GetCurrentLoggedInUser();
            existingUser1.LanId = "CAPITA\\P2222";

            UserPrimaryDetails existingUser2 = DataInitializer.GetCurrentLoggedInUser();
            existingUser2.EmployeeId = "2222";

            UserPrimaryDetails existingUser3 = DataInitializer.GetCurrentLoggedInUser();
            existingUser3.LanId = "CAPITA\\P2222";
            existingUser3.EmployeeId = "2222";

            UserPrimaryDetails existingUser4 = DataInitializer.GetCurrentLoggedInUser();

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result_user_1 = _UserService.CheckUserExists(existingUser1);
            var result_user_2 = _UserService.CheckUserExists(existingUser2);
            var result_user_3 = _UserService.CheckUserExists(existingUser3);
            var result_user_4 = _UserService.CheckUserExists(existingUser4);

            Assert.AreEqual(true, result_user_1);//cannot set some other users lanId
            Assert.AreEqual(true, result_user_2);//cannot set some other users EmployeeId
            Assert.AreEqual(true, result_user_3);//cannot set some other users lanId and EmployeeId
            Assert.AreEqual(false, result_user_4);//lanId and EmployeeId is unique for the user

        }
        
        [TestMethod()]
        public void UpdateUserAndDeptTest()
        {
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();
        
            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            UserPrimaryDetails existingUser1 = DataInitializer.GetCurrentLoggedInUser();
            existingUser1.FirstName = "u11f";

            UserPrimaryDetails existingUser2 = DataInitializer.GetCurrentLoggedInUser();
            existingUser2.Id = 6;
            existingUser2.FirstName = "u6f";

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result1 = _UserService.UpdateUserAndDept(existingUser1, 1);
            var result2 = _UserService.UpdateUserAndDept(existingUser2, 1);

            Assert.AreEqual(true, result1);
            Assert.AreEqual(false, result2);
        }
        
        [TestMethod()]
        public void DeleteUserByIdTest()
        {
            List<UserPrimaryDetails> lstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails();
            var newEmp = lstUserPrimaryDetails.FirstOrDefault();
            newEmp.Id = 4;
            newEmp.IsActive = false;
            lstUserPrimaryDetails.Add(newEmp);
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = lstUserPrimaryDetails.AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result1 = _UserService.DeleteUserById(3, 1);
            var result2 = _UserService.DeleteUserById(4, 1);
            Assert.AreEqual(true, result1);
            Assert.AreEqual(true, result2);

        }

        [TestMethod()]
        public void GetEmployeesByManagerIdAndDepartmentIdTest()
        {
            IQueryable<MappingUserDepartment> queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment_1().AsQueryable();
            IQueryable<UserPrimaryDetails> queryLstUserPrimaryDetails = DataInitializer.GetUserPrimaryDetails().AsQueryable();

            _UserPrimaryDetailsRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserPrimaryDetailsRepository.Setup(m => m.Get()).Returns(queryLstUserPrimaryDetails);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _AuxCodeService = new Mock<IAuxCode>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserPrimaryDetailsRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _UserService = new UserService(uow.Object, _AuxCodeService.Object);

            var result1 = _UserService.GetEmployeesByManagerIdAndDepartmentId(2, 2);//is manager of department 2
            var result2 = _UserService.GetEmployeesByManagerIdAndDepartmentId(1, 2);//is not a manager of department 1
            var result3 = _UserService.GetEmployeesByManagerIdAndDepartmentId(1, 1);//is not a manager of department 1

            Assert.AreEqual(2, result1.Count);
            Assert.AreEqual(0, result2.Count);
            Assert.AreEqual(0, result3.Count);
        }

        //[TestMethod()]
        //public void AddOrUpdateCurrentActivityTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetCurrentActivityTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetCurrentUsersActivityTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetLoggedInUserDetailsTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetUserLogsTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void AddUserLogTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void UpdateUserLogTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetUserLogTest()
        //{
        //    Assert.Fail();
        //}
        //




        //[TestMethod()]
        //public void GetUsersByDepartmentIdTest()
        //{
        //    Assert.Fail();
        //}
        //
        //[TestMethod()]
        //public void GetUserDataForTodayTest()
        //{
        //    Assert.Fail();
        //}
    }
}