﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class AuxCodeServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private AuxCodeService _AuxCodeService = null;

        private Mock<IGenericRepository<MappingAuxCodeDepartment>> _MappingAuxCodeDepartmentRepository = null;

        private Mock<IGenericRepository<MstAuxCode>> _MstAuxCodeRepository = null;

        IQueryable<MappingAuxCodeDepartment> lstMappingAuxCodeDepartment = null;

        IQueryable<MstAuxCode> lstMstAuxCode = null;

        [TestInitialize]
        public void Initialize()
        {
            lstMappingAuxCodeDepartment = DataInitializer.GetMappingAuxCodeDepartment();
            lstMstAuxCode = DataInitializer.GetMstAuxCode();            
        }

        [TestMethod()]
        public void GetAllAuxCodeByDepartmentIdTest()
        {
            int departmentId = 1;

            _MappingAuxCodeDepartmentRepository = new Mock<IGenericRepository<MappingAuxCodeDepartment>>();
            _MappingAuxCodeDepartmentRepository.Setup(m => m.Get()).Returns(lstMappingAuxCodeDepartment);

            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingAuxCodeDepartment>()).Returns(_MappingAuxCodeDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.GetAllAuxCode(departmentId);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void GetAuxCodeByIdTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.GetAuxCodeById(1);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void CheckAuxCodeExistsTest()
        {
            MstAuxCode auxCode = new MstAuxCode();
            auxCode.Id = 1;
            auxCode.ActivityName = "Lunch";

            MstAuxCode auxCode2 = new MstAuxCode();
            auxCode2.Id = 1;
            auxCode2.ActivityName = "Lunch111";

            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result1 = _AuxCodeService.CheckAuxCodeExists(auxCode);
            var result2 = _AuxCodeService.CheckAuxCodeExists(auxCode2);

            Assert.AreEqual(true, result1);//aux code Lunch already exist
            Assert.AreEqual(false, result2);
        }

        [TestMethod()]
        public void GetAllAuxCodeListTest()
        {
            var auxCodeList = lstMstAuxCode.ToList();
            auxCodeList.Add(new MstAuxCode() { Id = 10, ActivityName = "Idle" });
            var queryauxCodeList = auxCodeList.AsQueryable();

            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(queryauxCodeList);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.GetAllAuxCodeList().ToList();

            Assert.AreEqual(5, result.Count);//exclude idle
        }

        [TestMethod()]
        public void GetAllAssignedAuxCodeTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            _MappingAuxCodeDepartmentRepository = new Mock<IGenericRepository<MappingAuxCodeDepartment>>();
            _MappingAuxCodeDepartmentRepository.Setup(m => m.Get()).Returns(lstMappingAuxCodeDepartment);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);
            uow.Setup(m => m.GetRepository<MappingAuxCodeDepartment>()).Returns(_MappingAuxCodeDepartmentRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result1 = _AuxCodeService.GetAllAssignedAuxCode(1).ToList();
            var result2 = _AuxCodeService.GetAllAssignedAuxCode(2).ToList();

            Assert.AreEqual(4, result1.Count);//out of 5 aux code, 1 is not visible,so result is 4
            Assert.AreEqual(3, result2.Count);
        }

        [TestMethod()]
        public void GetAllAuxCodeTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.GetAllAuxCode().ToList();

            Assert.AreEqual(5, result.Count);
        }

        [TestMethod()]
        public void AddAuxCodeTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            MstAuxCode auxCode = new MstAuxCode();
            auxCode.ActivityName = "New Act";

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.AddAuxCode(auxCode, new UserPrimaryDetails() {Id = 1 });

            Assert.AreEqual(true, result);
        }

        [TestMethod()]
        public void UpdateAuxCodeTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            MstAuxCode auxCode = new MstAuxCode();
            auxCode.Id = 1;
            auxCode.ActivityName = "New Act";

            MstAuxCode auxCode2 = new MstAuxCode();
            auxCode2.Id = 10;
            auxCode2.ActivityName = "New Act";

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result1 = _AuxCodeService.UpdateAuxCode(auxCode, new UserPrimaryDetails() { Id = 1 });
            var result2 = _AuxCodeService.UpdateAuxCode(auxCode2, new UserPrimaryDetails() { Id = 1 });

            Assert.AreEqual(true, result1);
            Assert.AreEqual(false, result2);
        }

        [TestMethod()]
        public void DeleteAuxCodeByIdTest()
        {
            _MstAuxCodeRepository = new Mock<IGenericRepository<MstAuxCode>>();
            _MstAuxCodeRepository.Setup(m => m.Get()).Returns(lstMstAuxCode);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstAuxCode>()).Returns(_MstAuxCodeRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _AuxCodeService = new AuxCodeService(uow.Object);

            var result = _AuxCodeService.DeleteAuxCodeById(1);

            Assert.AreEqual(true, result);
        }


    }
}