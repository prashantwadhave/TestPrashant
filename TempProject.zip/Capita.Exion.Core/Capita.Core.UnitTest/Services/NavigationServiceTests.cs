﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using Moq;
using Capita.Core.UnitTest.Helper;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class NavigationServiceTests
    {
        private Mock<IUnitOfWork> uow;
        
        private NavigationService _NavigationService = null;

        private Mock<IGenericRepository<MstNavigation>> _navigationRepository = null;

        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;

        private Mock<IGenericRepository<MappingRoleNavigation>> _MappingRoleNavigationRepository = null;

        private Mock<IUser> _UserService = null;

        IQueryable<MappingUserDepartment> queryMappingUserDepartment = null;

        IQueryable<MappingRoleNavigation> queryMappingRoleNavigation = null;

        [TestInitialize]
        public void Initialize()
        {
            queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment();
            queryMappingRoleNavigation = DataInitializer.GetMappingRoleNavigation();
        }

        [TestMethod()]
        public void GetAllNavigationsTestForEmptyDB()
        {
            int userId = 2;
            IQueryable<MappingUserDepartment> queryMappingUserDepartment1 = new List<MappingUserDepartment>().AsQueryable();
            IQueryable<MappingRoleNavigation> queryMappingRoleNavigation1 = new List<MappingRoleNavigation>().AsQueryable();
            IQueryable<MstNavigation> queryMstNavigation = new List<MstNavigation>().AsQueryable();

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment1);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation1);

            _navigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _navigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_navigationRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _NavigationService = new NavigationService(uow.Object, _UserService.Object);

            var result = _NavigationService.GetAllNavigations(1, "capita\\p10359078");
            // Assert           
            Assert.IsNull(result);           
        }

        [TestMethod()]
        public void GetAllNavigationsTest()
        {
            int userId = 2;            
            
            List<MstNavigation> LstMstNavigation = new List<MstNavigation>()
            {
                new MstNavigation(){ Id = 1, DisplayName = "Dashboard", IsActive = true, ParentId = 0, SortOrder = 1, SourceUrl = "#/Home" },
                new MstNavigation(){ Id = 2, DisplayName = "Manager Dashboard", IsActive = true, ParentId = 0, SortOrder = 2, SourceUrl = "#/LineManagerDashboard" },
                new MstNavigation(){ Id = 3, DisplayName = "RTA", IsActive = true, ParentId = 0, SortOrder = 3, SourceUrl = "#/rta" },
                new MstNavigation(){ Id = 4, DisplayName = "Setting", IsActive = true, ParentId = 0, SortOrder = 4, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 5, DisplayName = "User Management", IsActive = true, ParentId = 0, SortOrder = 5, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 6, DisplayName = "Reports", IsActive = true, ParentId = 0, SortOrder = 6, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 7, DisplayName = "Add Role", IsActive = true, ParentId = 5, SortOrder = 7, SourceUrl = "#/addrole" }
            };

            IQueryable<MstNavigation> queryMstNavigation = LstMstNavigation.AsQueryable();

            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _navigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _navigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_navigationRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);

            _NavigationService = new NavigationService(uow.Object, _UserService.Object);

            var result = _NavigationService.GetAllNavigations(1, "capita\\p10359078");
            // Assert           
            Assert.IsNotNull(result);
        }
    }
}
