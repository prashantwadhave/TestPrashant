﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class CallsServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private Mock<IUser> _UserService = null;

        private Mock<ICoreActivity> _CoreActivityService = null;

        private CallsService _CallsService = null;
        
        private Mock<IGenericRepository<CoreActivityJourney>> _CoreActivityJourneyRepository = null;

        private Mock<IGenericRepository<NonCoreActivityJourney>> _NonCoreActivityJourneyRepository = null;
        private int teamId = 1;
        NonCoreActivityJourney queryNonCoreActivityJourney = null;

        [TestInitialize]
        public void Initialize()
        {
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivity();
        }

        [TestMethod()]
        public void AddCallActivityValidConditionTest()
        {
            int userId = 2;
            Calls callActivity = new Calls() { UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Duration = 0 , TeamId= teamId };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.AddCallActivity(callActivity, 1, "capita\\p10359078");

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddCallActivityInValidNonCoreActivityIdTest()
        {
            int userId = 2;
            Calls callActivity = new Calls() { UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Duration = 0, TeamId= teamId };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(3)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(false);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.AddCallActivity(callActivity, 1, "capita\\p10359078");

            Assert.AreEqual(0, result);
        }

        [TestMethod()]
        public void UpdateCallActivityWhenCoreActivityIsNullTest()
        {
            Calls callActivity = new Calls() { Id = 2, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Scheme = "scheme", CallCode = "code", CallCodeResolution = "resolution" };
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };
            NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Id = 1, Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, UserId = 2 };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(callActivity.UserId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);
            _CoreActivityJourneyRepository.Setup(m => m.Add(existingCoreActivity));

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.UpdateCallActivity(callActivity, false, false);

            Assert.AreEqual(0,result);
        }

        [TestMethod()]
        public void UpdateCallActivityWhenCoreAndWebChatNotStartedTest()
        {
            Calls callActivity = new Calls() {Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Scheme = "scheme", CallCode = "code", CallCodeResolution = "resolution" };
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };
            NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() {Id = 1, Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, UserId = 2 };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();            
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(callActivity.UserId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);
            _CoreActivityJourneyRepository.Setup(m => m.Add(existingCoreActivity));

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();            

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.UpdateCallActivity(callActivity, false, false);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateCallActivityWhenCoreStartedAndWebChatNotStartedTest()
        {
            Calls callActivity = new Calls() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Scheme = "scheme", CallCode = "code", CallCodeResolution = "resolution" };
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };
            NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Id = 1, Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, UserId = 2 };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(callActivity.UserId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);
            _CoreActivityJourneyRepository.Setup(m => m.Add(existingCoreActivity));

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.UpdateCallActivity(callActivity, true, false);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateCallActivityWhenCoreNotStartedAndWebChatStartedTest()
        {
            Calls callActivity = new Calls() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Scheme = "scheme", CallCode = "code", CallCodeResolution = "resolution" };
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };
            NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Id = 1, Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, UserId = 2 };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(callActivity.UserId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);
            _CoreActivityJourneyRepository.Setup(m => m.Add(existingCoreActivity));

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.UpdateCallActivity(callActivity, false, true);

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void UpdateCallActivityWhenCoreAndWebChatStartedTest()
        {
            Calls callActivity = new Calls() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Scheme = "scheme", CallCode = "code", CallCodeResolution = "resolution" };
            CoreActivityJourney existingCoreActivity = new CoreActivityJourney() { Id = 1, UserId = 2, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, Duration = 0, Param1 = "scheme", Param2 = "code", Param3 = "resolution" };
            NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Id = 1, Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = null, UserId = 2 };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(callActivity.UserId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();
            _CoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(existingCoreActivity);
            _CoreActivityJourneyRepository.Setup(m => m.Add(existingCoreActivity));

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.UpdateCallActivity(callActivity, true, true);

            Assert.IsNotNull(result);
        }


        [TestMethod()]
        public void AddCallActivityValidConditionOfTeamIdTest()
        {
            int userId = 67;
            Calls callActivity = new Calls() { UserId = userId, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Duration = 0, TeamId = teamId };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10355915")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);
            


            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);
            uow.Setup(m => m.Commit()).Returns(true);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);
            //uow.Setup(x => x.Commit()).Returns(true);


            var result = _CallsService.AddCallActivity(callActivity, 1, "capita\\p10355915");

            Assert.IsNotNull(result);
        }

        [TestMethod()]
        public void AddCallActivityInValidTeamIdTest()
        {
            int userId = 67;
           // int number = 4;
            teamId = 0;// This team id does not exist in database
            Calls callActivity = new Calls() { UserId = userId, DepartmentId = 1, StartTime = DateTimeHelper.Now, EndTime = DateTimeHelper.Now, Duration = 0, TeamId = teamId };

            _UserService = new Mock<IUser>();
            _CoreActivityService = new Mock<ICoreActivity>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10355915")).Returns(userId);
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, 1, Settings.Constants.Call, teamId));

            _CoreActivityJourneyRepository = new Mock<IGenericRepository<CoreActivityJourney>>();

            _NonCoreActivityJourneyRepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NonCoreActivityJourneyRepository.Setup(m => m.GetByID(3)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<CoreActivityJourney>()).Returns(_CoreActivityJourneyRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NonCoreActivityJourneyRepository.Object);
            uow.Setup(m => m.Commit()).Returns(false);

            _CallsService = new CallsService(_UserService.Object, uow.Object, _CoreActivityService.Object);

            var result = _CallsService.AddCallActivity(callActivity, 1, "capita\\p10355915");

            Assert.AreEqual(0, result);
        }
    }
}