﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Capita.Core.Services.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Contracts;
using Moq;
using Capita.Core.Models.DataModels;
using Capita.Core.UnitTest.Helper;
using Capita.Core.Models;

namespace Capita.Core.Services.Services.Tests
{
    [TestClass()]
    public class CommonServiceTests
    {
        private Mock<IUnitOfWork> uow;

        private Mock<IUser> _UserService = null;

        private CommonService _CommonServiceService = null;

        private Mock<IGenericRepository<MstDepartment>> _MstDepartmentRepository = null;

        private Mock<IGenericRepository<NonCoreActivityJourney>> _NCARepository = null;

        private Mock<IGenericRepository<UserPrimaryDetails>> _UserRepository = null;

        private Mock<IGenericRepository<UserLoggedIn>> _UserLoginRepository = null;

        private Mock<IGenericRepository<UserCurrentActivity>> _UserCurrentActivityRepository = null;

        private Mock<IGenericRepository<MappingUserDepartment>> _MappingUserDepartmentRepository = null;

        private Mock<IGenericRepository<MappingRoleNavigation>> _MappingRoleNavigationRepository = null;

        private Mock<IGenericRepository<MstNavigation>> _NavigationRepository = null;

        NonCoreActivityJourney queryNonCoreActivityJourney = null;

        IQueryable<UserPrimaryDetails> queryUser = null;

        IQueryable<UserLoggedIn> queryUserLoggedIn = null;

        IQueryable<UserCurrentActivity> queryUserCurrentActivity = null;

        IQueryable<MappingUserDepartment> queryMappingUserDepartment = null;

        IQueryable<MappingRoleNavigation> queryMappingRoleNavigation = null;

        IQueryable<MstNavigation> queryMstNavigation = null;

        IQueryable<MstDepartment> queryDepartments = null;
        private int teamId = 1;

        [TestInitialize]
        public void Initialize()
        {
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivity();
            queryUser = DataInitializer.GetAllUsers().AsQueryable();
            queryUserLoggedIn = DataInitializer.GetAllUserLoggedIn().AsQueryable();
            queryUserCurrentActivity = DataInitializer.GetUserCurrentActivity().AsQueryable();
            queryMappingUserDepartment = DataInitializer.GetMappingUserDepartment();
            queryMappingRoleNavigation = DataInitializer.GetMappingRoleNavigation();
            queryMstNavigation = DataInitializer.GetMstNavigation();
            queryDepartments = DataInitializer.GetDepartments();
        }

        [TestMethod()]
        public void AddUserLoginDetailsInValidUserTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.AddUserLoginDetails(queryNonCoreActivityJourney, "capita\\p10359078q", false);

            Assert.IsNull(Result);
        }

        [TestMethod()]
        public void AddUserLoginDetailsValidUserTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.AddUserLoginDetails(queryNonCoreActivityJourney, "capita\\p10359078", false);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void AddUserLoginDetailsDepartmentChangedTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.AddUserLoginDetails(queryNonCoreActivityJourney, "capita\\p10359078", true);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void UpdateUserLogOutDetailsValidTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));
            _UserService.Setup(u => u.GetUserLog(1)).Returns(new UserLogs() { Id = 1, ActivityName = Settings.Constants.CoreActivity, DepartmentId = 1, UserId = 2, LoginTime = DateTimeHelper.Now, Duration = 0, LogOutTime = null, UserName = "Shriyansh jain" });

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _UserCurrentActivityRepository = new Mock<IGenericRepository<UserCurrentActivity>>();
            _UserCurrentActivityRepository.Setup(m => m.Get()).Returns(queryUserCurrentActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<UserCurrentActivity>()).Returns(_UserCurrentActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.UpdateUserLogOutDetails(1, "capita\\p10359078", 1, 1);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void UpdateUserLogOutDetailsWhereUserLoggedInIsNullTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));
            _UserService.Setup(u => u.GetUserLog(1)).Returns(new UserLogs() { Id = 1, ActivityName = Settings.Constants.CoreActivity, DepartmentId = 1, UserId = 2, LoginTime = DateTimeHelper.Now, Duration = 0, LogOutTime = null, UserName = "Shriyansh jain" });

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _UserCurrentActivityRepository = new Mock<IGenericRepository<UserCurrentActivity>>();
            _UserCurrentActivityRepository.Setup(m => m.Get()).Returns(queryUserCurrentActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<UserCurrentActivity>()).Returns(_UserCurrentActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.UpdateUserLogOutDetails(2, "capita\\p10359078", 1, 1);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void UpdateUserLogOutDetailsWhereUserCurrentActivityIsNullTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));
            _UserService.Setup(u => u.GetUserLog(1)).Returns(new UserLogs() { Id = 1, ActivityName = Settings.Constants.CoreActivity, DepartmentId = 1, UserId = 2, LoginTime = DateTimeHelper.Now, Duration = 0, LogOutTime = null, UserName = "Shriyansh jain" });

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _UserCurrentActivityRepository = new Mock<IGenericRepository<UserCurrentActivity>>();
            _UserCurrentActivityRepository.Setup(m => m.Get()).Returns(queryUserCurrentActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<UserCurrentActivity>()).Returns(_UserCurrentActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.UpdateUserLogOutDetails(2, "capita\\p10359078", 1, 1);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void UpdateUserLogOutDetailsWhereUserLogAndNonCoreIsNullTest()
        {
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.AddOrUpdateCurrentActivity(2, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, 1, string.Empty, teamId));
            _UserService.Setup(u => u.GetUserLog(1)).Returns(new UserLogs() { Id = 1, ActivityName = Settings.Constants.CoreActivity, DepartmentId = 1, UserId = 2, LoginTime = DateTimeHelper.Now, Duration = 0, LogOutTime = null, UserName = "Shriyansh jain" });

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _UserCurrentActivityRepository = new Mock<IGenericRepository<UserCurrentActivity>>();
            _UserCurrentActivityRepository.Setup(m => m.Get()).Returns(queryUserCurrentActivity);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<UserCurrentActivity>()).Returns(_UserCurrentActivityRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.UpdateUserLogOutDetails(2, "capita\\p10359078", 10, 10);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void ChangeDepartmentValidTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.ChangeDepartment(1, "capita\\p10359078", 1);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void ChangeDepartmentWhereNonCoreIsNullTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.ChangeDepartment(1, "capita\\p10359078", 10);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void ChangeDepartmentWhereNonCoreEndTimeIsNotNullTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivityWhereEndTimeIsNotNull();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.ChangeDepartment(1, "capita\\p10359078", 1);

            Assert.IsNotNull(Result);
        }

        [TestMethod()]
        public void ChangeDepartmentWhereNavigationIstNullTest()
        {
            int userId = 2;
            _UserService = new Mock<IUser>();
            _UserService.Setup(u => u.GetUserIdFromLanId("capita\\p10359078")).Returns(userId);

            _NCARepository = new Mock<IGenericRepository<NonCoreActivityJourney>>();
            queryNonCoreActivityJourney = DataInitializer.GetNonCoreActivityWhereEndTimeIsNotNull();
            _NCARepository.Setup(m => m.GetByID(1)).Returns(queryNonCoreActivityJourney);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            queryMappingRoleNavigation = new List<MappingRoleNavigation>().AsQueryable();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            new List<MstNavigation>().AsQueryable();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<NonCoreActivityJourney>()).Returns(_NCARepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.ChangeDepartment(1, "capita\\p10359078", 1);

            Assert.AreEqual(0, Result.UserAccessibleUrls.Count);
        }

        [TestMethod()]
        public void IsUserAuthorizedInValidUserTest()
        {
            _UserService = new Mock<IUser>();

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.IsUserAuthorized("capita\\p10359078q");

            Assert.IsNull(Result);
        }

        [TestMethod()]
        public void IsUserAuthorizedWhereDeptNotAssignTest()
        {
            _UserService = new Mock<IUser>();

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            queryUser = DataInitializer.GetAllUsersWhereDeptNotAssigned().AsQueryable();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.IsUserAuthorized("capita\\p10359078");

            Assert.AreEqual(0, Result.DepartmentId);
        }

        [TestMethod()]
        public void IsUserAuthorizedWhereNavigationIstNullTest()
        {
            _UserService = new Mock<IUser>();

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            queryMappingRoleNavigation = new List<MappingRoleNavigation>().AsQueryable();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.IsUserAuthorized("capita\\p10359078");

            Assert.AreEqual(0, Result.UserAccessibleUrls.Count);
        }

        [TestMethod()]
        public void IsUserAuthorizedWhereUserLoggedInIsNullTest()
        {
            _UserService = new Mock<IUser>();

            _UserRepository = new Mock<IGenericRepository<UserPrimaryDetails>>();
            _UserRepository.Setup(m => m.Get()).Returns(queryUser);

            _MappingUserDepartmentRepository = new Mock<IGenericRepository<MappingUserDepartment>>();
            _MappingUserDepartmentRepository.Setup(m => m.Get()).Returns(queryMappingUserDepartment);

            _MappingRoleNavigationRepository = new Mock<IGenericRepository<MappingRoleNavigation>>();
            _MappingRoleNavigationRepository.Setup(m => m.Get()).Returns(queryMappingRoleNavigation);

            _NavigationRepository = new Mock<IGenericRepository<MstNavigation>>();
            _NavigationRepository.Setup(m => m.Get()).Returns(queryMstNavigation);

            _UserLoginRepository = new Mock<IGenericRepository<UserLoggedIn>>();
            queryUserLoggedIn = new List<UserLoggedIn>().AsQueryable();
            _UserLoginRepository.Setup(m => m.Get()).Returns(queryUserLoggedIn);

            _MstDepartmentRepository = new Mock<IGenericRepository<MstDepartment>>();
            _MstDepartmentRepository.Setup(m => m.Get()).Returns(queryDepartments);

            uow = new Mock<IUnitOfWork>();
            uow.Setup(m => m.GetRepository<MappingUserDepartment>()).Returns(_MappingUserDepartmentRepository.Object);
            uow.Setup(m => m.GetRepository<MappingRoleNavigation>()).Returns(_MappingRoleNavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserPrimaryDetails>()).Returns(_UserRepository.Object);
            uow.Setup(m => m.GetRepository<MstNavigation>()).Returns(_NavigationRepository.Object);
            uow.Setup(m => m.GetRepository<UserLoggedIn>()).Returns(_UserLoginRepository.Object);
            uow.Setup(m => m.GetRepository<MstDepartment>()).Returns(_MstDepartmentRepository.Object);
            uow.Setup(m => m.Commit()).Returns(true);

            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.IsUserAuthorized("capita\\p10359078");

            Assert.AreEqual(false, Result.IsUserSessionActiveInDB);
        }

        [TestMethod()]
        public void GetTimezonesTest()
        {
            _UserService = new Mock<IUser>();
            uow = new Mock<IUnitOfWork>();
            _CommonServiceService = new CommonService(_UserService.Object, uow.Object);

            var Result = _CommonServiceService.GetTimezones();

            Assert.IsNotNull(Result);
        }
    }
}