﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.UnitTest.Helper
{
    public static class DataInitializer
    {
        public static IQueryable<MappingAuxCodeDepartment> GetMappingAuxCodeDepartment()
        {
            return new List<MappingAuxCodeDepartment>()
            {
                new MappingAuxCodeDepartment(){ Id =1, DepartmentId = 1, AuxCodeId = 1, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =2, DepartmentId = 1, AuxCodeId = 2, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =3, DepartmentId = 1, AuxCodeId = 3, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =4, DepartmentId = 1, AuxCodeId = 4, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =5, DepartmentId = 1, AuxCodeId = 5, IsVisibile = false},
                new MappingAuxCodeDepartment(){ Id =6, DepartmentId = 2, AuxCodeId = 1, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =7, DepartmentId = 2, AuxCodeId = 2, IsVisibile = true},
                new MappingAuxCodeDepartment(){ Id =8, DepartmentId = 2, AuxCodeId = 3, IsVisibile = true}
            }.AsQueryable();
        }

        public static IQueryable<MstTeam> GetTeamList()
        {

            return new List<MstTeam>()
            {
                new MstTeam(){Id=1,Name="Team A",DepartmentId=1,IsActive=true },
                new MstTeam(){Id=2,Name="Team B",DepartmentId=1,IsActive=true }

            }.AsQueryable();

        }

        public static IQueryable<DisplayUserDepartmentRole> DisplayUserDepartmentRole()
        {
            return new List<DisplayUserDepartmentRole>()
            {
                new DisplayUserDepartmentRole() { Id =1, UserName = "Dhananjay Hole", DepartmentName = "SBSS", TeamName = "Team A", RoleName = "Advisor"},
                new DisplayUserDepartmentRole() { Id =2, UserName = "Dhananjay Hole", DepartmentName = "SBSS", TeamName = "Team B", RoleName = "Advisor"}
                
            }.AsQueryable();
        }

        public static IQueryable<ProductivityReport> GetProductivityReportList()
        {
            return new List<ProductivityReport>()
            {
                new ProductivityReport(){  AgentName = "Dhananjay Hole", Timelogged ="08:00:00",NonCoreDuration="00:50:00",CoreDuration="09:00:00",Productivity="100"},
                new ProductivityReport(){  AgentName = "Abhishek", Timelogged ="08:00:00",NonCoreDuration="00:50:00",CoreDuration="09:00:00",Productivity="100"},
                new ProductivityReport(){  AgentName = "Shriyansh", Timelogged ="08:00:00",NonCoreDuration="00:50:00",CoreDuration="09:00:00",Productivity="100"}

            }.AsQueryable();
        }

        public static IQueryable<CoreActivityJourney> coreActivitiesList()
        {
            return new List<CoreActivityJourney>()
            {
                new CoreActivityJourney(){  UserId = 6, ActivityType ="Core",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration=360,Remarks="Remark",Param1="VB",Param2="123",Param3="Task1"},
                new CoreActivityJourney(){  UserId = 7, ActivityType ="Core",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration=360,Remarks="Remark",Param1="VB",Param2="123",Param3="Task2"},
                new CoreActivityJourney(){  UserId = 8, ActivityType ="Core",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration=360,Remarks="Remark",Param1="VB",Param2="123",Param3="Task3"}

            }.AsQueryable();
        }

        public static IQueryable<STTReport> GetSttReportList()
        {
            return new List<STTReport>()
            {
                new STTReport(){  AgentName = "Dhananjay Hole", Activity ="C2L",Task="ADVANCE PAYMENT",Task_Count="1" ,AHT="00:01:04",STT="00:01:00",Color="red"},
                new STTReport(){  AgentName = "Dhananjay Hole", Activity ="PCDL",Task="AMENDEIORG",Task_Count="4" ,AHT="00:04:57",STT="00:08:00",Color="green"},
                new STTReport(){  AgentName = "Dhananjay Hole", Activity ="PCDL",Task="BANKDEC",Task_Count="4" ,AHT="00:04:57",STT="00:08:00",Color="green"},
                new STTReport(){  AgentName = "Dhananjay Hole", Activity ="PCDL",Task="Task1",Task_Count="4" ,AHT="00:04:57",STT="00:08:00",Color="green"}

            }.AsQueryable();
        }

        public static IQueryable<CoreActivity> coreActivitiesForSBSSList()
        {
            return new List<CoreActivity>()
            {
                new CoreActivity(){  AgentName = "Dhananjay Hole", ActivityType ="08:00:00",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration="360",Remarks="Remark",Scheme="VB",UID="123",Task="Task1",StrStartTime=DateTimeHelper.Now.ToString(),StrEndTime=DateTimeHelper.Now.AddHours(1).ToString()},
                new CoreActivity(){  AgentName = "Abhishek", ActivityType ="08:00:00",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration="360",Remarks="Remark",Scheme="VB",UID="123",Task="Task1",StrStartTime=DateTimeHelper.Now.ToString(),StrEndTime=DateTimeHelper.Now.AddHours(1).ToString()},
                new CoreActivity(){  AgentName = "Shriyansh", ActivityType ="08:00:00",DepartmentId=1,StartTime=DateTimeHelper.Now,EndTime=DateTimeHelper.Now.AddHours(1),Duration="360",Remarks="Remark",Scheme="VB",UID="123",Task="Task1",StrStartTime=DateTimeHelper.Now.ToString(),StrEndTime=DateTimeHelper.Now.AddHours(1).ToString()}

            }.AsQueryable();
        }

        public static IQueryable<TaskAverageReport> GettaskAverageReportList()
        {
            return new List<TaskAverageReport>()
            {
                new TaskAverageReport(){  Scheme = "C2L", Task ="ADVANCE PAYMENT",TotalTask=1,TotalHandlingTime="01:00:00",AverageHandlingTime="01:00:00"},
                new TaskAverageReport(){  Scheme = "VB", Task ="PAYMENT",TotalTask=1,TotalHandlingTime="01:00:00",AverageHandlingTime="01:00:00"}

            }.AsQueryable();
        }

        public static IQueryable<TaskTotals> GetTaskTotalReportList()
        {
            return new List<TaskTotals>()
            {
                new TaskTotals(){  TotalHandlingTime="01:00:00",TotalTaskCount=1},
                new TaskTotals(){ TotalHandlingTime="01:00:00",TotalTaskCount=3}

            }.AsQueryable();
        }

        internal static IQueryable<LoginLogoutReport> GetLoginLoguttList()
        {
            return new List<LoginLogoutReport>()
            {
                new LoginLogoutReport(){ UserId=6, UserName = "Dhananjay Hole", LoginTime =DateTimeHelper.Now ,StrLoginTime=DateTimeHelper.Now.ToString(),LogoutTime=DateTimeHelper.Now.AddHours(8), StrLogoutTime=DateTimeHelper.Now.AddHours(8).ToString(),Duration="08:00:00"},
                new LoginLogoutReport(){ UserId=1, UserName = "Shriyansh", LoginTime =DateTimeHelper.Now ,StrLoginTime=DateTimeHelper.Now.ToString(),LogoutTime=DateTimeHelper.Now.AddHours(8), StrLogoutTime=DateTimeHelper.Now.AddHours(8).ToString(),Duration="08:00:00"},
                new LoginLogoutReport(){ UserId=2, UserName = "Abhishek", LoginTime =DateTimeHelper.Now ,StrLoginTime=DateTimeHelper.Now.ToString(),LogoutTime=DateTimeHelper.Now.AddHours(8), StrLogoutTime=DateTimeHelper.Now.AddHours(8).ToString(),Duration="08:00:00"},
                new LoginLogoutReport(){ UserId=3, UserName = "Satya", LoginTime =DateTimeHelper.Now ,StrLoginTime=DateTimeHelper.Now.ToString(),LogoutTime=DateTimeHelper.Now.AddHours(8), StrLogoutTime=DateTimeHelper.Now.AddHours(8).ToString(),Duration="08:00:00"}

            }.AsQueryable();
        }

        public static IQueryable<MstAuxCode> GetMstAuxCode()
        {
            return new List<MstAuxCode>()
            {
                new MstAuxCode(){ Id = 1, ActivityName = "Break1", CreatedBy = 1, ModifiedBy = 1, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstAuxCode(){ Id = 2, ActivityName = "Lunch", CreatedBy = 1, ModifiedBy = 1, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstAuxCode(){ Id = 3, ActivityName = "Snacks", CreatedBy = 1, ModifiedBy = 1, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstAuxCode(){ Id = 4, ActivityName = "Meeting", CreatedBy = 1, ModifiedBy = 1, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstAuxCode(){ Id = 5, ActivityName = "Discussions", CreatedBy = 1, ModifiedBy = 1, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now }
            }.AsQueryable();
        }

        public static IQueryable<MstActivity> GetmstActivities()
        {
            return new List<MstActivity>()
            {
                new MstActivity(){ Id = 1,DepartmnetId=1,ParentId=0, ActivityName = "C2L",ActivityGroup="Scheme", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstActivity(){ Id = 2,DepartmnetId=1,ParentId=0, ActivityName = "VB",ActivityGroup="Scheme", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstActivity(){ Id = 3,DepartmnetId=1,ParentId=0, ActivityName = "PCDL",ActivityGroup="Scheme", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstActivity(){ Id = 4,DepartmnetId=1,ParentId=1, ActivityName = "ADVANCE PAYMENT",ActivityGroup="Task", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstActivity(){ Id = 5,DepartmnetId=1,ParentId=2, ActivityName = "AMENDEIORG",ActivityGroup="Task", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MstActivity(){ Id = 6,DepartmnetId=1,ParentId=3, ActivityName = "BANKDEC",ActivityGroup="Task", STT=60, CreatedBy = 1, ModifiedBy = 1,IsActive=true, CreatedDate =DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now }
            }.AsQueryable();
        }

        public static IQueryable<MstActivityGroup> GetActivityGroup()
        {
            return new List<MstActivityGroup>()
            {
                new MstActivityGroup(){ Id = 1,GroupName="Scheme"},
                new MstActivityGroup(){ Id = 2,GroupName="Task"},
                new MstActivityGroup(){ Id = 3,GroupName="CallCode"},
                new MstActivityGroup(){ Id = 4,GroupName="CallResolution"}
            }.AsQueryable();
        }

        public static IQueryable<MappingUserDepartment> GetMappingUserDepartment()
        {
            return new List<MappingUserDepartment>()
            {
                new MappingUserDepartment() { Id =1, DepartmentId = 1, RoleId = 1, UserId = 2, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id =2, DepartmentId = 1, RoleId = 2, UserId = 2, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id =3, DepartmentId = 2, RoleId = 1, UserId = 2, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id =4, DepartmentId = 1, RoleId = 1, UserId = 1, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id =5, DepartmentId = 1, RoleId = 2, UserId = 1, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id =6, DepartmentId = 2, RoleId = 1, UserId = 1, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now }
            }.AsQueryable();
        }

        public static IQueryable<MappingRoleNavigation> GetMappingRoleNavigation()
        {
            return new List<MappingRoleNavigation>()
            {
                new MappingRoleNavigation(){ Id = 1,  DepartmentId = 1, RoleId = 1, NavigationId =1 },
                new MappingRoleNavigation(){ Id = 2,  DepartmentId = 1, RoleId = 1, NavigationId =2 },
                new MappingRoleNavigation(){ Id = 3,  DepartmentId = 1, RoleId = 1, NavigationId =3 },
                new MappingRoleNavigation(){ Id = 4,  DepartmentId = 1, RoleId = 1, NavigationId =4 },
                new MappingRoleNavigation(){ Id = 5,  DepartmentId = 1, RoleId = 1, NavigationId =5 },
                new MappingRoleNavigation(){ Id = 6,  DepartmentId = 1, RoleId = 1, NavigationId =6 },
                new MappingRoleNavigation(){ Id = 7,  DepartmentId = 1, RoleId = 2, NavigationId =1 },
                new MappingRoleNavigation(){ Id = 8,  DepartmentId = 1, RoleId = 2, NavigationId =2 },
                new MappingRoleNavigation(){ Id = 9,  DepartmentId = 1, RoleId = 2, NavigationId =3 },
                new MappingRoleNavigation(){ Id = 10, DepartmentId = 1, RoleId = 2, NavigationId =4 },
                new MappingRoleNavigation(){ Id = 11, DepartmentId = 1, RoleId = 2, NavigationId =5 },
                new MappingRoleNavigation(){ Id = 12, DepartmentId = 1, RoleId = 3, NavigationId =1 },
                new MappingRoleNavigation(){ Id = 13, DepartmentId = 1, RoleId = 3, NavigationId =2 },
                new MappingRoleNavigation(){ Id = 14, DepartmentId = 1, RoleId = 3, NavigationId =3 }
            }.AsQueryable();
        }

        public static IQueryable<MstDepartment> GetDepartments()
        {
            return new List<MstDepartment>()
            {
                new MstDepartment(){ Id = 1, Name = "SSBS", IsActive = true, CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate=DateTimeHelper.Now } ,
                new MstDepartment(){ Id = 2, Name = "PCSC", IsActive = true, CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate=DateTimeHelper.Now}
            }.AsQueryable();
        }

        public static IQueryable<MstRole> GetRoles()
        {
            return new List<MstRole>()
            {
                new MstRole(){ Id = 1, Name = "Advisor", CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate=DateTimeHelper.Now } ,
                new MstRole(){ Id = 2, Name = "Manager", CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate=DateTimeHelper.Now},
                new MstRole(){ Id = 3, Name = "Administrator", CreatedBy = 1, ModifiedBy = 1, CreatedDate = DateTimeHelper.Now, ModifiedDate=DateTimeHelper.Now}
            }.AsQueryable();
        }

        public static List<UserPrimaryDetails> GetUserPrimaryDetails()
        {
            return new List<UserPrimaryDetails>()
            {
                new UserPrimaryDetails() {
                    Id = 1,  FirstName = "u1f",   LastName = "u1l",  LanId = "CAPITA\\P1111",  EmployeeId = "1111",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "a@a.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 2,  FirstName = "u2f",   LastName = "u2l",  LanId = "CAPITA\\P2222",  EmployeeId = "2222",  DepartmentId =  2, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "b@b.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 3,  FirstName = "u3f",   LastName = "u3l",  LanId = "CAPITA\\P3333",  EmployeeId = "3333",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "c@c.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                }
            };
        }

        public static List<UserPrimaryDetails> GetUserPrimaryDetailsForReport()
        {
            return new List<UserPrimaryDetails>()
            {
                new UserPrimaryDetails() {
                    Id = 1,  FirstName = "u1f",   LastName = "u1l",  LanId = "CAPITA\\P1111",  EmployeeId = "1111",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "a@a.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 2,  FirstName = "u2f",   LastName = "u2l",  LanId = "CAPITA\\P2222",  EmployeeId = "2222",  DepartmentId =  2, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "b@b.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 3,  FirstName = "u3f",   LastName = "u3l",  LanId = "CAPITA\\P3333",  EmployeeId = "3333",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "c@c.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                 new UserPrimaryDetails() {
                    Id = 6,  FirstName = "Dhananjay",   LastName = "Hole",  LanId = "CAPITA\\P10322047",  EmployeeId = "10322047",  DepartmentId =  1, TimeZone =  "India Standard Time", ManagerId = null, EmailId = "c@c.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                }
            };
        }

        public static List<MappingUserDepartment> GetMappingUserDepartment_1()
        {
            return new List<MappingUserDepartment>()
            {
                new MappingUserDepartment() { Id = 1, DepartmentId = 1, UserId = 1, RoleId = 1, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id = 2, DepartmentId = 1, UserId = 1, RoleId = 2, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id = 3, DepartmentId = 2, UserId = 2, RoleId = 2, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id = 4, DepartmentId = 2, UserId = 2, RoleId = 3, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now },
                new MappingUserDepartment() { Id = 5, DepartmentId = 1, UserId = 3, RoleId = 1, CreatedBy = 1, ModifiedBy = 1 , CreatedDate = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now }

            };
        }

        public static List<UserLoggedIn> GetLstUserLoggedIn()
        {
            return new List<UserLoggedIn>()
            {
                new UserLoggedIn() { Id = 6, UserId = 1, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = null },
                new UserLoggedIn() { Id = 7, UserId = 2, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = null },
                new UserLoggedIn() { Id = 8, UserId = 3, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = null },
                new UserLoggedIn() { Id = 9, UserId = 4, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = DateTimeHelper.Now.AddHours(1)},
                new UserLoggedIn() { Id = 10, UserId = 5, DepartmentId = 2, LoggedIn = DateTimeHelper.Now, LoggedOut = null }
            };
        }

        public static List<MstDepartment> GetLstMstDepartment()
        {
            return new List<MstDepartment>()
            {
                new MstDepartment() { Id = 1, Name = "SBSS", CreatedDate = DateTimeHelper.Now, CreatedBy = 1, ModifiedDate = DateTimeHelper.Now, ModifiedBy = 1, IsActive = true },
                new MstDepartment() { Id = 2, Name = "Prudential", CreatedDate = DateTimeHelper.Now, CreatedBy = 1, ModifiedDate = DateTimeHelper.Now, ModifiedBy = 1, IsActive = true },
                new MstDepartment() { Id = 3, Name = "sbss2", CreatedDate = DateTimeHelper.Now, CreatedBy = 1, ModifiedDate = DateTimeHelper.Now, ModifiedBy = 1, IsActive = true }
            };
        }

        public static UserPrimaryDetails GetCurrentLoggedInUser()
        {
            return new UserPrimaryDetails()
            {
                Id = 1,
                FirstName = "u1f",
                LastName = "u1l",
                LanId = "CAPITA\\P1111",
                EmployeeId = "1111",
                DepartmentId = 1,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "a@a.com",
                CreatedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };
        }

        public static UserPrimaryDetails GetAddUserData()
        {
            return new UserPrimaryDetails()
            {
                FirstName = "u4f",
                LastName = "u4l",
                LanId = "CAPITA\\P4444",
                EmployeeId = "4444",
                DepartmentId = 0,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "d@d.com",
                CreatedBy = 1,
                ModifiedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };
        }

        public static UserDetails GetAddUserAndDeptData()
        {
            return new UserDetails()
            {
                FirstName = "u4f",
                LastName = "u4l",
                LanId = "CAPITA\\P4444",
                EmployeeId = "4444",
                DepartmentId = 0,
                TimeZone = "GMT Standard Time",
                ManagerId = null,
                EmailId = "d@d.com",
                CreatedBy = 1,
                ModifiedBy = 1,
                CreatedDate = DateTimeHelper.Now,
                ModifiedDate = DateTimeHelper.Now,
                IsActive = true
            };
        }

        public static NonCoreActivityJourney GetNonCoreActivity()
        {
            return new NonCoreActivityJourney()
            {
                Id = 1,
                AuxCodeId = 1,
                DepartmentId = 1,
                UserId = 2,
                Duration = 0,
                StartTime = DateTimeHelper.Now,
                EndTime = null,
                Comment = string.Empty
            };
        }

        public static NonCoreActivityJourney GetNonCoreActivityWhereEndTimeIsNotNull()
        {
            return new NonCoreActivityJourney()
            {
                Id = 1,
                AuxCodeId = 1,
                DepartmentId = 1,
                UserId = 2,
                Duration = 0,
                StartTime = DateTimeHelper.Now,
                EndTime = DateTimeHelper.Now,
                Comment = string.Empty
            };
        }

        public static List<UserPrimaryDetails> GetAllUsers()
        {
            return new List<UserPrimaryDetails>()
            {
                new UserPrimaryDetails() {
                    Id = 1,  FirstName = "Shriyansh",   LastName = "Jain",  LanId = "capita\\p10359078",  EmployeeId = "10359078",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "a@a.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 2,  FirstName = "u2f",   LastName = "u2l",  LanId = "CAPITA\\P2222",  EmployeeId = "2222",  DepartmentId =  2, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "b@b.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 3,  FirstName = "u3f",   LastName = "u3l",  LanId = "CAPITA\\P3333",  EmployeeId = "3333",  DepartmentId =  1, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "c@c.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                }
            };
        }

        public static List<UserPrimaryDetails> GetAllUsersWhereDeptNotAssigned()
        {
            return new List<UserPrimaryDetails>()
            {
                new UserPrimaryDetails() {
                    Id = 1,  FirstName = "Shriyansh",   LastName = "Jain",  LanId = "capita\\p10359078",  EmployeeId = "10359078",  DepartmentId =  0, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "a@a.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 2,  FirstName = "u2f",   LastName = "u2l",  LanId = "CAPITA\\P2222",  EmployeeId = "2222",  DepartmentId =  0, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "b@b.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                },
                new UserPrimaryDetails() {
                    Id = 3,  FirstName = "u3f",   LastName = "u3l",  LanId = "CAPITA\\P3333",  EmployeeId = "3333",  DepartmentId =  0, TimeZone =  "GMT Standard Time", ManagerId = null, EmailId = "c@c.com",
                    CreatedBy = 1, ModifiedBy = 1, CreatedDate  = DateTimeHelper.Now, ModifiedDate = DateTimeHelper.Now, IsActive = true
                }
            };
        }

        public static List<UserLoggedIn> GetAllUserLoggedIn()
        {
            return new List<UserLoggedIn>()
            {
                new UserLoggedIn() {
                    Id = 1, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = null, UserId = 1
                },
                new UserLoggedIn() {
                    Id = 2, DepartmentId = 1, LoggedIn = DateTimeHelper.Now, LoggedOut = null, UserId = 2
                }
            };
        }

        public static List<UserCurrentActivity> GetUserCurrentActivity()
        {
            return new List<UserCurrentActivity>()
            {
                new UserCurrentActivity() {
                    Id = 1, DepartmentId = 1, UserId = 1 , StartTime= DateTimeHelper.Now, SubActivity = string.Empty
                },
                new UserCurrentActivity() {
                    Id = 2, DepartmentId = 1, UserId = 2, StartTime= DateTimeHelper.Now, SubActivity = string.Empty
                }
            };
        }

        public static IQueryable<MstNavigation> GetMstNavigation()
        {
            return new List<MstNavigation>()
            {
                new MstNavigation(){ Id = 1, DisplayName = "Dashboard", IsActive = true, ParentId = 0, SortOrder = 1, SourceUrl = "#/Home" },
                new MstNavigation(){ Id = 2, DisplayName = "Manager Dashboard", IsActive = true, ParentId = 0, SortOrder = 2, SourceUrl = "#/LineManagerDashboard" },
                new MstNavigation(){ Id = 3, DisplayName = "RTA", IsActive = true, ParentId = 0, SortOrder = 3, SourceUrl = "#/rta" },
                new MstNavigation(){ Id = 4, DisplayName = "Setting", IsActive = true, ParentId = 0, SortOrder = 4, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 5, DisplayName = "User Management", IsActive = true, ParentId = 0, SortOrder = 5, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 6, DisplayName = "Reports", IsActive = true, ParentId = 0, SortOrder = 6, SourceUrl = "#/reports" },
                new MstNavigation(){ Id = 7, DisplayName = "Add Role", IsActive = true, ParentId = 5, SortOrder = 7, SourceUrl = "#/addrole" }
            }.AsQueryable();
        }

        public static List<RealTimeDashboard> GetRealTimeDashboard(DateTime startDate, DateTime endDate)
        {
            return new List<RealTimeDashboard>()
            {
                new RealTimeDashboard()
                {
                    Name = "Abhishek Das",
                    ActivityName =  "Idle",
                    Comment = "",
                    StartTime =  startDate.AddHours(1),
                    EndTime = startDate.AddHours(2),
                    ConsumeTime = "01:00:00",
                    StrEndTime = "",
                    StrStartTime = ""
                }
            };
        }

        public static List<CoreNonCoreTime> GetLstCoreNonCoreTime_user1()
        {
            return new List<CoreNonCoreTime>()
            {
                new CoreNonCoreTime()
                {
                    Name = "Call",
                    Hours = 0.15m
                },
                new CoreNonCoreTime()
                {
                    Name = "Core",
                    Hours = 0.06m
                },
                new CoreNonCoreTime()
                {
                    Name = "Idle",
                    Hours = 0.41m
                },
                new CoreNonCoreTime()
                {
                    Name = "WebChat",
                    Hours = 0.09m
                }
            };
        }

        public static List<CoreNonCoreTime> GetLstCoreNonCoreTime_allUser()
        {
            return new List<CoreNonCoreTime>()
            {
                new CoreNonCoreTime()
                {
                    Name = "Break",
                    Hours = 0.02m
                },
                new CoreNonCoreTime()
                {
                    Name = "Call",
                    Hours = 0.54m
                },
                new CoreNonCoreTime()
                {
                    Name = "Core",
                    Hours = 0.26m
                },
                new CoreNonCoreTime()
                {
                    Name = "Idle",
                    Hours = 19.48m
                },
                new CoreNonCoreTime()
                {
                    Name = "WebChat",
                    Hours = 0.27m
                }
            };
        }

        public static List<EmployeesCoreNonCoreData> GetLstEmployeesCoreNonCoreData_user1()
        {
            return new List<EmployeesCoreNonCoreData>()
            {
                new EmployeesCoreNonCoreData()
                {
                    UserId = 1,
                    Name = "u1f u1l",
                    Core = "00:01:41",
                    NonCore = "01:51:29"
                }
            };
        }

        public static List<EmployeesCoreNonCoreData> GetLstEmployeesCoreNonCoreData_allUser()
        {
            return new List<EmployeesCoreNonCoreData>()
            {
                new EmployeesCoreNonCoreData()
                {
                    UserId = 1,
                    Name = "u1f u1l",
                    Core = "00:01:41",
                    NonCore = "01:51:29"
                },
                new EmployeesCoreNonCoreData()
                {
                    UserId = 2,
                    Name = "u2f u2l",
                    Core = "00:11:10",
                    NonCore = "05:00:00"
                }
            };
        }
        public static List<UserCurrentStatistics> GetLstUserCurrentStatistics_user1()
        {
            return new List<UserCurrentStatistics>()
            {
                new UserCurrentStatistics()
                {
                   ActivityType = "Core",
                   TaskCount = 1
                },
                new UserCurrentStatistics()
                {
                   ActivityType = "None",
                   TaskCount = 0
                }
            };
        }

        public static List<UserCurrentStatistics> GetLstUserCurrentStatistics_allUser()
        {
            return new List<UserCurrentStatistics>()
            {
                new UserCurrentStatistics()
                {
                   ActivityType = "Call",
                   TaskCount = 6
                },
                new UserCurrentStatistics()
                {
                   ActivityType = "Core",
                   TaskCount = 11
                },
                new UserCurrentStatistics()
                {
                   ActivityType = "OutboundCall",
                   TaskCount = 4
                },
                 new UserCurrentStatistics()
                {
                   ActivityType = "WebChat",
                   TaskCount = 7
                },
                new UserCurrentStatistics()
                {
                   ActivityType = "None",
                   TaskCount = 0
                }
            };
        }

        public static List<RealTimeDashboard> GetLstRealTimeDashboard_user1(DateTime startDate)
        {
            return new List<RealTimeDashboard>()
            {
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_1",
                    StartTime = startDate,
                    EndTime = startDate.AddHours(1),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_2",
                    StartTime = startDate.AddHours(1),
                    EndTime = startDate.AddHours(2),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_3",
                    StartTime = startDate.AddHours(2),
                    EndTime = startDate.AddHours(3),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_4",
                    StartTime = startDate.AddHours(3),
                    EndTime = startDate.AddHours(4),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_5",
                    StartTime = startDate.AddHours(4),
                    EndTime = startDate.AddHours(5),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_6",
                    StartTime = startDate.AddHours(5),
                    EndTime = startDate.AddHours(6),
                    ConsumeTime = "01:00:00"
                }
            };
        }

        public static List<RealTimeDashboard> GetLstRealTimeDashboard_allUser(DateTime startDate)
        {
            return new List<RealTimeDashboard>()
            {
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_1",
                    StartTime = startDate,
                    EndTime = startDate.AddHours(1),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_2",
                    StartTime = startDate.AddHours(1),
                    EndTime = startDate.AddHours(2),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_3",
                    StartTime = startDate.AddHours(2),
                    EndTime = startDate.AddHours(3),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_4",
                    StartTime = startDate.AddHours(3),
                    EndTime = startDate.AddHours(4),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_5",
                    StartTime = startDate.AddHours(4),
                    EndTime = startDate.AddHours(5),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u1f u1l",
                    ActivityName = "Idle",
                    Comment = "comm_6",
                    StartTime = startDate.AddHours(5),
                    EndTime = startDate.AddHours(6),
                    ConsumeTime = "01:00:00"
                },
                new RealTimeDashboard()
                {
                    Name = "u2f u2l",
                    ActivityName = "Idle",
                    Comment = "comm_7",
                    StartTime = startDate.AddHours(6),
                    EndTime = startDate.AddHours(7),
                    ConsumeTime = "01:00:00"
                }
            };
        }
    }
}
