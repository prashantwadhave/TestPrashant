﻿using System;
using System.Configuration;
using System.Data.Entity;
using Capita.Core.Models;
using Capita.Core.Contracts;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Data.Entity.ModelConfiguration;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Data
{

    public class DataContext : DbContext, IDataContext
    {
        public DbSet<AppException> AppException { get; set; }

        public DbSet<MstAuxCode> MstAuxCode { get; set; }

        public DbSet<MstDepartment> MstDepartment { get; set; }

        public DbSet<MstRole> MstRole { get; set; }

        public DbSet<UserPrimaryDetails> UserPrimaryDetails { get; set; }

        public DbSet<NonCoreActivityJourney> NonCoreActivityJourney { get; set; }

        public DbSet<CoreActivityJourney> CoreActivityJourney { get; set; }

        public DbSet<UserLoggedIn> UserLoggedIn { get; set; }

        public DbSet<UserCurrentActivity> UserCurrentActivity { get; set; }

        public DbSet<MstNavigation> MstNavigation { get; set; }

        public DbSet<MappingAuxCodeDepartment> MappingAuxCodeDepartment { get; set; }

        public DbSet<MappingUserDepartment> MappingUserDepartment { get; set; }

        public DbSet<MappingRoleNavigation> MappingDepartmentRoleNavigation { get; set; }

        public DbSet<UserLogs> UserLogs { get; set; }

        public DbSet<MstActivity> MstActivity { get; set; }
        public DbSet<Calls> Calls { get; set; }
        public DbSet<MstActivityGroup> MstActivityGroup { get; set; }
        public DbSet<MstTeam> MstTeam { get; set; }

        public DataContext() : base(ConnenctionStringProject)
        {
            Database.SetInitializer<DataContext>(null);
        }

        public static string ConnenctionStringProject
        {
            get
            {
                return Convert.ToString(Settings.DBConnectionString.ConnectionString);
            }
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }

}
