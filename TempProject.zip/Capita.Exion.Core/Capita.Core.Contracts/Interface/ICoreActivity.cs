﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;

namespace Capita.Core.Contracts
{
    public interface ICoreActivity
    {        
        List<CoreActivity> GetCoreActivities(int departmentId, DateTime startDate, DateTime endDate, string lanId);

        int AddCoreActivity(CoreActivityJourney coreActivity, int activeNonCoreActivityId, string lanId);

        int UpdateCoreActivity(CoreActivityJourney coreActivityJourney);

        CoreActivityJourney GetCurrentActivity(int userId, int departmentId, string activityType);
    }
}
