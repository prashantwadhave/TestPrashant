﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface IWebChat
    {
        int AddWebChatActivity(int departmentId, string comment, int activeNonCoreActivityId, string lanId, int teamId);

        int UpdateWebChatActivity(int webChatID, string comment, bool isCoreActivtyStarted, bool isCallActivtyStarted, bool isOutBoundActivtyStarted);
    }
}
