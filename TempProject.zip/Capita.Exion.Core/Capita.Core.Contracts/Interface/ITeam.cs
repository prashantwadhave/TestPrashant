﻿using System;
using System.Collections.Generic;
using Capita.Core.Models.DataModels;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
  public interface ITeam
    {

        List<MstTeam> GetAllTeamsByDepartment(int departmentId);       
        MstTeam GetTeamById(int id);
        bool AddTeam(MstTeam team, string createdBy);
        bool UpdateTeam(MstTeam team, string modifiedBy);
        bool DeleteTeamById(int id, string modifiedBy);
        bool CheckTeamExists(string teamName, int DepartmentId);
        bool CheckTeamExists(MstTeam team);
        List<MstTeam> GetAllTeamsByUserId(int userId, int departmentId);

    }
}
