﻿using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface INonCoreActivity
    {
        int AddActivity(NonCoreActivityJourney nonCoreActivityJourney, int userId, int activeNonCoreActivityId);

        int UpdateActivity(string activeNonCoreActivityId, string comments, bool isAnyCoreActivtyStarted);
    }
}
