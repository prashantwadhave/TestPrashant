﻿using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts
{
    public interface IMappingDepartmentRoleNavigation
    {
        IEnumerable<MappingDepartmentRoleNavigation> GetAllMappingDepartmentRoleNavigation();

        MappingDepartmentRoleNavigation GetMappingDepartmentRoleNavigationById(int id);

        bool AddMappingDepartmentRoleNavigation(MappingDepartmentRoleNavigation mappingUserDepartment);

        bool UpdateMappingDepartmentRoleNavigation(MappingDepartmentRoleNavigation mappingUserDepartment);

        bool DeleteMappingDepartmentRoleNavigationById(int id);
    }
}
