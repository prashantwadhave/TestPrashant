﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System.Collections.Generic;

namespace Capita.Core.Contracts
{
    public interface IAuxCode
    {
        IEnumerable<MstAuxCode> GetAllAuxCodeList();
        IEnumerable<MstAuxCode> GetAllAssignedAuxCode(int departmentId);
        IEnumerable<MstAuxCode> GetAllAuxCode(int departmentId);
        IEnumerable<AuxCodeDepartment> GetAllAuxCodeDepartment(int departmentId, int auxCodeId);

        MstAuxCode GetAuxCodeById(int id);

        bool AddAuxCode(MstAuxCode auxCode, UserPrimaryDetails createdBy);

        bool UpdateAuxCode(MstAuxCode auxCode, UserPrimaryDetails modifiedBy);

        bool DeleteAuxCodeById(int id);
        bool CheckAuxCodeExists(MstAuxCode auxcode);
        List<KeyValuePair> GetAllAuxCode();
        List<KeyValuePair> GetDepartmentsWhichDontHaveSelectedAuxCode(int auxCodeId);
        bool AddUpdateMappingAuxCodeDepartment(int auxCodeId, int departmentId);
        bool DeleteMapAuxCodeAndDepartment(int auxCodeId, int departmentId);
        bool CheckMappingExistsAuxCodeAndDepartment(int auxCodeId, int departmentId);


    }
}
