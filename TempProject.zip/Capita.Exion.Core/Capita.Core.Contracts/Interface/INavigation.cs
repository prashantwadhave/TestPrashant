﻿using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts
{
    public interface INavigation
    {
        List<MstNavigation> GetAllNavigations(int departmentId, string lanId);

        //MstNavigation GetNavigationById(int id);

        //bool AddNavigation(MstNavigation department);

        //bool UpdateNavigation(MstNavigation department);

        //bool DeleteNavigationById(int id);
    }
}
