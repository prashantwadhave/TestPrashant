﻿using Capita.Core.Models.DataModels;
using System.Collections.Generic;

namespace Capita.Core.Contracts
{
    public interface IRole
    {
        IEnumerable<MstRole> GetAllRoles(int departmentId);

        MstRole GetRoleById(int id);

        bool AddRole(MstRole role);

        bool UpdateRole(MstRole role);

        bool DeleteRoleById(int id);
    }
}
