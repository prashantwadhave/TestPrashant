﻿using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts
{
    public interface IDepartment
    {
        IEnumerable<MstDepartment> GetAllDepartments(string lanId);
        IEnumerable<MstDepartment> GetAllDepartmentsInApp();

        MstDepartment GetDepartmentById(int id);

        bool AddDepartment(MstDepartment department, UserPrimaryDetails createdBy);

        bool UpdateDepartment(MstDepartment department, UserPrimaryDetails modifiedBy);

        bool DeleteDepartmentById(int id, UserPrimaryDetails modifiedBy);
        bool CheckDepartmentExists(string departmentName);
        bool CheckDepartmentExists(MstDepartment department);
    }
}
