﻿using Capita.Core.Models;
using System;
using System.Collections.Generic;

namespace Capita.Core.Contracts
{
    public interface IEmailService
    {
        bool SendEmail(string emailTo, string emailCC, string msgSubject, string msgBody);
    }
}
