﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts
{
    public interface IDashboard
    {
        List<RealTimeDashboard> GetRealTimeDashboard(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);
        List<RealTimeDashboard> GetRealTimeDashboardLM(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int skip, int pageSize, string searchValue, int teamId,out int totalCount);
        ProductiveNonProductiveHours GetProductiveNonProductive(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);
        List<CoreNonCoreTime> GetCoreNonCoreTime(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);
        List<EmployeesCoreNonCoreData> GetEmployeesCoreNonCoreData(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);
        List<UserCurrentStatistics> GetUserCurrentStatistic(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);
    }
}
