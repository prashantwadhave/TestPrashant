﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts
{
    public interface IMappingUserDepartment
    {
        IEnumerable<MappingUserDepartment> GetAllMappingUserDepartment();

        IEnumerable<DisplayUserDepartmentRole> GetUserDepartmentRolesByUserId(int userId, int departmentId);
        IEnumerable<DisplayUserDepartmentRole> GetUserDepartmentRolesByUserIdForAdmin(int userId);

        IEnumerable<DisplayUserDepartmentRole> AddMappingUserDepartment(UserDepartmentRoles userDepartmentRoles, string lanId);
        IEnumerable<DisplayUserDepartmentRole> AddMappingUserDepartmentForAdmin(UserDepartmentRoles userDepartmentRoles, string lanId);

        MastersData GetAllUserRoleDepartment(string lanId, int departmentId);

        IEnumerable<DisplayUserDepartmentRole> DeleteMappingUserDepartmentById(int id, int userId);
        IEnumerable<DisplayUserDepartmentRole> DeleteMappingUserDepartmentByIdForAdmin(int id, int userId);

        MastersData GetAllUserRoleDepartment(string lanId);
    }
}
