﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface IOutbondCall
    {
        int AddOutboundCallActivity(int departmentId, string comment, int activeNonCoreActivityId, string lanId,int teamId);

        int UpdateOutboundCallActivity(int outboundCallId, string comment, bool isCoreActivtyStarted, bool isWebChatActivtyStarted);

    }
}
