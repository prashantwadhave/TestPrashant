﻿using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface ICommon
    {
        ActivityIds AddUserLoginDetails(NonCoreActivityJourney nonCoreActivityJourney, string lanId, bool isDepartmentOrRoleChanged);

        UserInfo IsUserAuthorized(string lanId);

        bool UpdateUserLogOutDetails(int departmentId, string lanId, int nonCoreActivityId, int userLogId);
        bool UpdateUserLogOutDetailsByUserLoggedInId(int departmentId, string UserLoggedInId, UserPrimaryDetails modifiedBy);

        UserAuthorizationDetail ChangeDepartment(int departmentId, string lanId, int nonCoreActivityId);
        List<TimeZoneCustom> GetTimezones();

        string ExportToExcel(DataTable dataTableToExport);
        
    }
}
