﻿using Capita.Core.Models;
using System;
using System.Collections.Generic;

namespace Capita.Core.Contracts
{
    public interface ILogger
    {
        IEnumerable<AppException> Get();
        int Log(Exception ex, string uid);
        int Log(string Info, string uid);
        int Log(AppException ex);
    }
}
