﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface IActivity
    {
        IEnumerable<Activity> GetActivity(int departmentId);
         MstActivity GetActivityById(int id);
        IList<Activity> GetAllActivities(int departmentId);
        bool AddActivity(MstActivity activity, UserPrimaryDetails createdBy);

        bool UpdateActivity(MstActivity activity, UserPrimaryDetails modifiedBy);

        bool DeleteActivityById(int id, UserPrimaryDetails modifiedBy);
        bool CheckActivityExists(string activityName);
        bool CheckActivityExists(MstActivity activity);

        IList<MstActivityGroup> GetActivityGroups();
    }
}
