﻿using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Data;

namespace Capita.Core.Contracts
{
    public interface IUser
    {
        IEnumerable<UserPrimaryDetails> GetAllUsers();
        IEnumerable<UserPrimaryDetails> GetAllUsersByDepartmentId(int departmentId);
        List<UserPrimaryDetails> GetUnassignedUserList(int departmentId);
        UserPrimaryDetails GetUserById(int id);

        bool AddUser(UserPrimaryDetails user, int createdByUserId);

        bool DeleteUserById(int id, int modifiedByUserId);

        int GetUserIdFromLanId(string lanId);

        void AddOrUpdateCurrentActivity(int userId, string activity, int auxCodeId, int departmentId, string coreSubActivityName,int? teamId);

        UserPrimaryDetails GetUserDetailsFromLanId(string lanId);

        IEnumerable<UserCurrentActivity> GetCurrentActivity(int departmentId);
        IEnumerable<ViewCurrentActivity> GetCurrentUsersActivity(int departmentId,string lanId,int teamId);

        IEnumerable<UserLoggedIn> GetLoggedInUserDetails(int departmentId);

        void AddUserLog(UserLogs user);

        IEnumerable<UserLogsCustom> GetUserLogs(int departmentId, DateTime startDate, DateTime endDate, string lanId);

        void UpdateUserLog(UserLogs user);

        UserLogs GetUserLog(int id);

        List<UserDeptLoggedInDetail> GetActiveSessionOfUsers(int departmentId, UserPrimaryDetails user);

        bool AddUserAndDept(UserDetails user);

        bool UpdateUserAndDept(UserPrimaryDetails user, int modifiedByUserId);
        List<KeyValuePair> GetEmployeesByManagerIdAndDepartmentId(int departmentId, int managerId);
        List<KeyValuePair> GetUsersByDepartmentId(int departmentId);
        bool CheckUserExists(string employeeId, string lanId);
        bool CheckUserExists(UserPrimaryDetails user);
        DynamicDataTable GetUserDataForToday(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId);

        IEnumerable<UserPrimaryDetails> RemoveUserFromDepartment(int userId, int updatedBy);
    }
}
