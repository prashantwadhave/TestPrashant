﻿using Capita.Core.Models.CustomModels;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Contracts.Interface
{
    public interface IReports
    {
        DataSet GetTaskAverage(int departmentId, DateTime startDate, DateTime endDate, string lanId, string Scheme, int teamId);
        DataSet GetAgentTaskAverage(int departmentId, DateTime startDate, DateTime endDate, string lanId, string userId, int teamId);
        List<ProductivityReport> GetProductivity(int departmentId, DateTime startDate, DateTime endDate, string lanId, string userId, int teamId);
        List<LoginLogoutReport> GetLoginLogoutReport(int departmentId, DateTime startDate, DateTime endDate, string lanId, int userId);
        List<STTReport> GetSTTRepot(int departmentId, DateTime startDate, DateTime endDate, string lanId, int teamId);
        List<CoreActivity> GetCoreActivities(int departmentId, DateTime startDate, DateTime endDate, string lanId, int skip, int pageSize, string searchValue, bool isExport, string Scheme, int userId, string ActivityType, int teamId, out int totalCount);
        List<CoreActivityReport> GetCoreActivitiesReport(int departmentId, DateTime startDate, DateTime endDate, string lanId, int skip, int pageSize, string searchValue, bool isExport, int teamId, out int totalCount);
        List<ActiveUsersReport> GetActiveUsers(int departmentId, DateTime startDate, DateTime endDate, string lanId);

    }
}
