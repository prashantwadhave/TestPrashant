﻿using Capita.Core.Models.CustomModels;
using System.Collections.Generic;

namespace Capita.Core.Models
{
    public class UserInfo
    {
        public UserInfo()
        {
            UserAccessibleUrls = new List<string>();
            UserTimeZoneDate = new UserTimeZoneDate();
        }

        public string FullName { get; set; }

        public string DepartmentName { get; set; }

        public int DepartmentId { get; set; }

        public int RoleId { get; set; }
        public int UserId { get; set; }

        public int? TeamId { get; set; }

        public bool IsUserSessionActiveInDB { get; set; }

        public bool HasMultipleDepartment { get; set; }

        public bool HasAdvisorRole { get; set; }

        public List<string> UserAccessibleUrls  { get; set; }

        public UserTimeZoneDate UserTimeZoneDate { get; set; }
    }
}
