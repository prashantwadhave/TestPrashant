﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class DynamicDataTable
    {
        public List<DynamicColumnDataTable> LstDynamicColumnDataTable { get; set; }
        public DataTable DtEmployees { get; set; }        
    }
}
