﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class TaskTotals
    {
        public int TotalTaskCount { get; set; }
        public string TotalHandlingTime { get; set; }
        public string TotalAverageHandlingTime { get; set; }
    }
}
