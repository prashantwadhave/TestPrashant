﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class UserDepartmentRoles
    {
        public int UserId { get; set; }

        public int DepartmentId { get; set; }

        public int TeamId { get; set; }


        public List<int> RoleIds { get; set; }

        public bool IsDefault { get; set; }
    }
}
