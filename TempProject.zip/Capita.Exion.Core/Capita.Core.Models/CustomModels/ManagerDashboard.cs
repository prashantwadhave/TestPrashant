﻿using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class ManagerDashboard
    {
        public List<RealTimeDashboard> LstRealTimeDashboard { get; set; }
        public List<ProductiveNonProductiveHours> LstProductiveNonProductiveHours { get; set; }
        public List<CoreNonCoreTime> LstCoreNonCoreTimeHours { get; set; }
        public List<KeyValuePair> LstEmployee { get; set; }

        public ManagerDashboard()
        {
            LstRealTimeDashboard = new List<RealTimeDashboard>();
            LstProductiveNonProductiveHours = new List<ProductiveNonProductiveHours>();
            LstCoreNonCoreTimeHours = new List<CoreNonCoreTime>();
            LstEmployee = new List<KeyValuePair>();
        }
    }
}
