﻿using System;

namespace Capita.Core.Models.DataModels
{
    public class RealTimeDashboard
    {
        public string Name { get; set; }
        public string ActivityName { get; set; }
        public string Comment { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string StrStartTime { get; set; }
        public string StrEndTime { get; set; }
        public string ConsumeTime { get; set; }
    }
}
