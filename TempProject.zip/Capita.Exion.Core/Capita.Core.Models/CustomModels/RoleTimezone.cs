﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
    public class RoleTimezone
    {
        public List<MstRole> lstRoles { get; set; }
        public List<TimeZoneCustom> lstTimeZone { get; set; }
        public string DepartmentName { get; set; }
        public int DepartmentId { get; set; }
        public UserPrimaryDetails User { get; set; }
    }
}
