﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
   public class ProductivityReport
    {
        public string AgentName { get; set; }
        public string Timelogged  { get; set; }
        public string NonCoreDuration { get; set; }
        public string CoreDuration { get; set; }        
        public string Productivity { get; set; }
        public string IdleTime { get; set; }
    }
}
