﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class MapAuxCodeDept
    {
        public IEnumerable<AuxCodeDepartment> LstAuxCodeDepartment { get; set; }
        public List<KeyValuePair> LstDepartment { get; set; }
    }
}
