﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
   public class CallsReport
    {
        public string AgentName { get; set; }
        public int UserId { get; set; }
        public int DepartmentId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string StrStartTime { get; set; }
        public string StrEndTime { get; set; }
        public string Duration { get; set; }
        public string Scheme { get; set; }
        public string CallCode { get; set; }
        public string CallCodeResolution { get; set; }
    }
}
