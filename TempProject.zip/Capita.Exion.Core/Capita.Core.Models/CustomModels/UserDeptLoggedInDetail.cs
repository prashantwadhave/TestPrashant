﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
    public class UserDeptLoggedInDetail
    {
        public int UserLoggedInId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string LanId { get; set; }
        public string EmployeeId { get; set; }
        public DateTime? LoggedIn { get; set; }
        public string StrLoggedIn { get; set; }
        public string DepartmentName { get; set; }
    }
}
