﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class STTReport
    {
        public string AgentName { get; set; }
        public string Activity { get; set; }
        public string Task { get; set; }
        public string Task_Count { get; set; }
        public string AHT { get; set; }
        public string STT { get; set; }
        public string Color { get; set; }
    }
}
