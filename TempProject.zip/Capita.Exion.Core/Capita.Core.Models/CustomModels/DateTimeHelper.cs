﻿using System;

namespace Capita.Core.Models.DataModels
{
    public static class DateTimeHelper
    {
        public static DateTime Now
        {
            get
            {
                //DateTime utcTime = DateTime.UtcNow;
                //TimeZoneInfo myZone = TimeZoneInfo.CreateCustomTimeZone("UK", new TimeSpan(0, 0, 0), "UK", "UK");
                //DateTime custDateTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, myZone);
                //return custDateTime;
                return DateTime.Now.ToUniversalTime();
            }
        }
    }
}
