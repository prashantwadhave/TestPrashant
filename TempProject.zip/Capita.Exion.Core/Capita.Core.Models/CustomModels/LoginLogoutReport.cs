﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class LoginLogoutReport
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public DateTime LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
        public string StrLoginTime { get; set; }
        public string StrLogoutTime { get; set; }

        public string Duration { get; set; }
    }
}
