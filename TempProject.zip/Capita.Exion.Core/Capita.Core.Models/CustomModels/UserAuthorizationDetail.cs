﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class UserAuthorizationDetail
    {
        public UserAuthorizationDetail()
        {
            UserAccessibleUrls = new List<string>();
        }

        public List<string> UserAccessibleUrls { get; set; }

        public bool HasAdvisorRole { get; set; }
        public int UserLogId { get; set; }
    }
}
