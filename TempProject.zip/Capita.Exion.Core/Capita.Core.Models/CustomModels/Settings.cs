﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models
{
    public static class Settings
    {
        public static class DBConnectionString
        {
            public static string ConnectionString { get { return ConfigurationManager.ConnectionStrings["CoreDataContext"].ToString(); } }
        }

        public static class AppSetting
        {
            public static string DisplayDateFormat { get { return ConfigurationManager.AppSettings["DisplayDateFormat"].ToString(); } }
            public static string DisplayDateFormatWithTime { get { return ConfigurationManager.AppSettings["DisplayDateFormatWithTime"] != null ? ConfigurationManager.AppSettings["DisplayDateFormatWithTime"].ToString() : "dd-MMM-yyyy hh:mm:ss tt"; } }
            public static string MonthDateFormat { get { return ConfigurationManager.AppSettings["MonthDateFormat"].ToString(); } }
            public static string SmtpServer { get { return ConfigurationManager.AppSettings["SmtpServer"].ToString(); } }
            public static int Port { get { return Convert.ToInt16(ConfigurationManager.AppSettings["Port"]); } }
            public static string FromAddress { get { return ConfigurationManager.AppSettings["FromAddress"].ToString(); } }
            public static string FromAddressTitle { get { return ConfigurationManager.AppSettings["FromAddressTitle"].ToString(); } }
            public static string ExceptionDL { get { return ConfigurationManager.AppSettings["ExceptionDL"].ToString(); } }
            public static bool IsExceptionMailRequired { get { return Convert.ToBoolean(ConfigurationManager.AppSettings["IsExceptionMailRequired"]); } }

        }

        public static class Constants
        {
            public const string NonCoreActivity = "Non-Core";

            public const string CoreActivity = "Core";

            public const string OutbondCall = "OutboundCall";

            public const string Call = "Call";

            public const string WebChat = "WebChat";

            public const int IdleActivityId = 1;

            public const string Login = "Login";

            public const string LogOut = "LogOut";

            public const string SessionKilledForcefully = "SessionKilledForcefully";

            public const int AdvisorRoleId = 1;

            public const string AdvisorRoleName = "Advisor";

            public const int ManagerRoleId = 2;

            public const string ManagerRoleName = "Manager";

            public const int AdminRoleId = 3;

            public const string AdminRoleName = "Administrator";

            public const int DashboardNavigationId = 1;

            public const int ManagerDashboard = 13;

            public const int RTA_Dashboard = 14;

            public const int UserManagement = 2;

            public const int AddUser = 3;

            public const int AddRole = 4;

            public const int LoggedInUser = 5;

            public const int Settings = 11;

            public const int AddDepartment = 12;

            public const int AddActivity = 15;

            public const int AddAuxCode = 16;

            public const int Reports = 7;

            public const int LoginLogoutReport = 6;

            public const int NonCoreActivityReport = 17;

            public const int CoreActivityReport = 18;

            public const int STTReport = 19;

            public const int ActiveUserReport = 20;

            public const int AddTeam = 22;

            public const int AddAdmin = 23;

            public const int BreakAuxCodeId = 3;

            public const int LunchAuxCodeId = 2;

            public const int DiscussionAuxCodeId = 7;
        }
    }
}
