﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class UserDetails
    {
        public String EmployeeId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public int DepartmentId { get; set; }
        public int? TeamId { get; set; }

        public String EmailId { get; set; }

        public String LanId { get; set; }

        public DateTime? CreatedDate { get; set; }

        public int CreatedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public int ModifiedBy { get; set; }

        public string TimeZone { get; set; }
        public bool IsActive { get; set; }
        public int? ManagerId { get; set; }

        public int CreatedByUserId { get; set; }
    }
}
