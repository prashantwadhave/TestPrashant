﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class AuxCodeDepartment
    {
        public int MappingAuxCodeDepartmentId { get; set; }
        public int AuxCodeId { get; set; }
        public string ActivityName { get; set; }
        public string DepartmentName { get; set; }
        public bool IsActive { get; set; }
    }
}
