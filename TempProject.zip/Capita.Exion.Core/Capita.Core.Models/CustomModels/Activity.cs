﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class Activity
    {
        public int Id { get; set; }

        public int DepartmnetId { get; set; }

        public int ParentId { get; set; }

        public string ActivityName { get; set; }

        public string ActivityGroup { get; set; }

        public int STT { get; set; }

        public string ParentActivityName { get; set; }

        public bool IsActive { get; set; }
    }
}
