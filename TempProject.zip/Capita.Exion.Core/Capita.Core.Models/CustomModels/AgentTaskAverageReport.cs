﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
   public class AgentTaskAverageReport
    {
        public string AgentName { get; set; }
        public string Scheme { get; set; }
        public string Task { get; set; }
        public int TotalTask { get; set; }
        public string TotalHandlingTime { get; set; }
        public string AverageHandlingTime { get; set; }

    }
}
