﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class MastersData
    {
        public MastersData()
        {
            Users = new List<IdValuePair>();
            Departments = new List<IdValuePair>();
            Teams = new List<IdValuePair>();
            Roles = new List<IdValuePair>();
        }

        public List<IdValuePair> Users { get; set; }

        public List<IdValuePair> Departments { get; set; }

        public List<IdValuePair> Roles { get; set; }
        public List<IdValuePair> Teams { get; set; }

    }
}
