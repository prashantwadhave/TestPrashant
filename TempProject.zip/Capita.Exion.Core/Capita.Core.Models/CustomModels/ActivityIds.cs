﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.CustomModels
{
    public class ActivityIds
    {
        public int NonCoreActivityId { get; set; }

        public int UserLogId { get; set; }
    }
}
