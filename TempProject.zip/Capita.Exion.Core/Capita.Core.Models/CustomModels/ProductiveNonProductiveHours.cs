﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
    public class ProductiveNonProductiveHours
    {
        public string Name { get; set; }
        public decimal? Core { get; set; }
        public decimal? NonCore { get; set; }
        public string TotalTimeProductive { get; set; }
        public string TotalTimeNonProductive { get; set; }
    }
}
