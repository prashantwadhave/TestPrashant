﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Capita.Core.Models.DataModels
{
    public class UserLogsCustom
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public int DepartmentId { get; set; }

        public string ActivityName { get; set; }

        public DateTime LoginTime { get; set; }

        public DateTime? LogOutTime { get; set; }
        public string StrLoginTime { get; set; }
        public string StrLogOutTime { get; set; }
        public int Duration { get; set; }
    }
}
