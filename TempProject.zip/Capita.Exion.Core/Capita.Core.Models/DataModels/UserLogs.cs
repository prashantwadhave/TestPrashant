﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Capita.Core.Models.DataModels
{
    public class UserLogs
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public int DepartmentId { get; set; }

        public string ActivityName { get; set; }

        public DateTime LoginTime { get; set; }

        public DateTime? LogOutTime { get; set; }

        public int Duration { get; set; }
    }
}
