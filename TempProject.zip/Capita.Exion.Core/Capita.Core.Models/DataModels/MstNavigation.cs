﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Capita.Core.Models.DataModels
{
    public class MstNavigation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Id { get; set; }

        public Nullable<int> ParentId { get; set; }

        public string ImageCssClass { get; set; }

        public string DisplayName { get; set; }

        public string SourceUrl { get; set; }

        public int SortOrder { get; set; }
        
        public bool IsActive { get; set; }

        public System.DateTime Created { get; set; }

        public int CreatedBy { get; set; }

        public Nullable<System.DateTime> Modified { get; set; }

        public int ModifiedBy { get; set; }
    }
}
