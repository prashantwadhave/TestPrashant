﻿using System;

namespace Capita.Core.Models.DataModels
{
    public class ViewCurrentActivity
    {
        public string Name { get; set; }
        public string Activity { get; set; }
        public string SubActivity { get; set; }
        public string TeamName { get; set; }
        public string Started { get; set; }
        public string Elapsed { get; set; }
        public string LoggedInSince { get; set; }
        public string LoggedOutSince { get; set; }
        public string LoginStatus { get; set; }
    }
}
