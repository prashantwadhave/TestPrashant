﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Capita.Core.Models.DataModels
{
    public class UserLoggedIn
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }
        
        public int DepartmentId { get; set; }

        public DateTime? LoggedIn { get; set; }

        public DateTime? LoggedOut { get; set; }
    }
}
