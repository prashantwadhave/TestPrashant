﻿using System;

namespace Capita.Core.Models.DataModels
{
    public class DisplayCurrentActivity
    {
        public string Name { get; set; }

        public string Activity { get; set; }
        public string TeamName{ get; set; }

        public string SubActivity { get; set; }

        public DateTime? Started { get; set; }
        public string Elapsed { get; set; }
        public DateTime? LoggedInSince { get; set; }
        public DateTime? LoggedOutSince { get; set; }
        public string LoginStatus { get; set; }

    }
}
