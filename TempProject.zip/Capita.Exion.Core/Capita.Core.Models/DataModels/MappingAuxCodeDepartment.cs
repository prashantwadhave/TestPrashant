﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
    public class MappingAuxCodeDepartment
    {
        [Key]
        public int Id { get; set; }

        public int DepartmentId { get; set; }

        public int AuxCodeId { get; set; }

        public bool IsVisibile { get; set; }
    }
}
