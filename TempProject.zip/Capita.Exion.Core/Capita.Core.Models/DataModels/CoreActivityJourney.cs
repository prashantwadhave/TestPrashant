﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
   public class CoreActivityJourney
    {
        [Key]
        public int Id { get; set; }
        public int UserId { get; set; }
        public string ActivityType { get; set; }
        public int DepartmentId { get; set; }
        public int? TeamId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public double Duration { get; set; }
        public string Remarks { get; set; }
        public string Param1 { get; set; }
        public string Param2 { get; set; }
        public string Param3 { get; set; }
        public string Param4 { get; set; }
        public string Param5 { get; set; }
        public string Param6 { get; set; }
        public string Param7 { get; set; }
        public string Param8 { get; set; }
        public string Param9 { get; set; }
        public string Param10 { get; set; }
        public string Param11 { get; set; }
        public string Param12 { get; set; }
        public string Param13 { get; set; }
        public string Param14 { get; set; }
        public string Param15 { get; set; }
        public string Param16 { get; set; }
        public string Param17 { get; set; }
        public string Param18 { get; set; }
        public string Param19 { get; set; }
        public string Param20 { get; set; }
        public string Param21 { get; set; }
        public string Param22 { get; set; }
        public string Param23 { get; set; }
        public string Param24 { get; set; }
        public string Param25 { get; set; }
        public string Param26 { get; set; }


    }
}
