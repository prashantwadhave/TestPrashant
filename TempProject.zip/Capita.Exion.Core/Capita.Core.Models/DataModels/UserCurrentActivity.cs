﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models.DataModels
{
    public class UserCurrentActivity
    {
        [Key]
        public int Id { get; set; }

        public int UserId { get; set; }

        public int DepartmentId { get; set; }
        public int? TeamId { get; set; }
        public string Activity { get; set; }

        public string SubActivity { get; set; }

        public DateTime StartTime { get; set; }
    }
}
