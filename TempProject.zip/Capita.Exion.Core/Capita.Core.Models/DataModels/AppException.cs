﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Capita.Core.Models
{
    public class AppException
    {
        [Key]
        public int Id { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string RequestURL { get; set; }
        public string UserAgent { get; set; }
        public string UserIP { get; set; }
        public string UserId { get; set; }
        public DateTime Created { get; set; }

    }
}
