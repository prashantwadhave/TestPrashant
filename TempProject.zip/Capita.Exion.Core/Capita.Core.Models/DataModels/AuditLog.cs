﻿using System;

namespace Capita.Core.Models
{
    public class AppAuditLog
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Action { get; set; }
        public string EntityName { get; set; }
        public DateTime? Created { get; set; }
    }
}
