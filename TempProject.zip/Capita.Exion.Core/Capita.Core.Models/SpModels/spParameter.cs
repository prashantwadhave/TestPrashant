﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Models
{
    public class spParameter
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }


    public class spResult
    {
        public string Name { get; set; }
        public string Empid { get; set; }
        public string OrganizationalUnit { get; set; }
    }

}
