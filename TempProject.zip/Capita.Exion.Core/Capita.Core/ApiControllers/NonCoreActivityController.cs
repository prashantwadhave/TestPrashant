﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.DataModels;
using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class NonCoreActivityController : ApiController
    {
        private INonCoreActivity _NonCoreActivityService = null;

        private IUser _UserService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public NonCoreActivityController(INonCoreActivity nonCoreActivityService, IUser userService)
        {
            this._NonCoreActivityService = nonCoreActivityService;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpPost]
        [Route("StartNonCoreActivity")]
        public HttpResponseMessage StartNonCoreActivity(NonCoreActivityJourney nonCoreActivity, int activeNonCoreActivityId)
        {
            if (nonCoreActivity != null)
            {
                int userId = _UserService.GetUserIdFromLanId(User.Identity.Name);
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, this._NonCoreActivityService.AddActivity(nonCoreActivity, userId, activeNonCoreActivityId));
            }
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Model cannot be null.");
        
            return httpResponseMessage;
        }

        [HttpPut]
        [Route("StopNonCoreActivity")]
        public HttpResponseMessage StopNonCoreActivity(string activeNonCoreActivityId, string comments, bool isAnyCoreActivtyStarted)
        {
            int result = 0;
            if (int.TryParse(activeNonCoreActivityId,out result))
            {
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, this._NonCoreActivityService.UpdateActivity(activeNonCoreActivityId, comments, isAnyCoreActivtyStarted));
            }
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Activity Id is not correct.");

            return httpResponseMessage;
        }        
    }
}
