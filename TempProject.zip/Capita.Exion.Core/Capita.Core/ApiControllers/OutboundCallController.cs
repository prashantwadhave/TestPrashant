﻿using Capita.Core.Contracts.Interface;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class OutboundCallController : ApiController
    {
        private IOutbondCall _WebChatService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public OutboundCallController(IOutbondCall webChatService)
        {
            _WebChatService = webChatService;
            httpResponseMessage = new HttpResponseMessage();
        }
        [HttpGet]
        [Route("AddOutbondCallActivity")]
        public HttpResponseMessage AddOCallActivity(int departmentId, string comment, int activeNonCoreActivityId, int teamId)
        {
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _WebChatService.AddOutboundCallActivity(departmentId, comment, activeNonCoreActivityId, User.Identity.Name, teamId));
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("UpdateOutboundCallActivity")]
        public HttpResponseMessage UpdateCallActivity(int OCallId, string comment, bool isCoreActivtyStarted, bool isChatActivtyStarted)
        {
            if (OCallId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _WebChatService.UpdateOutboundCallActivity(OCallId, comment, isCoreActivtyStarted, isChatActivtyStarted));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Outbound Call ID is 0");

            return httpResponseMessage;
        }
    }
}