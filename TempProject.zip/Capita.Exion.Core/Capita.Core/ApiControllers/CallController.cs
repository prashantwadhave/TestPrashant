﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class CallController : ApiController
    {
        private ICalls _CallService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public CallController(ICalls callService)
        {
            _CallService = callService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpPost]
        [Route("AddCallActivity")]
        public HttpResponseMessage AddCallActivity(Calls callActivityJourney, int activeNonCoreActivityId)
        {
            if (callActivityJourney != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CallService.AddCallActivity(callActivityJourney, activeNonCoreActivityId, User.Identity.Name));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "CoreActivityJourney model is null");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateCallActivity")]
        public HttpResponseMessage UpdateCallActivity(Calls callActivityJourney, bool isCoreActivtyStarted, bool isWebChatActivityStarted)
        {
            if (callActivityJourney != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CallService.UpdateCallActivity(callActivityJourney, isCoreActivtyStarted, isWebChatActivityStarted));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "callActivityJourney model is null");

            return httpResponseMessage;
        }
    }
}
