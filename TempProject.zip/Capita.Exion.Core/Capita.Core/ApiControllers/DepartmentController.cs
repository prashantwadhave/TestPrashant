﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
namespace Capita.Core.ApiControllers
{

    [RoutePrefix("api")]
    public class DepartmentController : ApiController
    {
        private IDepartment _DepartmentCodeService = null;
        private IUser _UserService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public DepartmentController(IDepartment departmentCodeService, IUser userService)
        {
            _DepartmentCodeService = departmentCodeService;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllDepartments")]
        public HttpResponseMessage Get()
        {
            IEnumerable<MstDepartment> lstDepartments = _DepartmentCodeService.GetAllDepartments(User.Identity.Name);
            return Request.CreateResponse(HttpStatusCode.OK, lstDepartments); 
        }

        [HttpGet]
        [Route("GetAllDepartmentsInApp")]
        public HttpResponseMessage GetAllDepartmentsInApp()
        {
            IEnumerable<MstDepartment> lstDepartments = _DepartmentCodeService.GetAllDepartmentsInApp();
            return Request.CreateResponse(HttpStatusCode.OK, lstDepartments);
        }

        [HttpGet]
        [Route("GetDepartmentById")]
        public HttpResponseMessage GetDepartmentById(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentCodeService.GetDepartmentById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department id cannot be 0");

            return httpResponseMessage;                     
        }

        [HttpPost]
        [Route("AddDepartment")]
        public HttpResponseMessage AddDepartment(MstDepartment department)
        {
            var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool departmentExists = _DepartmentCodeService.CheckDepartmentExists(department.Name);

            if (!departmentExists)
            {
                if (department != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentCodeService.AddDepartment(department, createdBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department already exists");
            }
            
            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateDepartment")]
        public HttpResponseMessage UpdateDepartment(MstDepartment department)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool departmentExists = _DepartmentCodeService.CheckDepartmentExists(department);

            if (!departmentExists)
            {
                if (department != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentCodeService.UpdateDepartment(department, modifiedBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department already exists");
            }

            return httpResponseMessage;
        }

       
    }
}
