﻿using Capita.Core.Contracts.Interface;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Data;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    [Authorize]
    public class CommonController : ApiController
    {
        private ICommon _CommonService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public CommonController(ICommon commonService)
        {
            _CommonService = commonService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpPost]
        [Route("AddUserLoginDetails")]
        public HttpResponseMessage AddUserLoginDetails(NonCoreActivityJourney nonCoreActivityJourney, bool isDepartmentOrRoleChanged)
        {
            if (nonCoreActivityJourney != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CommonService.AddUserLoginDetails(nonCoreActivityJourney, User.Identity.Name, isDepartmentOrRoleChanged));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Model cannot be null.");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("IsUserAuthorized")]
        public HttpResponseMessage IsUserAuthorized()
        {            
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CommonService.IsUserAuthorized(User.Identity.Name));         
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("UserLoggedOut")]
        public HttpResponseMessage UserLoggedOut(int departmentId, int nonCoreActivityId, int userLogId)
        {
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CommonService.UpdateUserLogOutDetails(departmentId, User.Identity.Name, nonCoreActivityId, userLogId));
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("ChangeDepartment")]
        public HttpResponseMessage ChangeDepartment(int departmentId, int nonCoreActivityId)
        {
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CommonService.ChangeDepartment(departmentId, User.Identity.Name, nonCoreActivityId));
            return httpResponseMessage;
        }

        [HttpPost]
        [Route("ExporttoExcel")]
        public HttpResponseMessage ExporttoExcel(List<DynamicJSON> listDynamicJSON)
        {
            string myjson = listDynamicJSON[0].MyJSON;
            DataTable dataTableToExport = JsonConvert.DeserializeObject<DataTable>(myjson);
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CommonService.ExportToExcel(dataTableToExport));
            return httpResponseMessage;
        }

    }
}
