﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class TeamController : ApiController
    {
        private ITeam _TeamService = null;
        private IUser _UserService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public TeamController(ITeam teamService, IUser userService)
        {
            _TeamService = teamService;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }
        [HttpGet]
        [Route("GetAllTeams")]
        public HttpResponseMessage GetAllTeams(string DepartmentId)
        {
            int dpt = 0;
            if (!string.IsNullOrEmpty(DepartmentId))
            {
                dpt = Convert.ToInt32(DepartmentId);
            }
            IEnumerable<MstTeam> lstTeam = _TeamService.GetAllTeamsByDepartment(dpt);
            return Request.CreateResponse(HttpStatusCode.OK, lstTeam);
        }

        [HttpGet]
        [Route("GetTeamById")]
        public HttpResponseMessage GetTeamById(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _TeamService.GetTeamById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Team id cannot be 0");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddTeam")]
        public HttpResponseMessage AddTeam(MstTeam team)
        {
            var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool departmentExists = _TeamService.CheckTeamExists(team.Name, team.DepartmentId);

            if (!departmentExists)
            {
                if (team != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _TeamService.AddTeam(team, createdBy.Id.ToString()));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Team model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Team already exists");
            }

            return httpResponseMessage;
        }


        [HttpPost]
        [Route("UpdateTeam")]
        public HttpResponseMessage UpdateTeam(MstTeam team)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool teamExists = _TeamService.CheckTeamExists(team);

            if (!teamExists)
            {
                if (team != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _TeamService.UpdateTeam(team, modifiedBy.Id.ToString()));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Team model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Team already exists");
            }

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetAllTeamsByUserId")]
        public HttpResponseMessage GetAllTeamsByUserId(int userId, int departmentId)
        {
            List<MstTeam> lstTeam = _TeamService.GetAllTeamsByUserId(userId, departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstTeam);
        }

    }
}
