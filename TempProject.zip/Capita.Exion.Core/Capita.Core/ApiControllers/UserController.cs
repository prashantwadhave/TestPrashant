﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class UserController : ApiController
    {
        private IUser _UserService = null;
        private IRole _RoleService = null;
        private ICommon _CommonService = null;
        private IDepartment _DepartmentService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public UserController(IUser userService, IRole roleService, ICommon commonService, IDepartment departmentService)
        {
            _UserService = userService;
            _RoleService = roleService;
            _CommonService = commonService;
            _DepartmentService = departmentService;

            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllUser")]
        public HttpResponseMessage Get()
        {
            IEnumerable<UserPrimaryDetails> lstUsers = _UserService.GetAllUsers();
            return Request.CreateResponse(HttpStatusCode.OK, lstUsers);
        }

        [HttpGet]
        [Route("GetUserById")]
        public HttpResponseMessage GetUserById(int departmentId, int userId)
        {
            RoleTimezone roleTimeZone = new RoleTimezone();
            roleTimeZone.DepartmentId = departmentId;
            roleTimeZone.lstRoles = _RoleService.GetAllRoles(departmentId).ToList();
            roleTimeZone.lstTimeZone = _CommonService.GetTimezones();
            roleTimeZone.DepartmentName = _DepartmentService.GetDepartmentById(departmentId).Name;
            roleTimeZone.User = userId > 0 ? _UserService.GetUserById(userId) : null;

            if (userId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, roleTimeZone);
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User id cannot be 0");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetUsersCurrentActivity")]
        public HttpResponseMessage GetCurrentActivity(int departmentId)
        {
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetCurrentActivity(departmentId));
        }

        [Route("GetCurrentUsersActivity")]
        public HttpResponseMessage GetCurrentUsersActivity(int departmentId, int teamId = 0)
        {
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetCurrentUsersActivity(departmentId, User.Identity.Name, teamId));
        }

        [HttpGet]
        [Route("GetLoggedInUserDetails")]
        public HttpResponseMessage GetLoggedInUserDetails(int departmentId)
        {
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetLoggedInUserDetails(departmentId));
        }

        [HttpGet]
        [Route("GetUsersByDepartmentId")]
        public HttpResponseMessage GetUsersByDepartmentId(int departmentId)
        {
            var userDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            List<UserPrimaryDetails> lstUserPrimaryDetails = _UserService.GetAllUsersByDepartmentId(departmentId > 0 ? departmentId : userDetails.DepartmentId).ToList();
            return Request.CreateResponse(HttpStatusCode.OK, lstUserPrimaryDetails);
        }

        [HttpGet]
        [Route("GetUnassignedUserList")]
        public HttpResponseMessage GetUnassignedUserList(int departmentId)
        {
            List<UserPrimaryDetails> lstUserPrimaryDetails = _UserService.GetUnassignedUserList(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstUserPrimaryDetails);
        }

        [HttpGet]
        [Route("DeleteUserById")]
        public HttpResponseMessage DeleteUserbyId(int userId)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            if (userId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserService.DeleteUserById(userId, modifiedBy.Id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User id cannot be 0");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddUser")]
        public HttpResponseMessage AddUser(int departmentId, UserPrimaryDetails user)
        {
            var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            if (user != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserService.AddUser(user, createdBy.Id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddUserAndDept")]
        public HttpResponseMessage AddUserAndDept(UserDetails userdetails)
        {
            var userExists = _UserService.CheckUserExists(userdetails.EmployeeId, userdetails.LanId);

            if (!userExists)
            {
                userdetails.CreatedByUserId = _UserService.GetUserIdFromLanId(User.Identity.Name);

                if (userdetails != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserService.AddUserAndDept(userdetails));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User already exists");
            }

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateUser")]
        public HttpResponseMessage UpdateUser(int departmentId, UserPrimaryDetails user)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            if (user != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserService.UpdateUserAndDept(user, modifiedBy.Id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateUserAndDept")]
        public HttpResponseMessage UpdateUserAndDept(int departmentId, UserPrimaryDetails user)
        {
            var userExists = _UserService.CheckUserExists(user);

            if (!userExists)
            {
                var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

                if (user != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserService.UpdateUserAndDept(user, modifiedBy != null ? modifiedBy.Id : user.Id));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User already exists");
            }

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetUserLogs")]
        public HttpResponseMessage GetUserLogs(int departmentId, DateTime startDate, DateTime endDate)
        {
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetUserLogs(departmentId, startDate, endDate, User.Identity.Name));
        }

        [HttpGet]
        [Route("GetActiveSessionOfUsers")]
        public HttpResponseMessage GetActiveSessionOfUsers(int departmentId)
        {
            var requestedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetActiveSessionOfUsers(departmentId, requestedBy));
        }

        [HttpGet]
        [Route("KillSessionByUserLoggedInId")]
        public HttpResponseMessage KillSessionByUserId(int departmentId, string userLoggedInId)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            return Request.CreateResponse(HttpStatusCode.OK, _CommonService.UpdateUserLogOutDetailsByUserLoggedInId(departmentId, userLoggedInId, modifiedBy));
        }

        [HttpGet]
        [Route("RemoveUserFromDepartment")]
        public HttpResponseMessage RemoveUserFromDepartment(int userId)
        {
            var updatedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            return Request.CreateResponse(HttpStatusCode.OK, _UserService.RemoveUserFromDepartment(userId, updatedBy.Id));
        }


    }
}
