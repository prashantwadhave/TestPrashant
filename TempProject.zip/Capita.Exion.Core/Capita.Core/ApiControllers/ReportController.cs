﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class ReportController : ApiController
    {
        private ICoreActivity _coreService = null;
        private ICalls _callsService = null;
        private IUser _UserService = null;

        private HttpResponseMessage httpResponseMessage = null;
        private IReports reportService = null;

        public ReportController(ICoreActivity coreService, ICalls calls, IReports _reports, IUser userService)
        {
            _coreService = coreService;
            _callsService = calls;
            reportService = _reports;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetCallList")]
        public HttpResponseMessage GetCallList(int departmentId, DateTime startDate, DateTime endDate)
        {

            return Request.CreateResponse(HttpStatusCode.OK, _callsService.GetCallList(departmentId, startDate, endDate, User.Identity.Name));
        }
        [HttpGet]
        [Route("TaskAverageReport")]
        public HttpResponseMessage TaskAverageReport(int departmentId, DateTime startDate, DateTime endDate, string scheme = "", int teamId = 0)
        {

            if (string.IsNullOrWhiteSpace(scheme) || scheme.Equals("undefined"))
            {
                scheme = string.Empty;
            }
            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetTaskAverage(departmentId, startDate, endDate, User.Identity.Name, scheme, teamId));
        }
        [HttpGet]
        [Route("GetProductivityReport")]
        public HttpResponseMessage GetProductivityReport(int departmentId, DateTime startDate, DateTime endDate, string userId, int teamId = 0)
        {

            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetProductivity(departmentId, startDate, endDate, User.Identity.Name, userId, teamId));
        }

        [HttpPost]
        [Route("GetCoreActivityReportSBSS")]
        public IHttpActionResult GetCoreActivityReport(int departmentId, DateTime startDate, DateTime endDate, string Scheme = "", int userId = 0, string ActivityType = "", string searchVal = "", bool isExport = false, int teamId = 0)
        {
            // TODO: Need to move to global varible           

            string draw = string.Empty, start = string.Empty, length = string.Empty, searchValue = string.Empty;
            int pageSize = 0, skip = 0, totalRecords = 0;
            if (!isExport)
            {
                draw = HttpContext.Current.Request.Form.GetValues("draw").FirstOrDefault();
                start = HttpContext.Current.Request.Form.GetValues("start").FirstOrDefault();
                length = HttpContext.Current.Request.Form.GetValues("length").FirstOrDefault();
                searchValue = HttpContext.Current.Request.Form.GetValues("search[value]").FirstOrDefault();
                pageSize = length != null ? Convert.ToInt32(length) : 0;
                skip = start != null ? Convert.ToInt32(start) : 0;
            }
            else
            {
                searchValue = string.IsNullOrWhiteSpace(searchVal) ? string.Empty : searchVal;
            }
            if (string.IsNullOrWhiteSpace(Scheme) || Scheme.Equals("undefined"))
            {
                Scheme = string.Empty;
            }
            if (string.IsNullOrWhiteSpace(ActivityType) || ActivityType.Equals("undefined"))
            {
                ActivityType = string.Empty;
            }

            var filteredData = reportService.GetCoreActivities(departmentId, startDate, endDate, User.Identity.Name, skip, pageSize, searchValue, isExport, Scheme, userId, ActivityType, teamId, out totalRecords).ToList();
            return Json(new { draw = draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = filteredData });
        }

        [HttpPost]
        [Route("GetCoreActivitiesReport")]
        public IHttpActionResult GetCoreActivitiesReport(int departmentId, DateTime startDate, DateTime endDate, string searchVal = "", bool isExport = false, int teamId=0)
        {
            // TODO: Need to move to global varible           

            string draw = string.Empty, start = string.Empty, length = string.Empty, searchValue = string.Empty;
            int pageSize = 0, skip = 0, totalRecords = 0;
            if (!isExport)
            {
                draw = HttpContext.Current.Request.Form.GetValues("draw").FirstOrDefault();
                start = HttpContext.Current.Request.Form.GetValues("start").FirstOrDefault();
                length = HttpContext.Current.Request.Form.GetValues("length").FirstOrDefault();
                searchValue = HttpContext.Current.Request.Form.GetValues("search[value]").FirstOrDefault();
                pageSize = length != null ? Convert.ToInt32(length) : 0;
                skip = start != null ? Convert.ToInt32(start) : 0;
            }
            else
            {
                searchValue = string.IsNullOrWhiteSpace(searchVal) ? string.Empty : searchVal;
            }

            var filteredData = reportService.GetCoreActivitiesReport(departmentId, startDate, endDate, User.Identity.Name, skip, pageSize, searchValue, isExport, teamId,out totalRecords).ToList();
            return Json(new { draw = draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = filteredData });
        }

        [HttpGet]
        [Route("GetUserList")]
        public HttpResponseMessage GetUserList(int departmentId)
        {
            return Request.CreateResponse(HttpStatusCode.OK, _UserService.GetUsersByDepartmentId(departmentId));
        }

        [HttpGet]
        [Route("GetLoginLogoutReport")]
        public HttpResponseMessage GetLoginLogoutReport(int departmentId, DateTime startDate, DateTime endDate, int userId = 0)
        {
            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetLoginLogoutReport(departmentId, startDate, endDate, User.Identity.Name, userId));
        }

        [HttpGet]
        [Route("GetNonCoreActivityReport")]
        public HttpResponseMessage GetNonCoreActivityReport(int departmentId, DateTime startDate, DateTime endDate, int teamId = 0)
        {
            var userDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            var result = _UserService.GetUserDataForToday(userDetails.Id, departmentId, userDetails.TimeZone, startDate, endDate, teamId);
            return Request.CreateResponse(HttpStatusCode.OK, result);
        }

        [HttpGet]
        [Route("GetSTTReport")]
        public HttpResponseMessage GetSTTReport(int departmentId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetSTTRepot(departmentId, startDate, endDate, User.Identity.Name, teamId));
        }
        [HttpGet]
        [Route("GetActiveUsersReport")]
        public HttpResponseMessage GetActiveUsersReport(int departmentId, DateTime startDate, DateTime endDate)
        {
            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetActiveUsers(departmentId, startDate, endDate, User.Identity.Name));
        }
        [HttpGet]
        [Route("AgentTaskAverageReport")]
        public HttpResponseMessage AgentTaskAverageReport(int departmentId, DateTime startDate, DateTime endDate, string userId = "", int teamId = 0)
        {

            if (string.IsNullOrWhiteSpace(userId) || userId.Equals("undefined"))
            {
                userId = string.Empty;
            }
            return Request.CreateResponse(HttpStatusCode.OK, reportService.GetAgentTaskAverage(departmentId, startDate, endDate, User.Identity.Name, userId, teamId));
        }
    }
}
