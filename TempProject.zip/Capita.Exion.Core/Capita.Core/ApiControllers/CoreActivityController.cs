﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class CoreActivityController : ApiController
    {
        private ICoreActivity _CoreActivityService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public CoreActivityController(ICoreActivity coreActivityService)
        {
            _CoreActivityService = coreActivityService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpPost]
        [Route("AddCoreActivity")]
        public HttpResponseMessage AddCoreActivity(CoreActivityJourney coreActivityJourney, int activeNonCoreActivityId)
        {
            if (coreActivityJourney != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CoreActivityService.AddCoreActivity(coreActivityJourney, activeNonCoreActivityId, User.Identity.Name));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "CoreActivityJourney model is null");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateCoreActivity")]
        public HttpResponseMessage UpdateCoreActivity(CoreActivityJourney coreActivityJourney)
        {            
            if (coreActivityJourney != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _CoreActivityService.UpdateCoreActivity(coreActivityJourney));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "CoreActivityJourney model is null");

            return httpResponseMessage;
        }
    }
}
