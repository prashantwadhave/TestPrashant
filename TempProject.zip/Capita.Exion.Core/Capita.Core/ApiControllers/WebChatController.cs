﻿using Capita.Core.Contracts.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class WebChatController : ApiController
    {
        private IWebChat _WebChatService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public WebChatController(IWebChat webChatService)
        {
            _WebChatService = webChatService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("AddWebChatActivity")]
        public HttpResponseMessage AddCallActivity(int departmentId, string comment, int activeNonCoreActivityId, int teamId)
        {           
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _WebChatService.AddWebChatActivity(departmentId, comment, activeNonCoreActivityId, User.Identity.Name,teamId));         
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("UpdateWebChatActivity")]
        public HttpResponseMessage UpdateCallActivity(int webChatID, string comment, bool isCoreActivtyStarted, bool isCallActivtyStarted, bool isOutBoundActivtyStarted)
        {
            if (webChatID > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _WebChatService.UpdateWebChatActivity(webChatID, comment, isCoreActivtyStarted, isCallActivtyStarted, isOutBoundActivtyStarted));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Web Chat ID is 0");

            return httpResponseMessage;
        }
    }
}
