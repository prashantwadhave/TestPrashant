﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
namespace Capita.Core.ApiControllers
{

    [RoutePrefix("api")]
    public class NavigationController : ApiController
    {
        private INavigation _NavigationService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public NavigationController(INavigation navigationCodeService)
        {
            _NavigationService = navigationCodeService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllNavigations")]
        public HttpResponseMessage Get(int departmentId)
        {
            List<MstNavigation> userNavigation = _NavigationService.GetAllNavigations(departmentId, User.Identity.Name);
            return Request.CreateResponse(HttpStatusCode.OK, userNavigation); 
        }

        //[HttpGet]
        //[Route("GetNavigationById")]
        //public HttpResponseMessage GetNavigationById(int id)
        //{
        //    if (id > 0)
        //        httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _NavigationService.GetNavigationById(id));
        //    else
        //        httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Navigation id cannot be 0");
        //    return httpResponseMessage;
        //}

    }
}
