﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class RoleController : ApiController
    {
        private IRole _RoleService = null;
        private ICommon _CommonService = null;
        private IDepartment _DepartmentService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public RoleController(IRole roleService, ICommon commonService, IDepartment departmentService)
        {
            _RoleService = roleService;
            _CommonService = commonService;
            _DepartmentService = departmentService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllRole")]
        public HttpResponseMessage Get(int departmentId)
        {
            IEnumerable<MstRole> lstRoles = _RoleService.GetAllRoles(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstRoles);
        }
        
        [HttpGet]
        [Route("GetRoleById")]
        public HttpResponseMessage GetRoleById(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _RoleService.GetRoleById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Role id cannot be 0");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("AddRole")]
        public HttpResponseMessage AddRole()
        {
            MstRole department = new MstRole() { Id = 2, Name = "Pru", CreatedDate = DateTimeHelper.Now, CreatedBy = 1, ModifiedBy = 1, ModifiedDate = DateTimeHelper.Now };

            if (department != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _RoleService.AddRole(department));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Role model is null");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("UpdateRole")]
        public HttpResponseMessage UpdateRole()
        {
            MstRole department = new MstRole() { Id = 2, Name = "arcadia", CreatedDate = DateTimeHelper.Now, CreatedBy = 1, ModifiedBy = 1, ModifiedDate = DateTimeHelper.Now };

            if (department != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _RoleService.UpdateRole(department));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Role model is null");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("DeleteRole")]
        public HttpResponseMessage DeleteRole(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _RoleService.DeleteRoleById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Role id cannot be 0");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetRoleTimezoneByDepartmentId")]
        public HttpResponseMessage GetDeptRoleTimezone(int departmentId)
        {
            RoleTimezone roleTimeZone = new RoleTimezone();
            roleTimeZone.DepartmentId = departmentId;
            roleTimeZone.lstRoles = _RoleService.GetAllRoles(departmentId).ToList();
            roleTimeZone.lstTimeZone = _CommonService.GetTimezones();
            roleTimeZone.DepartmentName = _DepartmentService.GetDepartmentById(departmentId).Name;

            return Request.CreateResponse(HttpStatusCode.OK, roleTimeZone);
        }
    }
}
