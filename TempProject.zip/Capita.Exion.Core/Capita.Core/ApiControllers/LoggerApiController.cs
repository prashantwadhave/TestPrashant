﻿using Capita.Core.Contracts;
using Capita.Core.Models;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    public class LoggerApiController : ApiController
    {
        ILogger ExceptionLoggerService;


        public LoggerApiController(ILogger ExceptionLoggerService)
        {
            this.ExceptionLoggerService = ExceptionLoggerService;
        }

        [HttpPost]
      
        public int LogClientError(AppException appError)
        {
            return ExceptionLoggerService.Log(appError);
        }
    }
}
