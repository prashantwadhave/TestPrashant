﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Globalization;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using System.Web;

namespace Capita.Core.ApiControllers
{

    [RoutePrefix("api")]
    public class LineManagerDashboardController : ApiController
    {
        private IDashboard _DashboardService = null;
        private IUser _UserService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public LineManagerDashboardController(IDashboard dashboardService, IUser userService)
        {
            _DashboardService = dashboardService;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetEmployeesByManagerIdLM")]
        public HttpResponseMessage GetEmployeesByManagerIdLM(int departmentId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            ManagerDashboard managerDashboard = new ManagerDashboard();

            var userDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            managerDashboard.LstCoreNonCoreTimeHours = _DashboardService.GetCoreNonCoreTime(0, departmentId > 0 ? departmentId : userDetails.DepartmentId, userDetails.TimeZone, startDate, endDate, teamId);

            foreach (var item in managerDashboard.LstCoreNonCoreTimeHours)
            {
                item.Hours = string.IsNullOrEmpty(item.DisplayName) ? 0.00m : Convert.ToDecimal(item.DisplayName.Replace(":", ".").Substring(0, 5));
            }

            var prodNonProd = _DashboardService.GetProductiveNonProductive(0, departmentId > 0 ? departmentId : userDetails.DepartmentId, userDetails.TimeZone, startDate, endDate, teamId);
            if (prodNonProd != null)
            {
                prodNonProd.Core = string.IsNullOrEmpty(prodNonProd.TotalTimeProductive) ? 0.00m : Convert.ToDecimal(prodNonProd.TotalTimeProductive.Replace(":", ".").Substring(0, 5));
                prodNonProd.NonCore = string.IsNullOrEmpty(prodNonProd.TotalTimeNonProductive) ? 0.00m : Convert.ToDecimal(prodNonProd.TotalTimeNonProductive.Replace(":", ".").Substring(0, 5));
            }

            if (prodNonProd.NonCore > 0.00m || prodNonProd.Core > 0.00m)
                managerDashboard.LstProductiveNonProductiveHours.Add(prodNonProd);

            return Request.CreateResponse(HttpStatusCode.OK, managerDashboard);
        }

        [HttpPost]
        [Route("GetRealTimeDashboardLM")]
        public IHttpActionResult GetRealTimeDashboardLM(int departmentId, int userId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            var managerDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            var userDetails = _UserService.GetUserById(userId);

            // TODO: Need to move to global varible           

            string draw = HttpContext.Current.Request.Form.GetValues("draw").FirstOrDefault();
            string start = HttpContext.Current.Request.Form.GetValues("start").FirstOrDefault();
            string length = HttpContext.Current.Request.Form.GetValues("length").FirstOrDefault();
            string searchValue = HttpContext.Current.Request.Form.GetValues("search[value]").FirstOrDefault();

            int pageSize = length != null ? Convert.ToInt32(length) : 0;
            int skip = start != null ? Convert.ToInt32(start) : 0;
            int totalRecords = 0;
            //string searchValue = HttpContext.Current.Request.Form.GetValues("search[value]").FirstOrDefault();

            List<RealTimeDashboard> lstRealTimeDashboard = new List<RealTimeDashboard>();
            lstRealTimeDashboard = _DashboardService.GetRealTimeDashboardLM(userDetails!=null? userDetails.Id : 0, departmentId, managerDetails.TimeZone, startDate, endDate, skip, pageSize, searchValue, teamId,out totalRecords);
            if (lstRealTimeDashboard!=null &&lstRealTimeDashboard.Count>0)
            {
                return Json(new { draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = lstRealTimeDashboard });
            }
            else
            {
                return Json(new { draw, recordsFiltered = totalRecords, recordsTotal = totalRecords, data = new List<RealTimeDashboard>() });
            }
            
        }

        [HttpGet]
        [Route("GetProductiveNonProductiveLM")]
        public HttpResponseMessage GetProductiveNonProductiveLM(int departmentId, int userId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            var userDetails = _UserService.GetUserById(userId);
            var currentUserDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            List<ProductiveNonProductiveHours> lstProductiveNonProductiveHours = new List<ProductiveNonProductiveHours>();
            var prodNonProd = _DashboardService.GetProductiveNonProductive(userDetails != null ? userDetails.Id : 0, departmentId, currentUserDetails.TimeZone, startDate, endDate, teamId);

            if (prodNonProd != null)
            {
                prodNonProd.Core = string.IsNullOrEmpty(prodNonProd.TotalTimeProductive) ? 0.00m : Convert.ToDecimal(prodNonProd.TotalTimeProductive.Replace(":", ".").Substring(0, 5));
                prodNonProd.NonCore = string.IsNullOrEmpty(prodNonProd.TotalTimeNonProductive) ? 0.00m : Convert.ToDecimal(prodNonProd.TotalTimeNonProductive.Replace(":", ".").Substring(0, 5));
            }

            if (prodNonProd.NonCore > 0.00m || prodNonProd.Core > 0.00m)
                lstProductiveNonProductiveHours.Add(prodNonProd);

            return Request.CreateResponse(HttpStatusCode.OK, lstProductiveNonProductiveHours);
            
        }

        [HttpGet]
        [Route("GetCoreNonCoreTimeLM")]
        public HttpResponseMessage GetCoreNonCoreTimeLM(int departmentId, int userId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            var userDetails = _UserService.GetUserById(userId);
            var currentUserDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            List<CoreNonCoreTime> lstCoreNonCoreTimeHours = _DashboardService.GetCoreNonCoreTime(userDetails != null ? userDetails.Id : 0, departmentId, currentUserDetails.TimeZone, startDate, endDate, teamId);

            foreach (var item in lstCoreNonCoreTimeHours)
            {
                item.Hours = string.IsNullOrEmpty(item.DisplayName) ? 0.00m : Convert.ToDecimal(item.DisplayName.Replace(":", ".").Substring(0, 5));
            }
            return Request.CreateResponse(HttpStatusCode.OK, lstCoreNonCoreTimeHours);
            
        }


        [HttpGet]
        [Route("GetEmployeesCoreNonCoreDataLM")]
        public HttpResponseMessage GetEmployeesCoreNonCoreData(int departmentId, int userId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            var userDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            var currentUserDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            List<EmployeesCoreNonCoreData> lstEmployeesCoreNonCoreData = _DashboardService.GetEmployeesCoreNonCoreData(userId, departmentId, currentUserDetails.TimeZone, startDate, endDate,teamId);
            return Request.CreateResponse(HttpStatusCode.OK, lstEmployeesCoreNonCoreData);
        }

        [HttpGet]
        [Route("GetUserCurrentStatisticLM")]
        public HttpResponseMessage GetUserCurrentStatisticLM(int departmentId, int userId, DateTime startDate, DateTime endDate, int teamId=0)
        {
            var userDetails = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            List<UserCurrentStatistics> lstEmployeesCoreNonCoreData = _DashboardService.GetUserCurrentStatistic(userId, departmentId, userDetails.TimeZone, startDate, endDate,teamId);
            return Request.CreateResponse(HttpStatusCode.OK, lstEmployeesCoreNonCoreData);
        }

    }
}
