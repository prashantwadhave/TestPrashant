﻿using Capita.Core.Contracts;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class AuxCodeController : ApiController
    {
        private IAuxCode _AuxCodeCodeService = null;
        private IUser _UserService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public AuxCodeController(IAuxCode auxCodeService, IUser userService)
        {
            _AuxCodeCodeService = auxCodeService;
            _UserService = userService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllAuxCode")]
        public HttpResponseMessage Get(int departmentId)
        {
            IEnumerable<MstAuxCode>  lstAuxCode = _AuxCodeCodeService.GetAllAuxCode(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstAuxCode);            
        }

        [HttpGet]
        [Route("GetAllAuxCodeList")]
        public HttpResponseMessage GetAllUnassignedAuxCode()
        {
            IEnumerable<MstAuxCode> lstAuxCode = _AuxCodeCodeService.GetAllAuxCodeList();
            return Request.CreateResponse(HttpStatusCode.OK, lstAuxCode);
        }

        [HttpGet]
        [Route("GetAllAssignedAuxCode")]
        public HttpResponseMessage GetAllAssignedAuxCode(int departmentId)
        {
            IEnumerable<MstAuxCode> lstAuxCode = _AuxCodeCodeService.GetAllAssignedAuxCode(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstAuxCode);
        }

        [HttpGet]
        [Route("GetAllAuxCodeForAllDept")]
        public HttpResponseMessage GetAllAuxCode()
        {
            List<KeyValuePair> lstAuxCode = _AuxCodeCodeService.GetAllAuxCode();
            return Request.CreateResponse(HttpStatusCode.OK, lstAuxCode);
        }

        [HttpGet]
        [Route("GetAllAuxCodeDepartment")]
        public HttpResponseMessage GetAllAuxCodeDepartment(int departmentId, int auxCodeId)
        {
            MapAuxCodeDept mapAuxCodeDept = new MapAuxCodeDept();
            mapAuxCodeDept.LstAuxCodeDepartment = _AuxCodeCodeService.GetAllAuxCodeDepartment(departmentId, auxCodeId);
            mapAuxCodeDept.LstDepartment = _AuxCodeCodeService.GetDepartmentsWhichDontHaveSelectedAuxCode(auxCodeId);
       
            return Request.CreateResponse(HttpStatusCode.OK, mapAuxCodeDept);
        }

        [HttpGet]
        [Route("GetAuxCodeById")]
        public HttpResponseMessage GetAuxCodeById(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _AuxCodeCodeService.GetAuxCodeById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "AuxCode id cannot be 0");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddAuxCode")]
        public HttpResponseMessage AddAuxCode(MstAuxCode auxCode)
        {
            var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool auxCodeExists = _AuxCodeCodeService.CheckAuxCodeExists(auxCode);

            if (!auxCodeExists)
            {
                if (auxCode != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _AuxCodeCodeService.AddAuxCode(auxCode, createdBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "AuxCode model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Aux Code already exists");
            }

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateAuxCode")]
        public HttpResponseMessage UpdateAuxCode(MstAuxCode auxcode)
        {
            var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);           

            bool auxCodeExists = _AuxCodeCodeService.CheckAuxCodeExists(auxcode);

            if (!auxCodeExists)
            {
                if (auxcode != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _AuxCodeCodeService.UpdateAuxCode(auxcode, modifiedBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "AuxCode model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Aux Code already exists");
            }

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("DeleteAuxCode")]
        public HttpResponseMessage DeleteAuxCode(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _AuxCodeCodeService.DeleteAuxCodeById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "AuxCode id cannot be 0");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("MapAuxCodeAndDepartment")]
        public HttpResponseMessage MapAuxCodeAndDepartment(int auxCodeId, int departmentId)
        {
            bool IsAlreadyAdded = _AuxCodeCodeService.CheckMappingExistsAuxCodeAndDepartment(auxCodeId, departmentId);
            if (!IsAlreadyAdded)
            {
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _AuxCodeCodeService.AddUpdateMappingAuxCodeDepartment(auxCodeId, departmentId));
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Aux Code is already added");
            }

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("DeleteMapAuxCodeAndDepartment")]
        public HttpResponseMessage DeleteMapAuxCodeAndDepartment(int auxCodeId, int departmentId)
        {
            //var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

            bool result = _AuxCodeCodeService.DeleteMapAuxCodeAndDepartment(auxCodeId, departmentId);

            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, result);

            return httpResponseMessage;
        }
    }
}
