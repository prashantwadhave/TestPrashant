﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
namespace Capita.Core.ApiControllers
{

    [RoutePrefix("api")]
    public class DepartmentRoleNavigationController : ApiController
    {
        private IMappingDepartmentRoleNavigation _DepartmentRoleNavigationService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public DepartmentRoleNavigationController(IMappingDepartmentRoleNavigation departmentRoleNavigationService)
        {
            _DepartmentRoleNavigationService = departmentRoleNavigationService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllDepartmentRoleNavigation")]
        public HttpResponseMessage Get()
        {
            IEnumerable<MappingRoleNavigation> lstDepartmentRoleNavigation = _DepartmentRoleNavigationService.GetAllMappingDepartmentRoleNavigation();
            return Request.CreateResponse(HttpStatusCode.OK, lstDepartmentRoleNavigation); 
        }

        [HttpGet]
        [Route("GetDepartmentRoleNavigationById")]
        public HttpResponseMessage GetMappingDepartmentRoleNavigationById(int id)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentRoleNavigationService.GetMappingDepartmentRoleNavigationById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "DepartmentRoleNavigation id cannot be 0");

            return httpResponseMessage;                     
        }

        [HttpPost]
        [Route("AddDepartmentRoleNavigation")]
        public HttpResponseMessage AddMappingDepartmentRoleNavigation(MappingRoleNavigation departmentRoleNavigation)
        {   
            if (departmentRoleNavigation != null)                
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentRoleNavigationService.AddMappingDepartmentRoleNavigation(departmentRoleNavigation));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "DepartmentRoleNavigation model is null");
            
            return httpResponseMessage;
        }

        [HttpPost]
        [Route("UpdateDepartmentRoleNavigation")]
        public HttpResponseMessage UpdateMappingDepartmentRoleNavigation(MappingRoleNavigation departmentRoleNavigation)
        {
            if (departmentRoleNavigation != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentRoleNavigationService.UpdateMappingDepartmentRoleNavigation(departmentRoleNavigation));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "DepartmentRoleNavigation model is null");
            
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("DeleteDepartmentRoleNavigationById")]
        public HttpResponseMessage DeleteMappingDepartmentRoleNavigationById(int id)
        {            
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _DepartmentRoleNavigationService.DeleteMappingDepartmentRoleNavigationById(id));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "DepartmentRoleNavigation id cannot be 0");
            
            return httpResponseMessage;
        }
    }
}
