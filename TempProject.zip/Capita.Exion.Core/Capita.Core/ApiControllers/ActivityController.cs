﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Capita.Core.ApiControllers
{
    [RoutePrefix("api")]
    public class ActivityController : ApiController
    {
        private IActivity _ActivityService = null;
        private IUser _UserService = null;

        private HttpResponseMessage httpResponseMessage = null;

        public ActivityController(IUser userService, IActivity activityService)
        {
            _UserService = userService;
            _ActivityService = activityService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllActivity")]
        public HttpResponseMessage Get(int departmentId)
        {
            IEnumerable<Activity> lstctivitys = _ActivityService.GetActivity(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstctivitys);
        }

        [HttpGet]
        [Route("GetAllActivityByDepartmentId")]
        public HttpResponseMessage GetAllActivityByDepartmentId(int departmentId)
        {
            IList<Activity> lstctivitys = _ActivityService.GetAllActivities(departmentId);
            return Request.CreateResponse(HttpStatusCode.OK, lstctivitys);
        }

        [HttpGet]
        [Route("GetActivityGroups")]
        public HttpResponseMessage GetActivityGroups()
        {
            IList<MstActivityGroup> lstctivitys = _ActivityService.GetActivityGroups();
            return Request.CreateResponse(HttpStatusCode.OK, lstctivitys);
        }
       
        [HttpPost]
        [Route("AddActivity")]
        public HttpResponseMessage AddActivity(MstActivity activity)
        {
            var userExists = _ActivityService.CheckActivityExists(activity);
            var createdBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);
            if (!userExists)
            {
                activity.CreatedBy = _UserService.GetUserIdFromLanId(User.Identity.Name);

                if (activity != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _ActivityService.AddActivity(activity, createdBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Activity combination already exists");
            }

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetActivityId")]
        public HttpResponseMessage GetActivityId(int departmentId, int activityId)
        {
            if (activityId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _ActivityService.GetActivityById(activityId));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Department id cannot be 0");

            return httpResponseMessage;
          
        }

        [HttpPost]
        [Route("UpdateActivity")]
        public HttpResponseMessage UpdateActivity(int departmentId, MstActivity activity)
        {
            var userActivity = _ActivityService.CheckActivityExists(activity);

            if (!userActivity)
            {
                var modifiedBy = _UserService.GetUserDetailsFromLanId(User.Identity.Name);

                if (activity != null)
                    httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _ActivityService.UpdateActivity(activity, modifiedBy));
                else
                    httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User model is null");
            }
            else
            {
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "Activity combination already exists");
            }

            return httpResponseMessage;
        }

    }
}
