﻿using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using System;
using Capita.Core.Models.CustomModels;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
namespace Capita.Core.ApiControllers
{

    [RoutePrefix("api")]
    public class UserDepartmentController : ApiController
    {
        private IMappingUserDepartment _UserDepartmentService = null;
        private HttpResponseMessage httpResponseMessage = null;

        public UserDepartmentController(IMappingUserDepartment userDepartmentService)
        {
            _UserDepartmentService = userDepartmentService;
            httpResponseMessage = new HttpResponseMessage();
        }

        [HttpGet]
        [Route("GetAllUserDepartment")]
        public HttpResponseMessage Get()
        {
            IEnumerable<MappingUserDepartment> lstUserDepartment = _UserDepartmentService.GetAllMappingUserDepartment();
            return Request.CreateResponse(HttpStatusCode.OK, lstUserDepartment); 
        }

        [HttpGet]
        [Route("GetUserDepartmentRolesByUserId")]
        public HttpResponseMessage GetUserDepartmentRolesByUserId(int userId, int departmentId)
        {
            if (userId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.GetUserDepartmentRolesByUserId(userId, departmentId));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User id cannot be 0");

            return httpResponseMessage;                     
        }
        [HttpGet]
        [Route("GetUserDepartmentRolesByUserIdForAdmin")]
        public HttpResponseMessage GetUserDepartmentRolesByUserIdForAdmin(int userId)
        {
            if (userId > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.GetUserDepartmentRolesByUserIdForAdmin(userId));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "User id cannot be 0");

            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddUserDepartmentRoles")]
        public HttpResponseMessage AddMappingUserDepartment(UserDepartmentRoles userDepartmentRoles)
        {            
            if (userDepartmentRoles != null)                
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.AddMappingUserDepartment(userDepartmentRoles, User.Identity.Name));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "UserDepartment model is null");
            
            return httpResponseMessage;
        }

        [HttpPost]
        [Route("AddUserDepartmentRolesForAdmin")]
        public HttpResponseMessage AddUserDepartmentRolesForAdmin(UserDepartmentRoles userDepartmentRoles)
        {
            if (userDepartmentRoles != null)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.AddMappingUserDepartmentForAdmin(userDepartmentRoles, User.Identity.Name));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "UserDepartment model is null");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("DeleteUserDepartmentById")]
        public HttpResponseMessage DeleteMappingUserDepartmentById(int id, int userId)
        {            
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.DeleteMappingUserDepartmentById(id, userId));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "UserDepartment id cannot be 0");
            
            return httpResponseMessage;
        }
        [HttpGet]
        [Route("DeleteUserDepartmentByIdForAdmin")]
        public HttpResponseMessage DeleteUserDepartmentByIdForAdmin(int id, int userId)
        {
            if (id > 0)
                httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.DeleteMappingUserDepartmentByIdForAdmin(id, userId));
            else
                httpResponseMessage = Request.CreateErrorResponse(HttpStatusCode.ExpectationFailed, "UserDepartment id cannot be 0");

            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetMasterData")]
        public HttpResponseMessage GetAllUserRoleDepartment(int departmentId)
        {
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.GetAllUserRoleDepartment(User.Identity.Name, departmentId));
            return httpResponseMessage;
        }

        [HttpGet]
        [Route("GetMasterDataForAdmin")]
        public HttpResponseMessage GetAllUserRoleDepartment()
        {
            httpResponseMessage = Request.CreateResponse(HttpStatusCode.OK, _UserDepartmentService.GetAllUserRoleDepartment(User.Identity.Name));
            return httpResponseMessage;
        }
    }
}
