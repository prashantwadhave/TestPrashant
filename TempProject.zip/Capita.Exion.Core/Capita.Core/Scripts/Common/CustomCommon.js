﻿var Commonmethods = {

    AjaxData: function GetData(url, reqType, isAsync, contentType, data, ErrorMsg, successCallback) {
        
        var result = null;
        if (contentType.trim() == '')
            contentType = "application/x-www-form-urlencoded; charset=UTF-8";
       
        $.ajax({
            url: url,
            type: reqType,
            async: isAsync,
            dataType: "json",
            contentType: contentType,
            data: data,
            success: successCallback,
            error: function (r, s, e) {                
                $('#cmnMsgText').text(ErrorMsg);
                $(".message_popup").show();
            }
        });
    },

    PostAjaxData: function PostData(url, reqType, isAsync, contentType, data, ErrorMsg, successCallback) {

        var result = null;
        if (contentType.trim() == '')
            contentType = "application/json;charset=utf-8";

        $.ajax({
            url:  url,
            type: reqType,
            async: isAsync,
            dataType: "json",
            contentType: contentType,
            data: data,
            success: successCallback,
            error: function (r, s, e) {
                $('#cmnMsgText').text(ErrorMsg);
                $(".message_popup").show();
            }
        });
    },

    ExportToExcel: function ExportToExcel(exportData) {
        
        var result = null;    
      
        $.ajax({
            type: "POST",
            dataType: "json",
            url: '/api/ExporttoExcel',
            async: false,          
            contentType: "application/json;charset=utf-8",
            data: JSON.stringify(exportData),
            success: function (returnVal) {
                result = '/FileDownload/' + returnVal;
            },
            //Commented By $Girish.
            error: function (returnVal) {
                
            },
            //Added new code below to display custom error message
            //error: Commonmethods.OnError
        });
        return result;
        //}, 100);
    }
};

$(function () {
    // getTimer();
    try {
        $("#alertPopup").load("Templates/AlertPopup.html", function () {
            //            if (sessionStorage.getItem('FirstName') === null || typeof (sessionStorage.getItem('FirstName')) === 'undefined' || sessionStorage.getItem('FirstName') === '')
            //                sessionStorage.setItem('IsLoggedin', false);
            //            else
            //                sessionStorage.setItem('IsLoggedin', true);

            //            var issuccess = GetEmployeeDetails();

            //            if (issuccess) {
            //                if (sessionStorage.getItem("IsLoggedin") === 'false') {
            //                    CheckUserLoggedIn();
            //                    GetUIConfig();
            //                }
            //                getTimer();
            //                RemoveIdleOptiion();
            //                nonCoreActivityContent();
            showAddActionModal();
            //                showViewModel();
            //                $(".btnLoggedInUser").click(function () {
            //                    GetAllLoggedInUsers(true);
            //                })

            //            }
        });
    } catch (e) {
        logError(e, "Exception raised in CustomCommon.js");
    }
});

//function LoginUser() {
//    var id = $('#txtlanID').val();
//    var issuccess = GetEmployeeDetails_DifferentUser(id);
//    if (issuccess) {
//        UpdateStopTime_DifferentUser();
//        InsertLogInDetails_DifferentUser(id);
//    }
//}

function validatePassword1() {

    var issuccess = false;
    var oldPassword = $('#txtOldPassword').val();
    var NewPassword = $('#txtNewPassword').val();
    var ConfirmPassword = $('#txtConfirmPassword').val();
    var access_token = sessionStorage.getItem("GetAccessToken");
    var userName = sessionStorage.getItem("UserName");
    if (!access_token) {
        window.location.href = '/Templates/Configurations/Users/Unauthorized.html';
    }
    else {
        issuccess = ChangePassword(userName, oldPassword, NewPassword);       // TODO: Need to set flag
    }
}

$("#txtConfirmPassword").keyup(function (event) {
    if (event.keyCode === 13) {
        validatePassword();
    }
});
//function getTimer() {
// $('#timerContainer').load('Templates/TimerContent.html');
//}
//function ChangePassword(userName, oldPassword, NewPassword) {
//    $('.custom-login-block').hide();
//    $('.chngpwdupdate').show();
//    $('.lblvaloldpasserr').css("display", "none");        
//}

function showAddActionModal() {
    $("#alertCommonPopup").load("Templates/Popuptmpl.html");
}
//function showViewModel() {
//    $("#alertViewPopup").load("Templates/PopupViewtmpl.html");
//}


function ShowLogoutPopup() {
    //var tempArr = sessionStorage.getItem("NonCoreActivity");
    //var arr = JSON.parse(tempArr);
    //var activityID = $("#hdnIdle").val();
    //if (activityID != 0) {
        $(".dvConfirmation").show();
        $(".sweet-overlay").show();
    //}
    //else {
    //    $('#cmnMsg1').text('You have not closed an activity.Request you to first close it.');
    //    $(".alertPopup").hide();
    //    $(".common_popup").show();
    //}
}

function ShowPasswordChngPopup() {

    $('.custom-login-block').show();
    setTimeout(function () {
        $("#txtOldPassword").focus();
    }, 200);
}
function HideMessageBox() {
    $(".message_popup").hide();
}
function ClearText() {
    $('#txtConfirmPassword').val('');
    $('#txtNewPassword').val('');
    $('#txtOldPassword').val('');
    $('.lblpassmatch').css("display", "none");
    $('.lblnewrangepass').css("display", "none");
    $('.lblconfrangepass').css("display", "none");
    $('.lbloldrangepass').css("display", "none");
    $('.lblconfrangepass').css("display", "none");
    $('.lblvaloldpasserr').css("display", "none");
}

function HidePasswordChngPopup() {
    ClearText();
    $('.custom-login-block').hide();
}

function validatePassword() {
    var IsSuccess = true;

    var ConfirmPassword = $('#txtConfirmPassword').val().trim();
    var NewPassword = $('#txtNewPassword').val().trim();
    var OldPassword = $('#txtOldPassword').val().trim();

    if ((NewPassword !== "" && ConfirmPassword !== "" && (!(NewPassword.length < 8 || NewPassword.length > 13)) && (!(ConfirmPassword.length < 8 || ConfirmPassword.length > 13))) && NewPassword !== ConfirmPassword) {
        $('.lblpassmatch').css("display", "block");
        // $('#txtNewPassword').addClass("borderColorRed");
        //$('#txtConfirmPassword').addClass("borderColorRed");
        IsSuccess = false;
    } else {
        $('.lblpassmatch').css("display", "none");
        // $('#txtNewPassword').removeClass("borderColorRed");
        // $('#txtConfirmPassword').removeClass("borderColorRed");
    }

    if (NewPassword.length < 8 || NewPassword.length > 13) {
        $('.lblnewrangepass').css("display", "block");
        // $('#txtNewPassword').addClass("borderColorRed");
        IsSuccess = false;
    } else {
        $('.lblnewrangepass').css("display", "none");
        //$('#txtNewPassword').removeClass("borderColorRed");
    }

    if (ConfirmPassword.length < 8 || ConfirmPassword.length > 13) {
        $('.lblconfrangepass').css("display", "block");
        // $('#txtConfirmPassword').addClass("borderColorRed");
        IsSuccess = false;
    } else {
        $('.lblconfrangepass').css("display", "none");
        //$('#txtConfirmPassword').removeClass("borderColorRed");
    }

    if (OldPassword.length < 8 || OldPassword.length > 13) {
        $('.lbloldrangepass').css("display", "block");
        // $('#txtOldPassword').addClass("borderColorRed");
        IsSuccess = false;
    } else {
        $('.lbloldrangepass').css("display", "none");
        //$('#txtOldPassword').removeClass("borderColorRed");
    }

    if (IsSuccess) {
        validatePassword1();
    }
}

function HideCommonPopup() {
    $(".common_popup").hide();
}
function CloseLogoutPopup() {    
    $(".dvConfirmation").css("display", "none");
    $(".sweet-overlayLog").css("display", "none");
}

function toggleFullScreen() {
    if (!document.fullscreenElement &&    // alternative standard method
        !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement) {  // current working methods
        if (document.documentElement.requestFullscreen) {
            document.documentElement.requestFullscreen();
        } else if (document.documentElement.msRequestFullscreen) {
            document.documentElement.msRequestFullscreen();
        } else if (document.documentElement.mozRequestFullScreen) {
            document.documentElement.mozRequestFullScreen();
        } else if (document.documentElement.webkitRequestFullscreen) {
            document.documentElement.webkitRequestFullscreen(Element.ALLOW_KEYBOARD_INPUT);
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        }
    }
}



$("ul.treeview-menu-custom li").click(function () {
    $("ul.treeview-menu-custom li").removeClass("active");
    $(this).addClass("active");
});

$("ul.sidebar-menu-custom li").click(function () {
    $("ul.sidebar-menu-custom li").removeClass("active");
    $(this).addClass("active");
});

//accordion-toggle
$('.collapse').on('shown.bs.collapse', function () {
    $(this).parent().find(".glyphicon-chevron-down").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
}).on('hidden.bs.collapse', function () {
    $(this).parent().find(".glyphicon-chevron-up").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
});

$('.closeall').click(function () {
    $('.panel-collapse.in')
        .collapse('hide');
});
$('.openall').click(function () {
    $('.panel-collapse:not(".in")')
        .collapse('show');
});

jQuery(document).ready(function (e) {
    e(".dropdown-toggle").click(function () {
        var t = e(this).parents(".button-dropdown").children(".dropdown-menu").is(":hidden");
        e(".button-dropdown .dropdown-menu").hide();
        e(".button-dropdown .dropdown-toggle").removeClass("active");
        if (t) {
            e(this).parents(".button-dropdown").children(".dropdown-menu").toggle().parents(".button-dropdown").children(".dropdown-toggle").addClass("active")
        }
    });
    e(document).bind("click", function (t) {
        var n = e(t.target);
        if (!n.parents().hasClass("button-dropdown")) e(".button-dropdown .dropdown-menu").hide();
    });
    e(document).bind("click", function (t) {
        var n = e(t.target);
        if (!n.parents().hasClass("button-dropdown")) e(".button-dropdown .dropdown-toggle").removeClass("active");
    });

    $(".xn-openable").click(function () {
        if ($(this).children("li.submenu").css("display") === "none") {
            $(this).children("li.submenu").show();
        } else {
            $(this).children("li.submenu").hide();
        }
    });

});

$('body').on('click', '.box-header-toggle', function (event) {
    
    $(this).find('i').toggleClass('fa-plus fa-minus');
    $(this).nextUntil('box-body').slideToggle(100, function () {
    });
});

$('body').on('click', '.box-header-toggle1', function (event) {
    if ($(event.target.parentElement).hasClass("zmdi-minus-common")) {
        $(this).find('i').toggleClass('fa-plus fa-minus');
        $(this).nextUntil('box-body').slideToggle(100, function () {
        });
    }
});


$('body').on('click', '#cmnpopuphide', function (event) {
    $('#DisplayMsgSuccess').css("display", "none");
});

$(".slimscrollleft").slimScroll({
    size: '8px',
    width: '100%',
    height: '520px',
    color: '#6e6e6e',
    allowPageScroll: true,
    alwaysVisible: true
});

$(".select2").select2();
$.fn.modal.Constructor.prototype.enforceFocus = function () { };


function ChangeTeam() {     
   $(".chnage_team").show();     
}
function ClosePopup() {    
    $(".chnage_team").hide();  
    $(".sweet-overlay").hide();  
}
//function HideConfirmationMsg() {
//    $(".confirmation_popup").hide();
//}
function HideMessageBox() {
    $(".message_popup").hide();
}
//function HideConfirmationMsg() {
//    $(".confirmation_popup").hide();
//}
function ShowMessageBox(msg) {
    $('#messageText').text(msg);
    $(".message_popup").show();
}





