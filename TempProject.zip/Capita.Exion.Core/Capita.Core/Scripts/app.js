﻿
var app = $.sammy("#mainContent", function () {
    this.use('Template');
    this.get('#/Home', function (context) {
       
        if (sessionStorage.getItem('isUserAuthenticated') == 'true') {
            context.app.swap('');

            if (sessionStorage.getItem("HasAdvisorRole") == 'true' || sessionStorage.getItem("HasAdvisorRole") == true)
                context.render('templates/Dashboard.html').appendTo(context.$element());
            else
                context.render('templates/LineManagerDashboard.html').appendTo(context.$element());
        }
    });

    this.get('#/EmployeeRole', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/EmployeeRole')) {
            context.app.swap('');
            context.render('templates/EmployeeTeamRole.html').appendTo(context.$element());
        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/addrole', function (context) {        
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/addrole')) {
            context.app.swap('');           
            context.render('templates/Configurations/Users/AddRole.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/addadmin', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/addadmin')) {
            context.app.swap('');
            context.render('templates/Configurations/Users/AddAdmin.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/userlogs', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/userlogs')) {
            context.app.swap('');
            context.render('templates/UserLogs.html').appendTo(context.$element());

          
        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/adduser', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/adduser')) {
            context.app.swap('');
            context.render('templates/Configurations/Users/AddUser.html').appendTo(context.$element());
         
        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/addteam', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/addteam')) {
            context.app.swap('');
            context.render('templates/Configurations/Settings/TeamMaster.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/loggedinuser', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/loggedinuser')) {
            context.app.swap('');
            context.render('templates/Configurations/Users/LoggedInUser.html').appendTo(context.$element());
       
        }
    });

    this.get('#/reports', function (context) {        
    });

    this.get('#/useractivityreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/useractivityreport')) {
            context.app.swap('');
            context.render('templates/Reports/UserActivityReport.html').appendTo(context.$element());
          
        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/coreuseractivityreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/coreuseractivityreport')) {
            context.app.swap('');
            context.render('templates/Reports/CoreUserActivityReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/calldetailreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/calldetailreport')) {
            context.app.swap('');
            context.render('templates/Reports/CallsDetailReport.html').appendTo(context.$element());
           
        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/taskaveragereport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/taskaveragereport')) {
            context.app.swap('');
            context.render('templates/Reports/TaskAverageReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/linemanagerdashboard', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/linemanagerdashboard')) {
            context.app.swap('');
            context.render('templates/LineManagerDashboard.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/rta', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/rta')) {
            context.app.swap('');
            context.render('templates/RTADashboard.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/productivityreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/productivityreport')) {
            context.app.swap('');
            context.render('templates/Reports/ProductivityReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/department', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/department')) {
            context.app.swap('');
            context.render('templates/configurations/settings/department.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/activitymaster', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/activitymaster')) {
            context.app.swap('');
            context.render('templates/configurations/settings/ActivityMaster.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/auxcode', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/auxcode')) {
            context.app.swap('');
            context.render('templates/configurations/settings/AuxCode.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/noncoreactivityreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/noncoreactivityreport')) {
            context.app.swap('');
            context.render('templates/Reports/NonCoreActivityReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

    this.get('#/sttreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/sttreport')) {
            context.app.swap('');
            context.render('templates/Reports/STTReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/activeusersreport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/activeusersreport')) {
            context.app.swap('');
            context.render('templates/Reports/ActiveUsersReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });
    this.get('#/agenttaskaveragereport', function (context) {
        if (sessionStorage.getItem('isUserAuthenticated') == 'true' && IsUserAuthorizedForCurrentPage('#/agenttaskaveragereport')) {
            context.app.swap('');
            context.render('templates/Reports/AgentTaskAverageReport.html').appendTo(context.$element());

        } else {
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
    });

});

$(function () {
    try {
        app.run('#/Home');
    } catch (e) {
        logError(e, "Exception raised in App.js");
    }
});

function IsUserAuthorizedForCurrentPage(sourceUrl) {

    var status = false;
    var UserAccessibleUrls = sessionStorage.getItem("UserAccessibleUrls");
    var res = UserAccessibleUrls.split(",");
    if (UserAccessibleUrls != null && UserAccessibleUrls != undefined && sourceUrl != null && sourceUrl != undefined) {
        
        $.each(res, function (index, value) {

            if (value.toLowerCase() == sourceUrl.toLowerCase()) {
                status = true;
            }

        });
    }

    return status;
};