﻿
function getModel() {
    var token = sessionStorage.getItem("GetAccessToken");
    var itemsu;
    var items;    

    var departmentId = sessionStorage.getItem("DepartmentId") == undefined ? 0 : parseInt(sessionStorage.getItem("DepartmentId"));
 
    var url = '/api/GetAllNavigations?departmentId=' + departmentId;    

    Commonmethods.AjaxData(url, 'GET', false, '', '', 'Issue with function GetSideLinksByRoleId', function (result) {           
        if (result === null) {
            window.location.href = '/Templates/Configurations/Users/Unauthorized.html';
        } else if (result.length >= 0) {           
            itemsu = result;
        }
    });        
    
    items = getNestedMenu(0, itemsu);

    //<remove duplicates, for infinity nesting only>   
    for (var i = 0; i < items.length; i++) {
        if (items[i].used) {
            items.splice(i, 1);
            i--;
        }
    }
    //</remove duplicates, for infinity nesting only>
    //<build root item>
    var model = {};
    model.children = ko.observableArray(items);

    model.nodeTemplate = function (node) {

        return node.children.length > 0 ? 'nodeTempl' : 'nodeLeafTempl';
    }
    //</build root item>
    return model;
};

function getNestedMenu(index, all) {
    var root = all[index];

    if (!root) {
        return all;
    }

    if (!all[index].children) {
        all[index].children = [];
    }

    for (var i = 0; i < all.length; i++) {
        //<infinity nesting?>

        //put children inside it's parent
        if (all[index].Id === all[i].ParentId) {
            all[index].children.push(all[i]);
            all[i].used = true;
        }

        //this is needed for each item, to determine which template to use        
        all[index].nodeTemplate = function (node) {

            return node.children.length > 0 ? 'nodeTempl' : 'nodeLeafTempl';
        }
        //</infinity nesting?>
    }

    return getNestedMenu(++index, all);
};

$(function () {
    try {
        ko.applyBindings(getModel(), document.getElementById('leftLinkTbl'));
        var ActiveLink = window.location.hash
       
        $('#sidebar-menu ul li').removeClass('currentPg active');

        if (ActiveLink !== '') {

            $('#sideLinks a.nevmenu').parent('li').removeClass('active');
            //$('#sideLinks a[href="' + ActiveLink + '"].nevmenu').parent('li').addClass('currentPg');
            //$('#sideLinks a[href="' + ActiveLink + '"].nevmenu').closest('.xn-openable').addClass('currentPg');
            $('#sideLinks a[href="' + ActiveLink + '"].nevmenu').parent('li').addClass('active');
            $('#sideLinks a[href="' + ActiveLink + '"].nevmenu').closest('.xn-openable').addClass('active');
        }
        if (ActiveLink === '#/' || ActiveLink === '#/Home' || ActiveLink === '') {
           
            //$('#sideLinks a[href="#/Home"].nevmenu, #sideLinks a[href="#/Dashboard"].nevmenu').parent('li').addClass('active currentPg');
            if (sessionStorage.getItem("HasAdvisorRole") == 'true' || sessionStorage.getItem("HasAdvisorRole") == true)
                $('#sideLinks a[href="#/Home"].nevmenu, #sideLinks a[href="#/Dashboard"].nevmenu').parent('li').addClass('currentPg active');
            else {
                $('#sideLinks a[href="#/Home"].nevmenu, #sideLinks a[href="#/linemanagerdashboard"].nevmenu').parent('li').addClass('currentPg active');               
            }

        }

        $("#sideLinks .xn-openable > a").click(function () {
            var li = $(this).parent('li');
            var ul = li.parent("ul");
            ul.find(" > li.xn-openable").not(li).removeClass("active");
        });

        $("#sideLinks .x-navigation li").click(function (event) {
            event.stopPropagation();
            $("#dynamicTitle").html($(event.target).text());
            if ($("#sideLinks .xn-openable > a").hasClass("subdrop"))
                $("#sideLinks .xn-openable > a").removeClass("subdrop");

            var li = $(this);
            var liParent = $(this).parent('li');
            if (li.hasClass("active")) {
                li.removeClass("active");
                li.find("li.active").removeClass("active");
            } else {
                if (li.parents().hasClass("xn-openable")) {
                    //$("li").not(liParent).removeClass("currentPg");
                    $("li:not(:has(>ul))").removeClass("active");
                    //li.parents('.xn-openable').addClass("currentPg");
                    li.addClass("active");
                } else if (li.hasClass("xn-openable")) {
                    li.addClass("active");
                }
                else {
                    //$("li").removeClass("active currentPg");
                    $("li").removeClass("active");
                    li.addClass("active");
                }
            }
            $("#leftLinkTbl").find("li.currentPg").removeClass('currentPg');
            li.addClass("currentPg");
            //Start/Stop menu NCactivity on menu Item click 
            //StartNonCoreActivityOnClickMenuItem(li);
            //ReadOnly page content onclick of menu Item and check activity status          
            //ReadonlyContentOnClickMenuItem();
        });

        //try {
        //    //Code added by $Girish on 14 Jun 2016. It will check currently running activity to disable Sidelinks.        
        //    if (nonCoreActivityGlobalModel !== undefined) {
        //        nonCoreActivityGlobalModel.EnableDisableCoreFuncationlity();
        //    }
        //} catch (e) { }

    }
    catch (e) {
        //logError(e, "Exception raised in Sidelinks.js");
    }
});