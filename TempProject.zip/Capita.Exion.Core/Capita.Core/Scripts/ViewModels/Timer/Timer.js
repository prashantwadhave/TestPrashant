﻿function TimerViewModel() {
    var self = this;
    var InitialTime = new Date().getTime();
    var extraSeconds = 0;
    var extraMins = 0;
    var firstLoad = 0;
    //-------Start Clock
    self.counter = null;
    self.recordtime = ko.observable();;
    self.seconds = ko.observable(0);
    self.minutes = ko.observable(0);
    self.hours = ko.observable(0);
    self.cssClock = ko.observable();
    self.idleActivityCounter = ko.observable(0);
    self.isIdleDisplay = ko.observable(true);

    self.setseconds = ko.computed(function () {       
        if (self.seconds() == 60) {
            return "00";
        }
        else {
            if (self.seconds() < 10)
                return "0" + self.seconds();
            else
                return self.seconds();
        }
    });

    self.setminutes = ko.computed(function () {
        if (self.minutes() == 60) {
            return "00";
        }
        else {
            if (self.minutes() < 10)
                return "0" + self.minutes();
            else
                return self.minutes();
        }
    });

    self.sethours = ko.computed(function () {
        if (self.hours() < 10)
            return "0" + self.hours();
        else
            return self.hours();
    });

    self.tick = function () {

        if (self.seconds() == 59) {
            if (self.minutes() == 59) {
                self.hours(self.hours() + 1);
                self.minutes(0);
                self.seconds(0);
            }
            else {
                self.minutes(self.minutes() + 1);
                self.seconds(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTime = new Date().getTime();
            var secondsDifference = 0;
            if (firstLoad === 0) {
                var secondsDifference = 0;
                firstLoad = 1;
            }
            else {
                secondsDifference = Math.floor((currentTime - InitialTime) / 1000);
            }

            if (secondsDifference == 0) {
                self.seconds(self.seconds() + 1);
            }
            else {
                if (self.seconds() + secondsDifference > 59) {
                    extraSeconds = self.seconds() + secondsDifference;
                    self.seconds(extraSeconds % 60)
                    extraMins = self.minutes() + Math.round(extraSeconds / 60);
                    if (extraMins > 59) {
                        self.minutes(extraMins % 60);
                        self.hours(self.hours() + Math.round(extraMins / 60));
                    }
                    else { self.minutes(extraMins); }
                    extraSeconds = 0;
                    extraMins = 0;
                }
                else {
                    self.seconds(self.seconds() + secondsDifference);
                }
            }
            InitialTime = currentTime;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounter(self.idleActivityCounter() + 1);
                var idleActivityCounterValue = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounter() == idleActivityCounterValue) {
                    if (self.isIdleDisplay() == true) {
                        self.isIdleDisplay(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for '+Constants.IdleTimerSettings.DurationInSecondsForPopup+' seconds.', 'Info');
                    }
                }
            }
        }
    }

    self.StartTimer = function () {
      
        InitialTime = new Date().getTime();
        firstLoad = 0;
        //set clock
        if (self.counter != null) {
            clearInterval(self.counter);
        }
        self.counter = setInterval(self.tick, 1000)
        // self.cssClock('timer-start');
    }

    self.ResetClock = function () {
        //set clock------------------
        InitialTime = new Date().getTime();
        firstLoad = 0;
        self.cssClock('');
        self.seconds(0);
        self.minutes(0);
        self.hours(0);
        clearInterval(self.counter);
        //set clock
        self.counter = setInterval(self.tick, 1000)
        self.cssClock('timer-start');
    }

    self.ResetIdleActivityCounter = function () {
        self.idleActivityCounter(0);
        self.isIdleDisplay(true);
    }
    //---------End Clock
}
var timerViewModel = new TimerViewModel();
//var timerViewModelCall = new TimerViewModel();
//var timerViewModelWeb = new TimerViewModel();
//var timerViewModelOutBound = new TimerViewModel();
$(document).ready(function () {
    try {          
        ko.applyBindings(timerViewModel, document.getElementById('divTimer'));
        //ko.applyBindings(timerViewModelCall, document.getElementById('divTimerCall'));
        //ko.applyBindings(timerViewModelWeb, document.getElementById('divTimerWeb'));
        //ko.applyBindings(timerViewModelOutBound, document.getElementById('divTimerOutBound'));
        timerViewModel.StartTimer();
        //timerViewModelCall.StartTimer();
        //timerViewModelWeb.StartTimer();
        //timerViewModelOutBound.StartTimer();

    } catch (e) {
        //logError(e, "Exception raised in Timer.js");
    }
    //toggleTimer();
});

//Adjust timer position when sidebar/header freezed
function setNewTimerPosition() {
    $('#divTimer').css({ 'top': '35px', 'z-index': '1002' });
    $('#divTimerCall').css({ 'top': '77px', 'z-index': '10' });
    $('#divTimerWeb').css({ 'top': '77px', 'z-index': '10' });
    $('#divTimerOutBound').css({ 'top': '77px', 'z-index': '10' });
}
function setPrevTimerPosition() {
    $('#divTimer').css({ 'top': '77px', 'z-index': '10' });
    $('#divTimerCall').css({ 'top': '77px', 'z-index': '10' });
    $('#divTimerWeb').css({ 'top': '77px', 'z-index': '10' });
    $('#divTimerOutBound').css({ 'top': '77px', 'z-index': '10' });
}