﻿function DeclareConstants() {
    Activity = 'activity';
    Task = 'task';    
}

function vm() {
    var self = this;

    ////Core
    self.AllActivity = ko.observableArray();
    self.isCoreClockVisisble = ko.observable(false);
    self.isDefaultCoreClockVisisble = ko.observable(false);
    self.isCoreStartButtonVisible = ko.observable(true);
    self.isCoreStopButtonVisible = ko.observable(false);
    self.isCoreStartButtonEnabled = ko.observable(true);
    self.isCoreStopButtonEnabled = ko.observable(true);
  
    self.Comments = ko.observable('');
    self.DD_CoreActivity = ko.observableArray();
    self.selectedCoreActivity = ko.observable('');

    self.DD_Tasks = ko.observableArray();
    self.selectedTask = ko.observable('');

    self.UniqueId = ko.observable('');

    self.GetInitialData = function () {

        var url = '/api/GetAllActivity?departmentid=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.AllActivity(result);                        
                        $.each(result, function (index, value) {
                            if (value.ActivityGroup.toLowerCase() == Activity && value.ParentId == 0) {
                                var tempData = { Id: value.Id, ActivityName: value.ActivityName };
                                self.DD_CoreActivity.push(tempData);                               
                            }
                        });

                    }
                } else {
                    var msg = "No Activities for department."
                    $('#cmnMsgText').text(msg);
                    $(".message_popup").show();
                }
            },
            error: function (returnVal) {
            }
        });
    };

    self.Change_CoreActivity = function () {
        var activityId = 0;
        self.DD_Tasks.removeAll();

        if (self.selectedCoreActivity() != null && self.selectedCoreActivity() != undefined) {
            $.each(self.DD_CoreActivity(), function (index, value) {
                if (value.ActivityName.toLowerCase() == self.selectedCoreActivity().toLowerCase()) {
                    activityId = value.Id;
                }
            });

            $.each(self.AllActivity(), function (index, value) {
                if (value.ActivityGroup.toLowerCase() == Task && value.ParentId == activityId) {
                    var tempData = { ActivityName: value.ActivityName, STT : value.STT };
                    self.DD_Tasks.push(tempData);
                }
            });
        }
    }

    self.StartCoreActivity = function () {
        
            sessionStorage.setItem('isCoreActivtyStarted', true);
            self.isCoreClockVisisble(true);         
            $("#IdSwitchTeam").prop('disabled', true); 
            var coreActivityJourney = {
                Id: 0,
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                UserId: 0,
                StartTime: new Date(),
                EndTime: null,
                Duration: 0,
                Remarks: self.Comments(),
                Param1: self.selectedCoreActivity() == null ? '' : self.selectedCoreActivity(),
                Param2: self.selectedTask() == null ? '' : self.selectedTask(),
                Param3: self.UniqueId(),
                Param4: '',
                Param5: '60',
                Param6: '',
                Param7: '',
                Param8: '',
                Param9: '',
                Param10: '',
                Param11: '',
                Param12: '',
                Param13: '',
                Param14: '',
                Param15: '',
                Param16: '',
                Param17: '',
                Param18: '',
                Param19: '',
                Param20: '',
                Param21: '',
                Param22: '',
                Param23: '',
                Param24: '',
                Param25: '',
                Param26: ''
            };

            var nonCoreActivityId = (sessionStorage.getItem("NonCoreActivityId") == undefined || sessionStorage.getItem("NonCoreActivityId") == null) ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));
            Commonmethods.PostAjaxData('/api/AddCoreActivity?activeNonCoreActivityId=' + nonCoreActivityId, 'POST', false, '', ko.toJSON(coreActivityJourney), 'Unable to add core activity', function (result) {                                
                self.StartTimerDCore();
                self.isDefaultCoreClockVisisble(true);
                $("#divDashboard").addClass("disabledbutton");
                $(".topbar").addClass("disabledbutton");
                $(".side-menu").addClass("disabledbutton");
                sessionStorage.setItem("CoreActivityId", result);              
                self.isCoreStartButtonVisible(false);
                self.isCoreStopButtonVisible(true);
            });
    };

    self.EndCoreActivity = function () {

        if (self.coreEndBtnErrors().length == 0) {
            var STT = '0';

            $.each(self.DD_Tasks(), function (index, value) {
                if (value.ActivityName.toLowerCase() == self.selectedTask().toLowerCase()) {
                    STT = value.STT;
                }
            });

            self.isCoreClockVisisble(false);
            var coreActivityJourney = {
                Id: sessionStorage.getItem("CoreActivityId"),
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                UserId: 0,
                StartTime: new Date(),
                EndTime: null,
                Duration: 0,
                Remarks: self.Comments(),
                Param1: self.selectedCoreActivity(),
                Param2: self.selectedTask(),
                Param3: self.UniqueId(),
                Param4: '',
                Param5: STT,
                Param6: '',
                Param7: '',
                Param8: '',
                Param9: '',
                Param10: '',
                Param11: '',
                Param12: '',
                Param13: '',
                Param14: '',
                Param15: '',
                Param16: '',
                Param17: '',
                Param18: '',
                Param19: '',
                Param20: '',
                Param21: '',
                Param22: '',
                Param23: '',
                Param24: '',
                Param25: '',
                Param26: ''
            };

            Commonmethods.PostAjaxData('/api/UpdateCoreActivity/', 'POST', false, '', ko.toJSON(coreActivityJourney), 'Unable to add core activity', function (result) {
                
                sessionStorage.setItem('isCoreActivtyStarted', false);
                sessionStorage.setItem("NonCoreActivityId", result); 
                $("#divDashboard").removeClass("disabledbutton");
                $(".topbar").removeClass("disabledbutton");
                $(".side-menu").removeClass("disabledbutton");
                $("#IdSwitchTeam").prop('disabled', true); 
                self.StopClockDCore();
                self.isDefaultCoreClockVisisble(false);                
                self.isCoreStartButtonVisible(true);
                self.isCoreStopButtonVisible(false);                  
                sessionStorage.setItem("CoreActivityId", 0);
                self.ResetCore();
                self.coreEndBtnErrors.showAllMessages(false);
            });
        } else {
            self.coreEndBtnErrors.showAllMessages();
        }
    };

    self.ResetCore = function () {
        self.Comments('');
        self.selectedTask(null);
        self.selectedCoreActivity(null);
        self.UniqueId('');
    };

    ////Core Validation
    self.selectedCoreActivity.extend({
        required: {
            param: true,
            message: "Please select an Activity."
        }
    }); 

    self.selectedTask.extend({
        required: {
            param: true,
            message: "Please select a task."
        }
    });
    
    let CoreEndBtnValidationFields = [self.selectedCoreActivity, self.selectedTask];
    self.coreEndBtnErrors = ko.validation.group(CoreEndBtnValidationFields);
    
    ////Timers
    //none timer
    var InitialTimeDCore = new Date().getTime();
    var extraSecondsDCore = 0;
    var extraMinsDCore = 0;
    var firstLoadDCore = 0;
    //-------Start Clock
    self.counterDCore = null;
    self.recordtimeDCore = ko.observable();;
    self.secondsDCore = ko.observable(0);
    self.minutesDCore = ko.observable(0);
    self.hoursDCore = ko.observable(0);
    self.cssClockDCore = ko.observable();
    self.idleActivityCounterDCore = ko.observable(0);
    self.isIdleDisplayDCore = ko.observable(true);

    self.setDCoreSeconds = ko.computed(function () {
        if (self.secondsDCore() == 60) {
            return "00";
        }
        else {
            if (self.secondsDCore() < 10)
                return "0" + self.secondsDCore();
            else
                return self.secondsDCore();
        }
    });

    self.setDCoreMinutes = ko.computed(function () {
        if (self.minutesDCore() == 60) {
            return "00";
        }
        else {
            if (self.minutesDCore() < 10)
                return "0" + self.minutesDCore();
            else
                return self.minutesDCore();
        }
    });

    self.setDCoreHours = ko.computed(function () {
        if (self.hoursDCore() < 10)
            return "0" + self.hoursDCore();
        else
            return self.hoursDCore();
    });

    self.tickDCore = function () {

        if (self.secondsDCore() == 59) {
            if (self.minutesDCore() == 59) {
                self.hoursDCore(self.hoursDCore() + 1);
                self.minutesDCore(0);
                self.secondsDCore(0);
            }
            else {
                self.minutesDCore(self.minutesDCore() + 1);
                self.secondsDCore(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTimeDCore = new Date().getTime();
            var secondsDifferenceDCore = 0;
            if (firstLoadDCore === 0) {
                var secondsDifferenceDCore = 0;
                firstLoadDCore = 1;
            }
            else {
                secondsDifferenceDCore = Math.floor((currentTimeDCore - currentTimeDCore) / 1000);
            }

            if (secondsDifferenceDCore == 0) {
                self.secondsDCore(self.secondsDCore() + 1);
            }
            else {
                if (self.secondsDCore() + secondsDifferenceDCore > 59) {
                    extraSecondsDCore = self.secondsDCore() + secondsDifferenceDCore;
                    self.secondsDCore(extraSecondsDCore % 60)
                    extraMinsDCore = self.minutesDCore() + Math.round(extraSecondsDCore / 60);
                    if (extraMinsDCore > 59) {
                        self.minutesDCore(extraMinsDCore % 60);
                        self.hoursDCore(self.hoursDCore() + Math.round(extraMinsDCore / 60));
                    }
                    else { self.minutesDCore(extraMinsDCore); }
                    extraSecondsDCore = 0;
                    extraMinsDCore = 0;
                }
                else {
                    self.secondsDCore(self.secondsDCore() + secondsDifferenceDCore);
                }
            }
            InitialTimeDCore = currentTimeDCore;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounterDCore(self.idleActivityCounterDCore() + 1);
                var idleActivityCounterValueDCore = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounterDCore() == idleActivityCounterValueDCore) {
                    if (self.isIdleDisplayDCore() == true) {
                        self.isIdleDisplayDCore(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }
    self.StartTimerDCore = function () {

        InitialTimeDCore = new Date().getTime();
        firstLoadDCore = 0;
        //set clock
        if (self.counterDCore != null) {
            clearInterval(self.counterDCore);
        }
        self.counterDCore = setInterval(self.tickDCore, 1000)
        // self.cssClock('timer-start');
    }
    self.StopClockDCore = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoadDCore = 0;
        self.cssClockDCore('');
        self.secondsDCore(0);
        self.minutesDCore(0);
        self.hoursDCore(0);
        clearInterval(self.counterDCore);
    }
    self.ResetIdleActivityCounterDCore = function () {
        self.idleActivityCounterDCore(0);
        self.isIdleDisplayDCore(true);
    }
    //end Non core
    //end timer

}

$(document).ready(function () {
    var defaultVM = new vm();
    DeclareConstants();
    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);
   
    ko.applyBindings(defaultVM, document.getElementById('defaultDiv'));
    defaultVM.GetInitialData();
    defaultVM.coreEndBtnErrors.showAllMessages(false);
});