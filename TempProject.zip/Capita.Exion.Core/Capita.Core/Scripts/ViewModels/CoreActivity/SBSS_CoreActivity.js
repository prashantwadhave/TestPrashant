﻿var coreViewmodel = new vm();
var isPause = false;
$(function () {
    DeclareConstants();

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    ko.applyBindings(coreViewmodel, document.getElementById('sbssCore'));
    //coreViewmodel.StartTimerCore();
    coreViewmodel.GetInitialData();
});

function DeclareConstants() {
    Schemes = 'scheme';
    Task = 'task';
    Channel = 'channel';
    CallCode = 'callcode';
    CallResolution = 'callresolution';
}

function vm() {
    var self = this;

    ////Core
    self.AllActivity = ko.observableArray();
    self.isCoreClockVisisble = ko.observable(false);
    self.isCallClockVisisble = ko.observable(false);
    self.isWebClockVisisble = ko.observable(false);
    self.isOutboundCallClockVisisble = ko.observable(false);

    self.isCoreStartButtonVisible = ko.observable(true);
    self.isCoreStopButtonVisible = ko.observable(false);
    self.isCoreStartButtonEnabled = ko.observable(true);
    self.isCoreStopButtonEnabled = ko.observable(true);
    self.dd_isCoreSchemeEnabled = ko.observable(true);
    
    self.UniqueId = ko.observable('');
    self.Comments = ko.observable('');
    self.DD_CoreSchemes = ko.observableArray();
    self.selectedCoreScheme = ko.observable();

    self.DD_Tasks = ko.observableArray();
    self.selectedTask = ko.observable();

    self.GetInitialData = function () {

        if (self.AllActivity().length > 0)
            self.AllActivity.removeAll();

        if (self.DD_CoreSchemes().length > 0)
            self.DD_CoreSchemes.removeAll();

        if (self.DD_CallSchemes().length > 0)
            self.DD_CallSchemes.removeAll();

        var url = '/api/GetAllActivity?departmentid=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.AllActivity(result);

                        $.each(result, function (index, value) {
                            if (value.ActivityGroup.toLowerCase() == Schemes && value.ParentId == 0) {
                                var tempData = { Id: value.Id, ActivityName: value.ActivityName };
                                self.DD_CoreSchemes.push(tempData);
                                self.DD_CallSchemes.push(tempData);
                            }
                        });

                    }
                } else {
                    var msg = "No Activities for department."
                    $('#cmnMsgText').text(msg);
                    $(".message_popup").show();
                }
            },
            error: function (returnVal) {
            }
        });
    };

    self.Change_CoreScheme = function () {
        var schemeId = 0;
        self.DD_Tasks.removeAll();

        if (self.selectedCoreScheme() != null && self.selectedCoreScheme() != undefined) {
            $.each(self.DD_CoreSchemes(), function (index, value) {
                if (value.ActivityName.toLowerCase() == self.selectedCoreScheme().toLowerCase()) {
                    schemeId = value.Id;
                }
            });

            $.each(self.AllActivity(), function (index, value) {
                if (value.ActivityGroup.toLowerCase() == Task && value.ParentId == schemeId) {
                    var tempData = { ActivityName: value.ActivityName, STT: value.STT };
                    self.DD_Tasks.push(tempData);
                }
            });
        }
    }

    self.StartCoreActivity = function () {

        if (self.coreStartBtnErrors().length == 0) {
            $("#IdSwitchTeam").prop('disabled', true); 
            self.StartTimerCore();
            sessionStorage.setItem('isCoreActivtyStarted', true);
            self.isCoreClockVisisble(true);
            var coreActivityJourney = {
                Id: 0,
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                UserId: 0,
                StartTime: new Date(),
                EndTime: null,
                Duration: 0,
                Remarks: self.Comments(),
                Param1: self.selectedCoreScheme(),
                Param2: '',
                Param3: self.selectedTask(),
                Param4: '',
                Param5: '60',
                Param6: '',
                Param7: '',
                Param8: '',
                Param9: '',
                Param10: '',
                Param11: '',
                Param12: '',
                Param13: '',
                Param14: '',
                Param15: '',
                Param16: '',
                Param17: '',
                Param18: '',
                Param19: '',
                Param20: '',
                Param21: '',
                Param22: '',
                Param23: '',
                Param24: '',
                Param25: '',
                Param26: ''
            };

            var nonCoreActivityId = (sessionStorage.getItem("NonCoreActivityId") == undefined || sessionStorage.getItem("NonCoreActivityId") == null) ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));
            Commonmethods.PostAjaxData('/api/AddCoreActivity?activeNonCoreActivityId=' + nonCoreActivityId, 'POST', false, '', ko.toJSON(coreActivityJourney), 'Unable to add core activity', function (result) {
                sessionStorage.setItem("CoreActivityId", result);
                $("#divDashboard").addClass("disabledbutton");
                $(".topbar").addClass("disabledbutton");
                $(".side-menu").addClass("disabledbutton");
                $("#btnReferesh").addClass("disabledbutton");

                self.dd_isCoreSchemeEnabled(false);
                
                self.isCoreStartButtonVisible(false);
                self.isCoreStopButtonVisible(true);
            });
        } else {
            self.coreStartBtnErrors.showAllMessages();
        }
    };

    self.EndCoreActivity = function () {
        var STT = '0';

        if (self.coreEndBtnErrors().length == 0) {
            $("#IdSwitchTeam").prop('disabled', false); 
            $.each(self.DD_Tasks(), function (index, value) {
                if (value.ActivityName.toLowerCase() == self.selectedTask().toLowerCase()) {
                    STT = value.STT;
                }
            });
            self.StopClockCore();
            self.isCoreClockVisisble(false);
            var coreActivityJourney = {
                Id: sessionStorage.getItem("CoreActivityId"),
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                UserId: 0,
                StartTime: new Date(),
                EndTime: null,
                Duration: 0,
                Remarks: self.Comments(),
                Param1: self.selectedCoreScheme(),
                Param2: self.UniqueId(),
                Param3: self.selectedTask(),
                Param4: '',
                Param5: STT,
                Param6: '',
                Param7: '',
                Param8: '',
                Param9: '',
                Param10: '',
                Param11: '',
                Param12: '',
                Param13: '',
                Param14: '',
                Param15: '',
                Param16: '',
                Param17: '',
                Param18: '',
                Param19: '',
                Param20: '',
                Param21: '',
                Param22: '',
                Param23: '',
                Param24: '',
                Param25: '',
                Param26: ''
            };

            Commonmethods.PostAjaxData('/api/UpdateCoreActivity/', 'POST', false, '', ko.toJSON(coreActivityJourney), 'Unable to add core activity', function (result) {

                if (result == -1 || result == '-1') {
                    $('#lblUniqueMsg').css('display', 'block');
                } else {
                    $('#lblUniqueMsg').css('display', 'none');
                    sessionStorage.setItem('isCoreActivtyStarted', false);
                    sessionStorage.setItem("NonCoreActivityId", result);
                    //timerViewModel.ResetClock();
                    self.isCoreStartButtonVisible(true);
                    self.isCoreStopButtonVisible(false);
                    self.dd_isCoreSchemeEnabled(true);
                    
                    sessionStorage.setItem("CoreActivityId", 0);
                    self.ResetCore();
                    self.coreStartBtnErrors.showAllMessages(false);
                    self.coreEndBtnErrors.showAllMessages(false);

                    $("#divDashboard").removeClass("disabledbutton");
                    $(".topbar").removeClass("disabledbutton");
                    $(".side-menu").removeClass("disabledbutton");
                    $("#btnReferesh").removeClass("disabledbutton");
                }
            });
        } else {
            self.coreEndBtnErrors.showAllMessages();
        }
    };

    self.ResetCore = function () {
        //console.log('null');
        self.Comments('');
        self.UniqueId('');
        self.selectedTask(null);
        self.selectedCoreScheme(null);
    }

    ////Core Validation
    self.selectedCoreScheme.extend({
        required: {
            param: true,
            message: "Please select a scheme."
        }
    });

    //self.UniqueId.extend({
    //    required: {
    //        param: true,
    //        message: "Please choose a unique id."
    //    }
    //});

    self.selectedTask.extend({
        required: {
            param: true,
            message: "Please select a task."
        }
    });

    let CoreStartBtnValidationFields = [self.selectedCoreScheme, self.selectedTask];
    self.coreStartBtnErrors = ko.validation.group(CoreStartBtnValidationFields);

    let CoreEndBtnValidationFields = [self.selectedTask];
    self.coreEndBtnErrors = ko.validation.group(CoreEndBtnValidationFields);

    ////Calls
    self.isCallStartButtonVisible = ko.observable(true);
    self.isCallStopButtonVisible = ko.observable(false);
    self.isCallStartButtonEnabled = ko.observable(true);
    self.isCallStopButtonEnabled = ko.observable(true);

    self.DD_CallSchemes = ko.observableArray();
    self.selectedCallScheme = ko.observable();

    self.DD_CallCode = ko.observableArray();
    self.selectedCallCode = ko.observable();

    self.DD_CallResolution = ko.observableArray();
    self.selectedCallResolution = ko.observable();

    self.Change_CallScheme = function () {
        var schemeCallId = 0;
        self.DD_CallCode.removeAll();
        self.DD_CallResolution.removeAll();

        if (self.selectedCallScheme() != null && self.selectedCallScheme() != undefined) {
            $.each(self.DD_CallSchemes(), function (index, value) {
                if (value.ActivityName.toLowerCase() == self.selectedCallScheme().toLowerCase()) {
                    schemeCallId = value.Id;
                }
            });

            $.each(self.AllActivity(), function (index, value) {
                if (value.ActivityGroup.toLowerCase() == CallCode && value.ParentId == schemeCallId) {
                    var tempData = { ActivityName: value.ActivityName };
                    self.DD_CallCode.push(tempData);
                }
            });

            $.each(self.AllActivity(), function (index, value) {
                if (value.ActivityGroup.toLowerCase() == CallResolution && value.ParentId == schemeCallId) {
                    var tempData = { ActivityName: value.ActivityName };
                    self.DD_CallResolution.push(tempData);
                }
            });
        }
    }

    self.StartCallActivity = function () {
        self.StartTimerCall();
        isPause = true;
        $("#IdSwitchTeam").prop('disabled', true); 
        $("#outboundcall").addClass("disabledbutton");
        $(".card-box-new").addClass("disabledbutton");
        $("#divDashboard").addClass("disabledbutton");
        $(".coreactivity").addClass("disabledbutton");
        $(".topbar").addClass("disabledbutton");
        $(".side-menu").addClass("disabledbutton");
        sessionStorage.setItem('isCallActivtyStarted', true);
        self.isCallClockVisisble(true);
        var callActivityJourney = {
            UserId: 0,
            DepartmentId: sessionStorage.getItem("DepartmentId"),
            TeamId: sessionStorage.getItem("TeamId"),
            StartTime: new Date(),
            EndTime: null,
            Duration: 0,
            Scheme: '',
            CallCode: '',
            CallCodeResolution: ''
        };
        
        var nonCoreActivityId = (sessionStorage.getItem("NonCoreActivityId") == undefined || sessionStorage.getItem("NonCoreActivityId") == null) ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));
        var url = '/api/AddCallActivity?activeNonCoreActivityId=' + nonCoreActivityId;
        Commonmethods.PostAjaxData(url, 'POST', false, '', ko.toJSON(callActivityJourney), 'Unable to add call activity', function (result) {
            sessionStorage.setItem("CallActivityId", result);
            nonCoreViewModel.isNonCoreStartButtonEnabled(false);
            nonCoreViewModel.isNonCoreStopButtonEnabled(false);
            self.isCallStartButtonVisible(false);
            self.isCallStopButtonVisible(true);
            self.isCoreStartButtonEnabled(false);
            self.isCoreStopButtonEnabled(false);
        });
    };

    self.EndCallActivity = function () {

        if (self.callEndBtnErrors().length == 0) {
            self.isCallClockVisisble(false);
            self.StopClockCall();
            var callActivityJourney = {
                Id: sessionStorage.getItem("CallActivityId"),
                UserId: 0,
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                StartTime: new Date(),
                EndTime: null,
                Duration: 0,
                Scheme: self.selectedCallScheme(),
                CallCode: self.selectedCallCode(),
                CallCodeResolution: self.selectedCallResolution()
            };

            var isCoreActivtyStarted = (sessionStorage.getItem('isCoreActivtyStarted') == undefined || sessionStorage.getItem('isCoreActivtyStarted') == null) ? false : sessionStorage.getItem('isCoreActivtyStarted');
            var isWebChatActivityStarted = (sessionStorage.getItem('isWebChatActivtyStarted') == undefined || sessionStorage.getItem('isWebChatActivtyStarted') == null) ? false : sessionStorage.getItem('isWebChatActivtyStarted');
            var url = '/api/UpdateCallActivity?isCoreActivtyStarted=' + isCoreActivtyStarted + '&isWebChatActivityStarted=' + isWebChatActivityStarted;

            Commonmethods.PostAjaxData(url, 'POST', false, '', ko.toJSON(callActivityJourney), 'Unable to update call activity', function (result) {
                sessionStorage.setItem('isCallActivtyStarted', false);
                sessionStorage.setItem("NonCoreActivityId", result);
                nonCoreViewModel.isNonCoreStartButtonEnabled(true);
                nonCoreViewModel.isNonCoreStopButtonEnabled(true);
                self.isCallStartButtonVisible(true);
                self.isCallStopButtonVisible(false);
                self.isCoreStartButtonEnabled(true);
                self.isCoreStopButtonEnabled(true);
                sessionStorage.setItem("CallActivityId", 0);
                self.ResetCall();
                self.callEndBtnErrors.showAllMessages(false);
                $("#outboundcall").removeClass("disabledbutton");
                var flag = false;                
                if (sessionStorage.getItem('isWebChatActivtyStarted') == null || sessionStorage.getItem('isWebChatActivtyStarted') == 'false' || sessionStorage.getItem('isWebChatActivtyStarted') == false) {
                    $(".card-box-new").removeClass("disabledbutton");
                    $("#divDashboard").removeClass("disabledbutton");
                    $(".coreactivity").removeClass("disabledbutton");
                    $(".topbar").removeClass("disabledbutton");
                    $(".side-menu").removeClass("disabledbutton");
                    $("#IdSwitchTeam").prop('disabled', false); 

                    flag = true;
                    isPause = false;
                }
                if ((sessionStorage.getItem('isCoreActivtyStarted') == true || sessionStorage.getItem('isCoreActivtyStarted') == "true") && flag) {
                    $(".card-box-new").removeClass("disabledbutton");
                    $("#divDashboard").addClass("disabledbutton");
                    $(".coreactivity").removeClass("disabledbutton");
                    $(".topbar").addClass("disabledbutton");
                    $(".side-menu").addClass("disabledbutton");
                    $("#IdSwitchTeam").prop('disabled', true); 
                    isPause = false;
                }
            });
        } else {
            self.callEndBtnErrors.showAllMessages();
        }
    };

    self.ResetCall = function () {

        self.selectedCallScheme(null);
        self.selectedCallCode(null);
        self.selectedCallResolution(null);
    }

    ////Validation

    self.selectedCallScheme.extend({
        required: {
            param: true,
            message: "Please select a scheme."
        }
    });

    self.selectedCallCode.extend({
        required: {
            param: true,
            message: "Please select a call code."
        }
    });

    self.selectedCallResolution.extend({
        required: {
            param: true,
            message: "Please select a call resolution."
        }
    });

    let CallEndBtnValidationFields = [self.selectedCallScheme, self.selectedCallCode, self.selectedCallResolution];
    self.callEndBtnErrors = ko.validation.group(CallEndBtnValidationFields);

    ////Web Chat
    self.isWebChatStartButtonVisible = ko.observable(true);
    self.isWebChatStopButtonVisible = ko.observable(false);
    self.isWebChatStartButtonEnabled = ko.observable(true);
    self.isWebChatStopButtonEnabled = ko.observable(true);
    self.WebChatComment = ko.observable('');

    self.StartWebChatActivity = function () {
        self.StartTimerWeb();
        //isPause = true;
        $("#IdSwitchTeam").prop('disabled', true); 
        $(".card-box-new").addClass("disabledbutton");
        $("#divDashboard").addClass("disabledbutton");
        $(".coreactivity").addClass("disabledbutton");
        $(".topbar").addClass("disabledbutton");
        $(".side-menu").addClass("disabledbutton");
        isPause = true;
        self.isWebClockVisisble(true);
        sessionStorage.setItem('isWebChatActivtyStarted', true);

        var nonCoreActivityId = (sessionStorage.getItem("NonCoreActivityId") == undefined || sessionStorage.getItem("NonCoreActivityId") == null) ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));

        var url = '/api/AddWebChatActivity?departmentId=' + sessionStorage.getItem("DepartmentId") + '&comment=' + self.WebChatComment() + '&activeNonCoreActivityId=' + nonCoreActivityId + '&teamId=' + sessionStorage.getItem("TeamId") ;

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unable to add web chat activity', function (result) {
            sessionStorage.setItem("WebChatActivityId", result);
            nonCoreViewModel.isNonCoreStartButtonEnabled(false);
            nonCoreViewModel.isNonCoreStopButtonEnabled(false);
            self.isCoreStartButtonEnabled(false);
            self.isCoreStopButtonEnabled(false);
            self.isWebChatStartButtonVisible(false);
            self.isWebChatStopButtonVisible(true);
        });
    };

    self.EndWebChatActivity = function () {
        self.isWebClockVisisble(false);
        self.StopClockWeb();
        var isCoreActivtyStarted = (sessionStorage.getItem('isCoreActivtyStarted') == undefined || sessionStorage.getItem('isCoreActivtyStarted') == null) ? false : sessionStorage.getItem('isCoreActivtyStarted');
        var isCallActivtyStarted = (sessionStorage.getItem('isCallActivtyStarted') == undefined || sessionStorage.getItem('isCallActivtyStarted') == null) ? false : sessionStorage.getItem('isCallActivtyStarted');
        var isOutBoundActivtyStarted = (sessionStorage.getItem('isOutbondCallStarted') == undefined || sessionStorage.getItem('isOutbondCallStarted') == null) ? false : sessionStorage.getItem('isOutbondCallStarted');
        var url = '/api/UpdateWebChatActivity?webChatID=' + sessionStorage.getItem("WebChatActivityId") + '&comment=' + self.WebChatComment() + '&isCoreActivtyStarted=' + isCoreActivtyStarted + '&isCallActivtyStarted=' + isCallActivtyStarted + '&isOutBoundActivtyStarted=' + isOutBoundActivtyStarted;

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unable to update web chat activity', function (result) {
            sessionStorage.setItem('isWebChatActivtyStarted', false);
            sessionStorage.setItem("NonCoreActivityId", result);
            nonCoreViewModel.isNonCoreStartButtonEnabled(true);
            nonCoreViewModel.isNonCoreStopButtonEnabled(true);
            self.WebChatComment('');
            self.isCoreStartButtonEnabled(true);
            self.isCoreStopButtonEnabled(true);
            self.isWebChatStartButtonVisible(true);
            self.isWebChatStopButtonVisible(false);
            sessionStorage.setItem("WebChatActivityId", 0);
            var flag = false;
            //isPause = false;
            if ((sessionStorage.getItem('isCallActivtyStarted') == null || sessionStorage.getItem('isCallActivtyStarted') == 'false' || sessionStorage.getItem('isCallActivtyStarted') == false) &&
                (sessionStorage.getItem('isOutbondCallStarted') == null || sessionStorage.getItem('isOutbondCallStarted') == 'false' || sessionStorage.getItem('isOutbondCallStarted') == false)) {
                flag = true;
                $(".card-box-new").removeClass("disabledbutton");
                $("#divDashboard").removeClass("disabledbutton");
                $(".coreactivity").removeClass("disabledbutton");
                $(".topbar").removeClass("disabledbutton");
                $(".side-menu").removeClass("disabledbutton");
                $("#IdSwitchTeam").prop('disabled', false); 

                isPause = false;
            }

            if ((sessionStorage.getItem('isCoreActivtyStarted') == true || sessionStorage.getItem('isCoreActivtyStarted') == "true") && flag) {
                $(".card-box-new").removeClass("disabledbutton");
                $("#divDashboard").addClass("disabledbutton");
                $(".coreactivity").removeClass("disabledbutton");
                $(".topbar").addClass("disabledbutton");
                $(".side-menu").addClass("disabledbutton");
                $("#IdSwitchTeam").prop('disabled', true); 
                isPause = false;
            }
        });
    };

    /// Outbound Call 
    self.isOutboundCallStartButtonVisible = ko.observable(true);
    self.isOutboundCallStopButtonVisible = ko.observable(false);
    self.isOutboundCallStartButtonEnabled = ko.observable(true);
    self.isOutboundCallStopButtonEnabled = ko.observable(true);
    self.OutboundCallComment = ko.observable('');

    self.StartOutboundCallActivity = function () {
        self.StartTimer();
        //isPause = true;
        $("#callex").addClass("disabledbutton");
        $(".card-box-new").addClass("disabledbutton");
        $("#divDashboard").addClass("disabledbutton");
        $(".coreactivity").addClass("disabledbutton");
        $(".topbar").addClass("disabledbutton");
        $(".side-menu").addClass("disabledbutton");
        $("#IdSwitchTeam").prop('disabled', true); 
        isPause = true;
        self.isOutboundCallClockVisisble(true);

        var nonCoreActivityId = (sessionStorage.getItem("NonCoreActivityId") == undefined || sessionStorage.getItem("NonCoreActivityId") == null) ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));

        var url = '/api/AddOutbondCallActivity?departmentId=' + sessionStorage.getItem("DepartmentId") + '&comment=' + self.OutboundCallComment() + '&activeNonCoreActivityId=' + nonCoreActivityId + '&teamId=' + sessionStorage.getItem("TeamId");;

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unable to add outbound call activity', function (result) {
            sessionStorage.setItem("OutbondCallActivityId", result);
            sessionStorage.setItem('isOutbondCallStarted', true);
            nonCoreViewModel.isNonCoreStartButtonEnabled(false);
            nonCoreViewModel.isNonCoreStopButtonEnabled(false);
            self.isCoreStartButtonEnabled(false);
            self.isCoreStopButtonEnabled(false);
            self.isOutboundCallStartButtonEnabled(false);
            self.isOutboundCallStopButtonEnabled(true);
            self.isOutboundCallStopButtonVisible(true);
            self.isOutboundCallStartButtonVisible(false);
        });
    };

    self.EndOutboundCallActivity = function () {
        self.StopClock();
        $("#callex").removeClass("disabledbutton");
        self.isOutboundCallClockVisisble(false);
        var isCoreActivtyStarted = (sessionStorage.getItem('isCoreActivtyStarted') == undefined || sessionStorage.getItem('isCoreActivtyStarted') == null) ? false : sessionStorage.getItem('isCoreActivtyStarted');
        var isCallActivtyStarted = (sessionStorage.getItem('isCallActivtyStarted') == undefined || sessionStorage.getItem('isCallActivtyStarted') == null) ? false : sessionStorage.getItem('isCallActivtyStarted');
        var isWebChatActivityStarted = (sessionStorage.getItem('isWebChatActivtyStarted') == undefined || sessionStorage.getItem('isWebChatActivtyStarted') == null) ? false : sessionStorage.getItem('isWebChatActivtyStarted');

        var url = '/api/UpdateOutboundCallActivity?OCallId=' + sessionStorage.getItem("OutbondCallActivityId") + '&comment=' + self.OutboundCallComment() + '&isCoreActivtyStarted=' + isCoreActivtyStarted + '&isChatActivtyStarted=' + isWebChatActivityStarted;

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unable to update web chat activity', function (result) {
            sessionStorage.setItem('isOutbondCallStarted', false);
            sessionStorage.setItem("NonCoreActivityId", result);
            nonCoreViewModel.isNonCoreStartButtonEnabled(true);
            nonCoreViewModel.isNonCoreStopButtonEnabled(true);
            self.OutboundCallComment('');
            self.isCoreStartButtonEnabled(true);
            self.isCoreStopButtonEnabled(true);
            self.isOutboundCallStartButtonEnabled(true);
            self.isOutboundCallStopButtonEnabled(false);
            self.isOutboundCallStopButtonVisible(false);
            self.isOutboundCallStartButtonVisible(true);

            sessionStorage.setItem("OutbondCallActivityId", 0);
            var flag = false;
            //isPause = false;
            if (sessionStorage.getItem('isWebChatActivtyStarted') == null || sessionStorage.getItem('isWebChatActivtyStarted') == 'false' || sessionStorage.getItem('isWebChatActivtyStarted') == false) {
                $(".card-box-new").removeClass("disabledbutton");
                $("#divDashboard").removeClass("disabledbutton");
                $(".coreactivity").removeClass("disabledbutton");
                $(".topbar").removeClass("disabledbutton");
                $(".side-menu").removeClass("disabledbutton");
                $("#IdSwitchTeam").prop('disabled', false); 

                flag = true;
                isPause = false;
            }

            if ((sessionStorage.getItem('isCoreActivtyStarted') == true || sessionStorage.getItem('isCoreActivtyStarted') == "true") && flag) {
                $(".card-box-new").removeClass("disabledbutton");
                $("#divDashboard").addClass("disabledbutton");
                $(".coreactivity").removeClass("disabledbutton");
                $(".topbar").addClass("disabledbutton");
                $(".side-menu").addClass("disabledbutton");
                $("#IdSwitchTeam").prop('disabled', true); 
                isPause = false;
            }
        });
    };

    ////Timers
    var InitialTimeCore = new Date().getTime();
    var extraSecondsCore = 0;
    var extraMinsCore = 0;
    var firstLoadCore = 0;
    //-------Start Clock
    self.counterCore = null;
    self.recordtimeCore = ko.observable();;
    self.secondsCore = ko.observable(0);
    self.minutesCore = ko.observable(0);
    self.hoursCore = ko.observable(0);
    self.cssClockCore = ko.observable();
    self.idleActivityCounterCore = ko.observable(0);
    self.isIdleDisplayCore = ko.observable(true);

    self.setCoreSeconds = ko.computed(function () {
        if (self.secondsCore() == 60) {
            return "00";
        }
        else {
            if (self.secondsCore() < 10)
                return "0" + self.secondsCore();
            else
                return self.secondsCore();
        }
    });

    self.setCoreMinutes = ko.computed(function () {
        if (self.minutesCore() == 60) {
            return "00";
        }
        else {
            if (self.minutesCore() < 10)
                return "0" + self.minutesCore();
            else
                return self.minutesCore();
        }
    });

    self.setCoreHours = ko.computed(function () {
        if (self.hoursCore() < 10)
            return "0" + self.hoursCore();
        else
            return self.hoursCore();
    });

    self.tickCore = function () {

        if (self.secondsCore() == 59) {
            if (self.minutesCore() == 59) {
                self.hoursCore(self.hoursCore() + 1);
                self.minutesCore(0);
                self.secondsCore(0);
            }
            else {
                self.minutesCore(self.minutesCore() + 1);
                self.secondsCore(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTimeCore = new Date().getTime();
            var secondsDifferenceCore = 0;
            if (firstLoadCore === 0) {
                var secondsDifferenceCore = 0;
                firstLoadCore = 1;
            }
            else {
                secondsDifferenceCore = Math.floor((currentTimeCore - currentTimeCore) / 1000);
            }

            if (secondsDifferenceCore == 0) {
                self.secondsCore(self.secondsCore() + 1);
            }
            else {
                if (self.secondsCore() + secondsDifferenceCore > 59) {
                    extraSecondsCore = self.secondsCore() + secondsDifferenceCore;
                    self.secondsCore(extraSecondsCore % 60)
                    extraMinsCore = self.minutesCore() + Math.round(extraSecondsCore / 60);
                    if (extraMinsCore > 59) {
                        self.minutesCore(extraMinsCore % 60);
                        self.hoursCore(self.hoursCore() + Math.round(extraMinsCore / 60));
                    }
                    else { self.minutesCore(extraMinsCore); }
                    extraSecondsCore = 0;
                    extraMinsCore = 0;
                }
                else {
                    self.secondsCore(self.secondsCore() + secondsDifferenceCore);
                }
            }
            InitialTimeCore = currentTimeCore;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounterCore(self.idleActivityCounterCore() + 1);
                var idleActivityCounterValueCore = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounterCore() == idleActivityCounterValueCore) {
                    if (self.isIdleDisplayCore() == true) {
                        self.isIdleDisplayCore(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }
    self.StartTimerCore = function () {

        InitialTimeCore = new Date().getTime();
        firstLoadCore = 0;
        //set clock
        if (self.counterCore != null) {
            clearInterval(self.counterCore);
        }
        self.counterCore = setInterval(function () { if (!isPause) { self.tickCore() }}, 1000)
        // self.cssClock('timer-start');
    }
    self.StopClockCore = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoadCore = 0;
        self.cssClockCore('');
        self.secondsCore(0);
        self.minutesCore(0);
        self.hoursCore(0);
        clearInterval(self.counterCore);
    }
    self.ResetIdleActivityCounterCore = function () {
        self.idleActivityCounterCore(0);
        self.isIdleDisplayCore(true);
    }
    //end core

    //call
    var InitialTimeCall = new Date().getTime();
    var extraSecondsCall = 0;
    var extraMinsCall = 0;
    var firstLoadCall = 0;
    //-------Start Clock
    self.counterCall = null;
    self.recordtimeCall = ko.observable();;
    self.secondsCall = ko.observable(0);
    self.minutesCall = ko.observable(0);
    self.hoursCall = ko.observable(0);
    self.cssClockCall = ko.observable();
    self.idleActivityCounterCall = ko.observable(0);
    self.isIdleDisplayCall = ko.observable(true);

    self.setCallSeconds = ko.computed(function () {
        if (self.secondsCall() == 60) {
            return "00";
        }
        else {
            if (self.secondsCall() < 10)
                return "0" + self.secondsCall();
            else
                return self.secondsCall();
        }
    });

    self.setCallMinutes = ko.computed(function () {
        if (self.minutesCall() == 60) {
            return "00";
        }
        else {
            if (self.minutesCall() < 10)
                return "0" + self.minutesCall();
            else
                return self.minutesCall();
        }
    });

    self.setCallHours = ko.computed(function () {
        if (self.hoursCall() < 10)
            return "0" + self.hoursCall();
        else
            return self.hoursCall();
    });

    self.tickCall = function () {

        if (self.secondsCall() == 59) {
            if (self.minutesCall() == 59) {
                self.hoursCall(self.hoursCall() + 1);
                self.minutesCall(0);
                self.secondsCall(0);
            }
            else {
                self.minutesCall(self.minutesCall() + 1);
                self.secondsCall(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTimeCall = new Date().getTime();
            var secondsDifferenceCall = 0;
            if (firstLoadCall === 0) {
                var secondsDifferenceCall = 0;
                firstLoadCall = 1;
            }
            else {
                secondsDifferenceCall = Math.floor((currentTimeCall - currentTimeCall) / 1000);
            }

            if (secondsDifferenceCall == 0) {
                self.secondsCall(self.secondsCall() + 1);
            }
            else {
                if (self.secondsCall() + secondsDifferenceCall > 59) {
                    extraSecondsCall = self.secondsCall() + secondsDifferenceCall;
                    self.secondsCall(extraSecondsCall % 60)
                    extraMinsCall = self.minutesCall() + Math.round(extraSecondsCall / 60);
                    if (extraMinsCall > 59) {
                        self.minutesCall(extraMinsCall % 60);
                        self.hoursCall(self.hoursCall() + Math.round(extraMinsCall / 60));
                    }
                    else { self.minutesCall(extraMinsCall); }
                    extraSecondsCall = 0;
                    extraMinsCall = 0;
                }
                else {
                    self.secondsCall(self.secondsCall() + secondsDifferenceCall);
                }
            }
            InitialTimeCall = currentTimeCall;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounterCall(self.idleActivityCounterCall() + 1);
                var idleActivityCounterValueCall = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounterCall() == idleActivityCounterValueCall) {
                    if (self.isIdleDisplayCall() == true) {
                        self.isIdleDisplayCall(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }

    self.StartTimerCall = function () {

        InitialTimeCall = new Date().getTime();
        firstLoadCall = 0;
        //set clock
        if (self.counterCall != null) {
            clearInterval(self.counterCall);
        }
        self.counterCall = setInterval(self.tickCall, 1000)
        // self.cssClock('timer-start');
    }

    self.StopClockCall = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoadCall = 0;
        self.cssClockCall('');
        self.secondsCall(0);
        self.minutesCall(0);
        self.hoursCall(0);
        clearInterval(self.counterCall);
    }

    self.ResetIdleActivityCounterCall = function () {
        self.idleActivityCounterCall(0);
        self.isIdleDisplayCall(true);
    }



    //Web
    var InitialTimeWeb = new Date().getTime();
    var extraSecondsWeb = 0;
    var extraMinsWeb = 0;
    var firstLoadWeb = 0;
    //-------Start Clock
    self.counterWeb = null;
    self.recordtimeWeb = ko.observable();;
    self.secondsWeb = ko.observable(0);
    self.minutesWeb = ko.observable(0);
    self.hoursWeb = ko.observable(0);
    self.cssClockWeb = ko.observable();
    self.idleActivityCounterWeb = ko.observable(0);
    self.isIdleDisplayWeb = ko.observable(true);
    self.setWebChatSeconds = ko.computed(function () {
        if (self.secondsWeb() == 60) {
            return "00";
        }
        else {
            if (self.secondsWeb() < 10)
                return "0" + self.secondsWeb();
            else
                return self.secondsWeb();
        }
    });

    self.setWebChatMinutes = ko.computed(function () {
        if (self.minutesWeb() == 60) {
            return "00";
        }
        else {
            if (self.minutesWeb() < 10)
                return "0" + self.minutesWeb();
            else
                return self.minutesWeb();
        }
    });

    self.setWebChatHours = ko.computed(function () {
        if (self.hoursWeb() < 10)
            return "0" + self.hoursWeb();
        else
            return self.hoursWeb();
    });

    self.tickWeb = function () {

        if (self.secondsWeb() == 59) {
            if (self.minutesWeb() == 59) {
                self.hoursWeb(self.hoursWeb() + 1);
                self.minutesWeb(0);
                self.secondsWeb(0);
            }
            else {
                self.minutesWeb(self.minutesWeb() + 1);
                self.secondsWeb(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTimeWeb = new Date().getTime();
            var secondsDifferenceWeb = 0;
            if (firstLoadWeb === 0) {
                var secondsDifferenceWeb = 0;
                firstLoadWeb = 1;
            }
            else {
                secondsDifferenceWeb = Math.floor((currentTimeWeb - currentTimeWeb) / 1000);
            }

            if (secondsDifferenceWeb == 0) {
                self.secondsWeb(self.secondsWeb() + 1);
            }
            else {
                if (self.secondsWeb() + secondsDifferenceWeb > 59) {
                    extraSecondsWeb = self.secondsWeb() + secondsDifferenceWeb;
                    self.secondsWeb(extraSecondsWeb % 60)
                    extraMinsWeb = self.minutesWeb() + Math.round(extraSecondsWeb / 60);
                    if (extraMinsWeb > 59) {
                        self.minutesWeb(extraMinsWeb % 60);
                        self.hoursWeb(self.hoursWeb() + Math.round(extraMinsWeb / 60));
                    }
                    else { self.minutesWeb(extraMinsWeb); }
                    extraSecondsWeb = 0;
                    extraMinsWeb = 0;
                }
                else {
                    self.secondsWeb(self.secondsWeb() + secondsDifferenceWeb);
                }
            }
            InitialTimeWeb = currentTimeWeb;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounterWeb(self.idleActivityCounterWeb() + 1);
                var idleActivityCounterValueWeb = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounterWeb() == idleActivityCounterValueWeb) {
                    if (self.isIdleDisplayWeb() == true) {
                        self.isIdleDisplayWeb(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }

    self.StartTimerWeb = function () {

        InitialTimeWeb = new Date().getTime();
        firstLoadWeb = 0;
        //set clock
        if (self.counterWeb != null) {
            clearInterval(self.counterWeb);
        }
        self.counterWeb = setInterval(self.tickWeb, 1000)
        // self.cssClock('timer-start');
    }

    self.StopClockWeb = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoadWeb = 0;
        self.cssClockWeb('');
        self.secondsWeb(0);
        self.minutesWeb(0);
        self.hoursWeb(0);
        clearInterval(self.counterWeb);
    }

    self.ResetIdleActivityCounterWeb = function () {
        self.idleActivityCounterWeb(0);
        self.isIdleDisplayWeb(true);
    }

    //outbound call
    var InitialTime = new Date().getTime();
    var extraSeconds = 0;
    var extraMins = 0;
    var firstLoad = 0;
    //-------Start Clock
    self.counter = null;
    self.recordtime = ko.observable();;
    self.seconds = ko.observable(0);
    self.minutes = ko.observable(0);
    self.hours = ko.observable(0);
    self.cssClock = ko.observable();
    self.idleActivityCounter = ko.observable(0);
    self.isIdleDisplay = ko.observable(true);

    self.setOutBoundCallSeconds = ko.computed(function () {
        if (self.seconds() == 60) {
            return "00";
        }
        else {
            if (self.seconds() < 10)
                return "0" + self.seconds();
            else
                return self.seconds();
        }
    });

    self.setOutBoundCallMinutes = ko.computed(function () {
        if (self.minutes() == 60) {
            return "00";
        }
        else {
            if (self.minutes() < 10)
                return "0" + self.minutes();
            else
                return self.minutes();
        }
    });

    self.setOutBoundCallHours = ko.computed(function () {
        if (self.hours() < 10)
            return "0" + self.hours();
        else
            return self.hours();
    });

    self.tick = function () {

        if (self.seconds() == 59) {
            if (self.minutes() == 59) {
                self.hours(self.hours() + 1);
                self.minutes(0);
                self.seconds(0);
            }
            else {
                self.minutes(self.minutes() + 1);
                self.seconds(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTime = new Date().getTime();
            var secondsDifference = 0;
            if (firstLoad === 0) {
                var secondsDifference = 0;
                firstLoad = 1;
            }
            else {
                secondsDifference = Math.floor((currentTime - InitialTime) / 1000);
            }

            if (secondsDifference == 0) {
                self.seconds(self.seconds() + 1);
            }
            else {
                if (self.seconds() + secondsDifference > 59) {
                    extraSeconds = self.seconds() + secondsDifference;
                    self.seconds(extraSeconds % 60)
                    extraMins = self.minutes() + Math.round(extraSeconds / 60);
                    if (extraMins > 59) {
                        self.minutes(extraMins % 60);
                        self.hours(self.hours() + Math.round(extraMins / 60));
                    }
                    else { self.minutes(extraMins); }
                    extraSeconds = 0;
                    extraMins = 0;
                }
                else {
                    self.seconds(self.seconds() + secondsDifference);
                }
            }
            InitialTime = currentTime;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounter(self.idleActivityCounter() + 1);
                var idleActivityCounterValue = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounter() == idleActivityCounterValue) {
                    if (self.isIdleDisplay() == true) {
                        self.isIdleDisplay(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }

    self.StartTimer = function () {

        InitialTime = new Date().getTime();
        firstLoad = 0;
        //set clock
        if (self.counter != null) {
            clearInterval(self.counter);
        }
        self.counter = setInterval(self.tick, 1000)
        // self.cssClock('timer-start');
    }

    self.StopClock = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoad = 0;
        self.cssClock('');
        self.seconds(0);
        self.minutes(0);
        self.hours(0);
        clearInterval(self.counter);
    }

    self.ResetIdleActivityCounter = function () {
        self.idleActivityCounter(0);
        self.isIdleDisplay(true);
    }

}