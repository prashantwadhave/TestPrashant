﻿
$(function () {

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('divTeam'));

    objvm.GetInitialData();

});


function vm() {


    var self = this;
    self.teamList = ko.observableArray();
    self.teamName = ko.observable();
    self.IsActive = ko.observable();
    self.SelectedTeamId = ko.observable();
    self.error_Add = ko.observable();
    self.error_Update = ko.observable();

    self.GetInitialData = function () {
        var url = '/api/GetAllTeams?DepartmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.teamList(result);
                    }
                    else {
                        if (self.teamList().length > 0)
                            self.teamList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.OpenAddDepartmentPopup = function () {
        $("#dvDepartment_Add").show();
    }

    self.rowClick = function (row) {
        self.SelectedTeamId(row.Id);
    }

    self.AddTeam = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            self.IsActive(true);
            var url = '/api/AddTeam';
            var model =
                {
                    Name: self.teamName(),
                    DepartmentId: sessionStorage.getItem("DepartmentId"),
                    IsActive: self.IsActive()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Add();
                    self.Reset();
                    self.GetInitialData();
                },
                error: function (returnVal) {
                    self.error_Add(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.OpenUpdateTeamPopup = function () {

        var url = '/api/GetTeamById?id=' + self.SelectedTeamId();
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    self.teamName(result.Name);
                    self.IsActive(result.IsActive);
                    $("#dvDepartment_Update").show();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.UpdateTeam = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            var url = '/api/UpdateTeam';
            var model =
                {
                    Id: self.SelectedTeamId(),
                    Name: self.teamName(),    
                    DepartmentId: sessionStorage.getItem("DepartmentId"),
                    IsActive: self.IsActive()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Update();
                    self.Reset();
                    self.GetInitialData();
                },
                error: function (returnVal) {
                    self.error_Update(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.Reset = function () {
        self.teamList('');
        self.SelectedTeamId('');
    }

    self.ResetPopup = function () {
        self.teamName('');
        self.IsActive('');
        self.SelectedTeamId('');
        self.error_Add('');
        self.error_Update('');
    }

    self.ClosePopup_Add = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvDepartment_Add").hide();
    };

    self.ClosePopup_Update = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvDepartment_Update").hide();
    };

    //validation starts

    self.teamName.extend({
        required: {
            param: true,
            message: "Please enter Team Name"
        }
    });


    let AddDepartmentBtnValidationFields = [self.teamName];
    self.addUpdateDepartmentBtnErrors = ko.validation.group(AddDepartmentBtnValidationFields);
}