﻿
$(function () {

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('divActMasters'));

    objvm.GetInitialData();

});


function vm() {


    var self = this;
    self.ActivityName = ko.observable();
    self.STT = ko.observable();
    self.ActivityList = ko.observableArray();
    self.ParentActivityList = ko.observableArray();
    self.ActivityGroupList = ko.observableArray();
    self.selectedGroup = ko.observable();
    self.selectedParentId = ko.observable();
    self.IsActive = ko.observable();
    self.IsParent = ko.observable();
    self.SelectedActivityId = ko.observable();
    self.error_Add = ko.observable();
    self.error_Update = ko.observable();
    self.errorMsg = ko.observable();
    self.errorMsg1 = ko.observable();
    self.GetInitialData = function () {
        var url = '/api/GetAllActivityByDepartmentId?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.ActivityList(result);
                    }
                    else {
                        //debugger;
                        if (self.ActivityList().length > 0) {
                            self.ActivityList.removeAll();
                        }
                    }
                }
            },
            error: function (returnVal) {
            }
        });

        self.BindParentDLL();
    }
    self.BindParentDLL = function () {
        var url = '/api/GetAllActivity?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.ParentActivityList(result);
                    }
                    else {
                        if (self.ParentActivityList().length > 0) {
                            self.ParentActivityList.removeAll();
                        }
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }
    self.BindActivityGroupDll = function () {
        var url = '/api/GetActivityGroups';
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {

                        self.ActivityGroupList(result);
                    }
                    else
                        if (self.ActivityGroupList().length > 0) {
                            self.ActivityGroupList.removeAll();
                        }

                }
            },
            error: function (returnVal) {
            }
        });
    }
    self.OpenAddActivityPopup = function () {
        self.IsActive(true);
        self.RemoveSelectedRow();
        self.ParentActivityList('');
        if (self.ParentActivityList().length > 0) {
        }
        else {
            self.BindParentDLL();
        }

        if (self.ActivityGroupList().length > 0) {
        }
        else {
            self.BindActivityGroupDll();
        }
        $("#AddActivityMaster").show();
    }

    self.rowClick = function (row, el) {
        var table = $('#tblActivity').DataTable();
        var rows = table.rows().nodes();
        $(rows).removeClass("active");
        var selectedRowId = $(el.target).closest("tr")[0].id;

        $("#" + selectedRowId).addClass("active");
        self.SelectedActivityId(row.Id);
    }

    self.RemoveSelectedRow = function () {
        //debugger;
        var table = $('#tblActivity').DataTable();
        var rows = table.rows().nodes();
        $(rows).removeClass("active");
    };
    self.AddActivity = function () {

        var data = self.ValidateParent();

        if (self.addUpdateActivityBtnErrors().length == 0) {
            if (data.errorMsg == "" && data.errorMsg1 == "") {
                self.errorMsg('');
                self.errorMsg1('');
                var url = '/api/AddActivity/';
                var model =
                    {
                        DepartmnetId: sessionStorage.getItem("DepartmentId"),
                        ParentId: self.selectedParentId,
                        ActivityName: self.ActivityName,
                        ActivityGroup: self.selectedGroup,
                        STT: self.STT,
                        IsActive: self.IsActive()
                    };

                var result = null;
                $.ajax({
                    url: url,
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json;charset=utf-8",
                    data: ko.toJSON(model),
                    async: true,
                    success: function (returnVal) {
                        self.ClosePopup_Add();
                        self.Reset();
                        self.GetInitialData();
                    },
                    error: function (returnVal) {
                        self.error_Add(returnVal.responseJSON.Message);
                    }
                });
            }
            else {
                self.errorMsg(data.errorMsg);
                self.errorMsg1(data.errorMsg1);
            }
        }
        else {

            self.addUpdateActivityBtnErrors.showAllMessages();
        }

    }

    self.ValidateParent = function () {
        var errorMsg = "";
        var errorMsg1 = "";
        //debugger;  
        if (self.IsParent()) {

            if (self.selectedParentId()==undefined || self.selectedParentId() == null || self.selectedParentId() == "--Select--") {
                errorMsg = "Please select parent activity";
            }
        }
        if ( self.STT()!=undefined && self.STT() != "" && self.STT() <= 0 )
        {
            errorMsg1 =  "Please select STT > 0";
        }
        return { errorMsg: errorMsg, errorMsg1: errorMsg1  };
    };
    self.OpenUpdateActivityPopup = function () {

        self.ParentActivityList('');
        if (self.ActivityGroupList().length > 0) {
        }
        else {
            self.BindActivityGroupDll();
        }
        if (self.ParentActivityList().length > 0) {
        }
        else {
            self.BindParentDLL();
        }

        var url = '/api/GetActivityId?departmentId=' + sessionStorage.getItem("DepartmentId") + '&activityId=' + self.SelectedActivityId();
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                //debugger;  
                result = returnVal;
                if (result != null) {
                    self.ActivityName(result.ActivityName);
                    self.STT(result.STT);
                    self.selectedGroup(result.ActivityGroup);
                    self.selectedParentId(result.ParentId);
                    if (result.ParentId > 0)
                        self.IsParent(true);
                    else
                        self.IsParent(false);

                    self.IsActive(result.IsActive);
                    self.SelectedActivityId(result.Id);

                    $("#dvactvity_Update").show();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.UpdateActivity = function () {

        var data = self.ValidateParent();

        if (self.addUpdateActivityBtnErrors().length == 0) {
            if (data.errorMsg == "" && data.errorMsg1=="") {
                self.errorMsg('');
                self.errorMsg1('');
                var url = '/api/UpdateActivity?departmentId=' + sessionStorage.getItem("DepartmentId");
                var model =
                    {
                        Id: self.SelectedActivityId(),
                        DepartmnetId: sessionStorage.getItem("DepartmentId"),
                        ParentId: self.IsParent() ? self.selectedParentId : '0',
                        ActivityName: self.ActivityName,
                        ActivityGroup: self.selectedGroup,
                        STT: self.STT,
                        IsActive: self.IsActive()

                    };
                var result = null;
                $.ajax({
                    url: url,
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json;charset=utf-8",
                    data: ko.toJSON(model),
                    async: true,
                    success: function (returnVal) {
                        self.ClosePopup_Update();
                        self.Reset();
                        self.GetInitialData();
                    },
                    error: function (returnVal) {
                        self.error_Update(returnVal.responseJSON.Message);
                    }
                });
            }
            else {
                self.errorMsg(data.errorMsg);
                self.errorMsg1(data.errorMsg1);
            }
        }
        else {
            self.addUpdateActivityBtnErrors.showAllMessages();
        }

    }

    self.Reset = function () {
        //debugger;
        //self.ActivityList('');
        self.SelectedActivityId('');
    }

    self.ResetPopup = function () {
        self.IsParent('');
        self.IsActive('');
        self.errorMsg('');
        self.errorMsg1('');
        self.ActivityGroupList('');
        self.SelectedActivityId('');
        self.selectedGroup('');
        self.ActivityName('');
        self.STT('');
        self.error_Add('');
        self.error_Update('');
        self.RemoveSelectedRow();
    }

    self.ClosePopup_Add = function () {
        self.ResetPopup();
        self.addUpdateActivityBtnErrors.showAllMessages(false);
        $("#AddActivityMaster").hide();
    };

    self.ClosePopup_Update = function () {
        self.ResetPopup();
        self.addUpdateActivityBtnErrors.showAllMessages(false);
        $("#dvactvity_Update").hide();
    };

    //validation starts


    ko.bindingHandlers.STT = {
        init: function (element, valueAccessor) {
            //debugger;  
            $(element).on("keydown", function (event) {
                // Allow: backspace, delete, tab, escape, and enter
                if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
                    // Allow: Ctrl+A
                    (event.keyCode == 65 && event.ctrlKey === true) ||
                    // Allow: . ,
                   // (event.keyCode == 188 || event.keyCode == 190 || event.keyCode == 110) ||
                    // Allow: home, end, left, right
                    (event.keyCode >= 35 && event.keyCode <= 39)) {
                    // let it happen, don't do anything
                    return;
                }
                else {
                    // Ensure that it is a number and stop the keypress
                    if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105) ) {
                        event.preventDefault();
                    }
                }
            });
        }
    };

    self.ActivityName.extend({
        required: {
            param: true,
            message: "Please enter Activity Name"
        }
    });
    self.selectedGroup.extend({
        required: {
            param: true,
            message: "Please select Activity Group"
        }
    });


    let AddActivityBtnValidationFields = [self.ActivityName, self.selectedGroup];
    self.addUpdateActivityBtnErrors = ko.validation.group(AddActivityBtnValidationFields);
}