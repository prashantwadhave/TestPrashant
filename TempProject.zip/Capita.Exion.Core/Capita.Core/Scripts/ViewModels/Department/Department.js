﻿
$(function () {

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('divDepartment'));

    objvm.GetInitialData();

});


function vm() {


    var self = this;
    self.departmentList = ko.observableArray();
    self.DepartmentName = ko.observable();
    self.IsActive = ko.observable();
    self.SelectedDepartmentId = ko.observable();
    self.error_Add = ko.observable();
    self.error_Update = ko.observable();

    self.GetInitialData = function () {
        var url = '/api/GetAllDepartmentsInApp';
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.departmentList(result);
                    }
                    else {
                        if (self.departmentList().length > 0)
                            self.departmentList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.OpenAddDepartmentPopup = function () {
        $("#dvDepartment_Add").show();
    }

    self.rowClick = function (row) {
        self.SelectedDepartmentId(row.Id);
    }

    self.AddDepartment = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            self.IsActive(true);
            var url = '/api/AddDepartment';
            var model =
                {
                    Name: self.DepartmentName(),
                    IsActive: self.IsActive()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Add();
                    self.Reset();
                    self.GetInitialData();
                },
                error: function (returnVal) {
                    self.error_Add(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.OpenUpdateDepartmentPopup = function () {

        var url = '/api/GetDepartmentById?id=' + self.SelectedDepartmentId();
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    self.DepartmentName(result.Name);
                    self.IsActive(result.IsActive);
                    $("#dvDepartment_Update").show();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.UpdateDepartment = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            var url = '/api/UpdateDepartment';
            var model =
                {
                    Id: self.SelectedDepartmentId(),
                    Name: self.DepartmentName(),
                    IsActive: self.IsActive()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Update();
                    self.Reset();
                    self.GetInitialData();
                },
                error: function (returnVal) {
                    self.error_Update(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.Reset = function () {
        self.departmentList('');
        self.SelectedDepartmentId('');
    }

    self.ResetPopup = function () {
        self.DepartmentName('');
        self.IsActive('');
        self.SelectedDepartmentId('');
        self.error_Add('');
        self.error_Update('');
    }

    self.ClosePopup_Add = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvDepartment_Add").hide();
    };

    self.ClosePopup_Update = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvDepartment_Update").hide();
    };

    //validation starts
  
    self.DepartmentName.extend({
        required: {
            param: true,
            message: "Please enter Department Name"
        }
    });


    let AddDepartmentBtnValidationFields = [self.DepartmentName];
    self.addUpdateDepartmentBtnErrors = ko.validation.group(AddDepartmentBtnValidationFields);
}