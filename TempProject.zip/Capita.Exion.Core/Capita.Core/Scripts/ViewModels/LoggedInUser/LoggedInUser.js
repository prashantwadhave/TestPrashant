﻿//function vmLoggedInUser() {
//    var self = this;
//    self.btnLoggedIn_Enable = ko.observable(false);
//    self.GetLoggedInUser = function () {
//        GetLoggedInUser();
//    },
//    self.KillSession = function () {
//        var userId = GetSelectedIds();
//        var url = '/api/LoggedInEmployess/KillSession';
//        var data = { 'userId': userId };
//        Commonmethods.GetAjaxDataAuth(url, 'GET', false, '', data, 'Issue with function KillSession', function (result) {
//            $(".confirmation_popup").hide();
//            if (result)
//                GetLoggedInUser();
//        });
//    }
//}
//self.ConfirmKillSession = function () {
//    var msg = "Are you sure to kill session?"
//    $('#cmnMsg').text(msg);
//    $(".confirmation_popup").show();
//}

//var vmModel = new vmLoggedInUser();
//$(document).ready(function () {
//    try {
//        ko.cleanNode(document.getElementById('dvLoggedInUser'));
//        ko.applyBindings(vmModel, document.getElementById('dvLoggedInUser'));
//        GetLoggedInUser();
//    } catch (e) {
//        logError(e, "Exception raised in LoggedInUser.js");
//    }
//});

//function GetLoggedInUser() {
//    var token = sessionStorage.getItem("GetAccessToken");
//    try {
//        var url = '/api/LoggedInEmployess/GetAllLoggedInUsers';
//        var data = { 'IsAllUsers': true };
//        Commonmethods.GetAjaxDataAuth(url, 'GET', false, '', data, 'Issue with function GetLoggedInUser', function (result) {
//            BindLoggedInUser(result);
//        });
       
//    }
//    catch (e) {
//        logError(e, "Issue with function GetLoggedInUser");
//    }
//}

//function BindLoggedInUser(result) {
//    $('#LoggedInUserGrid').dataTable({
//        "aaData": result,
//        "order": [],
//        destroy: true,
//        dom: 'lBfrtip',
//        scrollX: true,
//        buttons: [
//            {
//                extend: 'excelHtml5',
//                title: 'LoggedinUsers'
//            },
//        ], 
//        "aoColumns": [
//            {
//                sTitle: "<input id='checkAll' type='checkbox' class='checkbox' style='margin:0 !important;min-height: 0px !important;'/>", sWidth: "40px", "bSortable": false,
//                "render": function (data, type, full, meta) {
//                    return "<input id=chk_" + full.UserId + " type='checkbox' class='check' style='margin:0 !important;min-height: 0px !important;'/>";
//                }
//            },
            
//            { sTitle: "Name", mDataProp: "Name", sWidth: "100px" },
//            { sTitle: "Team Name", mDataProp: "Team", sWidth: "100px" },
//            { sTitle: "Department Name", mDataProp: "Department", sWidth: "100px" },
//            { sTitle: "Logged In", mDataProp: "LoggedIn", sWidth: "100px" }
//        ],
     
//        "fnInfoCallback": function (oSettings, iStart, iEnd, iMax, iTotal, sPre) {
//            ko.cleanNode(document.getElementById('LoggedInUserGrid'));
//            ko.applyBindings(vmModel, document.getElementById('LoggedInUserGrid'));
//            var rows = $("#LoggedInUserGrid").dataTable().fnGetNodes();
//            for (var i = 0; i < rows.length; i++) {
//                $(rows[i]).removeClass("active")
//            }
//            $("#LoggedInUserGrid").children("tbody").children("tr").children("td").unbind("click");
//            $("#LoggedInUserGrid").children("tbody").children("tr").children("td").click(function (event) {
//                $(this.parentNode).toggleClass("active");
//                if ($(this.parentNode).hasClass("active")) {
//                    ele = $(this.parentElement).find('td input:checkbox')[0];
//                    ele.checked = true;
//                }
//                else {
//                    ele = $(this.parentElement).find('td input:checkbox')[0];
//                    ele.checked = false;
//                }
//                var cells = $("#LoggedInUserGrid").dataTable().api().cells().nodes();
//                if ($(cells).find('.check:checked').length > 0) {
//                    vmModel.btnLoggedIn_Enable(true);
//                }
//                else {
//                    vmModel.btnLoggedIn_Enable(false);
//                }
                
//            });

//            $("#checkAll").click(function () {
//                if ($("#checkAll").is(':checked')) {
//                    var cells = $("#LoggedInUserGrid").dataTable().api().cells().nodes();
//                    var rows = $("#LoggedInUserGrid").dataTable().api().rows().nodes();
//                    $(cells).find('.check').prop('checked', this.checked);
//                    $(rows).addClass("active");
//                    vmModel.btnLoggedIn_Enable(true);
//                } else {
//                    var cells = $("#LoggedInUserGrid").dataTable().api().cells().nodes();
//                    var rows = $("#LoggedInUserGrid").dataTable().api().rows().nodes();
//                    $(cells).find('.check').prop('checked', this.checked);
//                    $(rows).removeClass("active");
//                    vmModel.btnLoggedIn_Enable(false);
//                }
//            });
//            return "Showing " + iStart + " to " + iEnd + " of " + iTotal + " entries";
//        }
//    });
//}

//function GetSelectedIds() {
//    var lstIds = "", i = 0;
//    $("input:checked", $("#LoggedInUserGrid").dataTable().fnGetNodes()).each(function () {
//        if (i === 0) {
//            lstIds = $(this).attr("id").split('_')[1];
//            i++;
//        } else {
//            lstIds = lstIds + ',' + $(this).attr("id").split('_')[1];
//        }
//    });
//    return lstIds;
//}

//Number.prototype.padLeft = function (base, chr) {
//    var len = (String(base || 10).length - String(this).length) + 1;
//    return len > 0 ? new Array(len).join(chr || '0') + this : this;
//}
//function ConfirmedToDo() {
//    vmModel.KillSession();
//}


$(function () {
    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('dvLoggedInUser'));

    objvm.GetInitialData();

});

function vm() {

    var self = this;
    self.userList = ko.observableArray();
    self.SelectedUserId = ko.observable();
    self.myValue = ko.observable(false);

    self.GetInitialData = function () {
        var url = '/api/GetActiveSessionOfUsers?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.userList(result);
                    }
                    else {
                        if (self.userList().length > 0)
                            self.userList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.rowClick = function (row) {
        self.SelectedUserId(row.UserLoggedInId);
    }

    self.Reset = function () {
        self.userList('');
        self.SelectedUserId('');
        self.myValue('');
    }

    self.ConfirmKillSession = function () {
        var ids = self.GetSelectedIds();
        if (ids != "") {
            var url = '/api/KillSessionByUserLoggedInId?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userLoggedInId=' + ids;
            var result = null;
            $.ajax({
                url: url,
                type: "GET",
                dataType: "json",
                async: true,
                success: function (returnVal) {
                    result = returnVal;
                    if (result == true) {
                        self.Reset();
                        self.SelectAll();
                        self.GetInitialData();
                    }
                },
                error: function (returnVal) {
                }
            });
        }
    }

    self.SelectAll = function () {
        var isCheckedAll = self.myValue();

        var table = $('#tblLoggedInUsers').DataTable();
        var rows = table.rows({ page: 'current' }).nodes();
        var cells = table.cells({ page: 'current' }).nodes();

        if (isCheckedAll) {
            $(cells).find('.check').prop('checked', isCheckedAll);
            $(rows).addClass("active");
        }
        else {
            cells = table.cells().nodes();
            rows = table.rows().nodes();
            $(cells).find('.check').prop('checked', isCheckedAll);
            $(rows).removeClass("active");
        }

        return true;
    }

    self.GetSelectedIds = function() {
        var lstIds = "", i = 0;
        $("input:checked", $("#tblLoggedInUsers").dataTable().fnGetNodes()).each(function () {
            if (i === 0) {
                lstIds = $(this).attr("id");
                i++;
            }
            else
            {
                lstIds = lstIds + ',' + $(this).attr("id");
            }
        });
        return lstIds;
    }
}