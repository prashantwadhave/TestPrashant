﻿
$(function () {

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('divAuxCode'));

    objvm.GetAllAuxCodeList();
    objvm.GetAssignedNonCoreActivityList();
});


function vm() {


    var self = this;
    self.AllAuxCodeList = ko.observableArray();
    self.AssignedNonCoreActivityList = ko.observableArray();
    self.AuxCode = ko.observable();
    self.IsActive = ko.observable();
    self.SelectedAuxCodeId = ko.observable();
    self.error_Add = ko.observable();
    self.error_Update = ko.observable();
 

    self.GetAllAuxCodeList = function () {
        var url = '/api/GetAllAuxCodeList';
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.AllAuxCodeList(result);
                    }
                    else {
                        if (self.AllAuxCodeList().length > 0)
                            self.AllAuxCodeList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.GetAssignedNonCoreActivityList = function () {
        var url = '/api/GetAllAssignedAuxCode?departmentId=' + sessionStorage.getItem("DepartmentId");;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.AssignedNonCoreActivityList(result);
                    }
                    else {
                        if (self.AssignedNonCoreActivityList().length > 0)
                            self.AssignedNonCoreActivityList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.MapAuxCodeToDepartment = function (row) {
        var url = '/api/MapAuxCodeAndDepartment?departmentId=' + sessionStorage.getItem("DepartmentId") + '&auxCodeId=' + row.Id;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                self.GetAssignedNonCoreActivityList();
            },
            error: function (returnVal) {
                var msg = returnVal.responseJSON.Message;
                $('#successMsg').text(msg);
                $(".popup_for_disp_msg").show();
            }
        });
    }

    self.UnmapAuxCodeToDepartment = function (row) {
        var url = '/api/DeleteMapAuxCodeAndDepartment?departmentId=' + sessionStorage.getItem("DepartmentId") + '&auxCodeId=' + row.Id;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                self.GetAssignedNonCoreActivityList();
            },
            error: function (returnVal) {
            }
        });
    }

    self.OpenAddDepartmentPopup = function () {
        $("#dvAuxCodeDepartment_Add").show();
    }

    self.rowClick = function (row, el) {
        self.RemoveActiveClass();
        var selectedRowId = $(el.target).closest("tr")[0].id;

        $("#" + selectedRowId).addClass("active");

        self.SelectedAuxCodeId(row.Id);
    }

    self.RemoveActiveClass = function () {
        var table = $('#tblUnassignedNonCoreActivityList').DataTable();
        var rows = table.rows().nodes();
        $(rows).removeClass("active");
    }

    self.AddAuxCode = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            var url = '/api/AddAuxCode';
            var model =
                {
                    ActivityName: self.AuxCode()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Add();
                    self.Reset();
                    self.GetAllAuxCodeList();
                },
                error: function (returnVal) {
                    self.error_Add(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.OpenUpdateDepartmentPopup = function () {

        var url = '/api/GetAuxCodeById?id=' + self.SelectedAuxCodeId();
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    self.AuxCode(result.ActivityName);
                    $("#dvAuxCodeDepartment_Update").show();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.UpdateAuxCode = function () {

        if (self.addUpdateDepartmentBtnErrors().length == 0) {
            var url = '/api/UpdateAuxCode';
            var model =
                {
                    Id: self.SelectedAuxCodeId(),
                    ActivityName: self.AuxCode()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Update();
                    self.Reset();
                    self.GetAllAuxCodeList();
                    self.GetAssignedNonCoreActivityList();
                },
                error: function (returnVal) {
                    self.error_Update(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateDepartmentBtnErrors.showAllMessages();
        }

    }

    self.HideMsg = function () {
        $(".popup_for_disp_msg").hide();
    }

    self.Reset = function () {
        self.SelectedAuxCodeId('');
    }

    self.ResetPopup = function () {
        self.AuxCode('');
        self.IsActive('');
        self.SelectedAuxCodeId('');
        self.error_Add('');
        self.error_Update('');
    }

    self.ClosePopup_Add = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvAuxCodeDepartment_Add").hide();
        self.RemoveActiveClass();
    };

    self.ClosePopup_Update = function () {
        self.ResetPopup();
        self.addUpdateDepartmentBtnErrors.showAllMessages(false);
        $("#dvAuxCodeDepartment_Update").hide();
        self.RemoveActiveClass();
    };

    //validation starts
  
    self.AuxCode.extend({
        required: {
            param: true,
            message: "Please enter Aux Code"
        }
    });


    let AddDepartmentBtnValidationFields = [self.AuxCode];
    self.addUpdateDepartmentBtnErrors = ko.validation.group(AddDepartmentBtnValidationFields);
}