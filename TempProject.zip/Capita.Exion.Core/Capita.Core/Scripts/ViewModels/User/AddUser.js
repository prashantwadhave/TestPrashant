﻿
$(function () {

    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('dvUserTeamRole'));

    objvm.GetInitialData();
    objvm.GetUnassignedUserList();
});


function vm() {


    var self = this;
    self.userList = ko.observableArray();
    self.unassignedUserList = ko.observableArray();
    self.SelectedUserId = ko.observable();

    self.timezoneList = ko.observableArray();
    self.selectedTimezone = ko.observable();
    self.DepartmentName = ko.observable();
    self.EmployeeId = ko.observable();
    self.FirstName = ko.observable();
    self.LastName = ko.observable();
    self.EmailId = ko.observable();
    self.LanId = ko.observable();
    self.IsActive = ko.observable();
    self.error_Add = ko.observable();
    self.error_Update = ko.observable();
    self.enableRemoveForUnAssignedUser = ko.observable(false);
    self.enableRemoveForAssignedUser = ko.observable(false);
    self.isUnAssingedSelectedUserToRemove = ko.observable(false);
    self.UnAssingedSelectedUserId = ko.observable();

    self.GetInitialData = function () {
        var url = '/api/GetUsersByDepartmentId?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result2 = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result2 = returnVal;
                if (result2 != null) {
                    if (result2.length > 0) {
                        self.userList(result2);
                    }
                    else {
                        if (self.userList().length > 0)
                            self.userList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.GetUnassignedUserList = function () {
        var url = '/api/GetUnassignedUserList?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result2 = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result2 = returnVal;
                if (result2 != null) {
                    if (result2.length > 0) {
                        if (self.unassignedUserList().length > 0)
                            self.unassignedUserList.removeAll();
                        self.unassignedUserList(result2);
                    }
                    else {
                        if (self.unassignedUserList().length > 0)
                            self.unassignedUserList.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.OpenAddUserPopup = function () {
        $('#lblTeamErrmsg').text("");
        var url = '/api/GetRoleTimezoneByDepartmentId?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {

                    if (result.lstTimeZone.length > 0) {
                        self.timezoneList(result.lstTimeZone);
                    }
                    self.DepartmentName(result.DepartmentName);

                    $("#dvEmpDetails_Add").show();
                }
            },
            error: function (returnVal) {
            }
        });

    }

    self.rowClick = function (row, el) {
      
        self.RemoveActiveClass();
        var selectedRowId = $(el.target).closest("tr")[0].id;

        $("#" + selectedRowId).addClass("active");
        self.SelectedUserId(row.Id);
        self.enableRemoveForAssignedUser(true);

    }

    self.RemoveActiveClass = function () {
        var table = $('#tblAssignedUserList').DataTable();
        var rows = table.rows().nodes();
        $(rows).removeClass("active");
    }

    self.AddUser = function () {
        if (self.addUpdateUserBtnErrors().length == 0) {

            var url = '/api/AddUserAndDept/';
            var model =
                {
                    EmployeeId: self.EmployeeId(),
                    FirstName: self.FirstName(),
                    LastName: self.LastName(),
                    DepartmentId: sessionStorage.getItem("DepartmentId"),
                    TeamId: 0,
                    EmailId: self.EmailId(),
                    LanId: self.LanId(),
                    TimeZone: self.selectedTimezone(),
                    IsActive: true,
                    CreatedByUserId: 0
                };

            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Add();
                    self.GetUnassignedUserList();
                    var msg = "User added successfully";
                    $('#cmnMsgText').text(msg);
                    $(".message_popup").show();
                },
                error: function (returnVal) {
                    self.error_Add(returnVal.responseJSON.Message);
                }
            });
        }
        else {

            self.addUpdateUserBtnErrors.showAllMessages();
        }

    }

    self.OpenUpdateUserPopup = function () {

        var url = '/api/GetUserById?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + self.SelectedUserId();
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {

                result = returnVal;
                if (result != null && result.User != null) {

                    if (result.lstTimeZone.length > 0) {
                        self.timezoneList(result.lstTimeZone);
                    }

                    self.selectedTimezone(result.User.TimeZone);
                    self.EmployeeId(result.User.EmployeeId);
                    self.FirstName(result.User.FirstName);
                    self.LastName(result.User.LastName);
                    self.EmailId(result.User.EmailId);
                    self.LanId(result.User.LanId);
                    self.IsActive(result.User.IsActive);
                    self.DepartmentName(result.DepartmentName);

                    $("#dvEmpDetails_Update").show();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.UpdateUser = function () {

        if (self.addUpdateUserBtnErrors().length == 0) {
            var url = '/api/UpdateUserAndDept?departmentId=' + sessionStorage.getItem("DepartmentId");
            var model =
                {
                    Id: self.SelectedUserId(),
                    EmployeeId: self.EmployeeId(),
                    FirstName: self.FirstName(),
                    LastName: self.LastName(),
                    DepartmentId: sessionStorage.getItem("DepartmentId"),
                    EmailId: self.EmailId(),
                    LanId: self.LanId(),
                    TimeZone: self.selectedTimezone(),
                    IsActive: self.IsActive()
                };
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: true,
                success: function (returnVal) {
                    self.ClosePopup_Update();
                    self.SelectedUserId('');
                    self.RemoveActiveClass();
                    self.GetInitialData();
                    var msg = "User updated successfully";
                    $('#cmnMsgText').text(msg);
                    $(".message_popup").show();
                },
                error: function (returnVal) {
                    self.error_Update(returnVal.responseJSON.Message);
                }
            });
        }
        else {
            self.addUpdateUserBtnErrors.showAllMessages();
        }

    }

    self.Reset = function () {
        self.unassignedUserList('');
    }

    self.ResetPopup = function () {
        self.timezoneList('');
        self.selectedTimezone('');
        self.DepartmentName('');
        self.EmployeeId('');
        self.FirstName('');
        self.LastName('');
        self.EmailId('');
        self.LanId('');
        self.IsActive('');
        self.error_Add('');
        self.error_Update('');
    }

    self.ClosePopup_Add = function () {
        self.ResetPopup();
        self.addUpdateUserBtnErrors.showAllMessages(false);
        $("#dvEmpDetails_Add").hide();
    };

    self.ClosePopup_Update = function () {
        self.ResetPopup();
        self.addUpdateUserBtnErrors.showAllMessages(false);
        $("#dvEmpDetails_Update").hide();
    };

    // Remove User from Department -- START
    self.OpenRemoveUserPopupUnAssigned = function () {
        self.isUnAssingedSelectedUserToRemove(true);
        $("#dvRemoveUserDept").show();
    }

    self.OpenRemoveUserPopupAssinged = function () {
        self.isUnAssingedSelectedUserToRemove(false);
        $("#dvRemoveUserDept").show();
    }

    self.RemoveUser = function () {
        var userId = 0;        
        if (self.isUnAssingedSelectedUserToRemove()) {
            userId = self.UnAssingedSelectedUserId();
        }
        else {
            userId = self.SelectedUserId();
        }

        var url = '/api/RemoveUserFromDepartment?userId=' + userId;
        var result2 = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                self.ClosePopup_Remove();
                if (self.isUnAssingedSelectedUserToRemove()) {
                    self.GetUnassignedUserList();
                    self.RemoveActiveClassUnAssignedUsers();
                    self.enableRemoveForUnAssignedUser(false);

                }
                else {
                    self.RemoveActiveClass();
                    self.GetInitialData();
                    self.enableRemoveForAssignedUser(false);
                }
                var msg = "Remove user successfully";
                $('#cmnMsgText').text(msg);
                $(".message_popup").show();
            },
            error: function (returnVal) {

            }
        });

    }

    self.ClosePopup_Remove = function () {
        $("#dvRemoveUserDept").hide();

    }
    self.rowClickForUnAssingedUsers = function (row, el) {

        self.RemoveActiveClassUnAssignedUsers();
        var selectedRowId = $(el.target).closest("tr")[0].id;

        $("#" + selectedRowId).addClass("active");
        self.UnAssingedSelectedUserId(row.Id);
        self.enableRemoveForUnAssignedUser(true);

    }

    self.RemoveActiveClassUnAssignedUsers = function () {
        var table = $('#tblUnassignedUserList').DataTable();
        var rows = table.rows().nodes();
        $(rows).removeClass("active");
    }
    // Remove User from Department -- END

    //validation starts
    self.LanId.extend({
        required: {
            param: true,
            message: "Please enter Lan Id"
        }
    });
    self.EmployeeId.extend({
        required: {
            param: true,
            message: "Please enter Employee Id"
        }
    });
    self.FirstName.extend({
        required: {
            param: true,
            message: "Please enter First Name"
        }
    });
    self.LastName.extend({
        required: {
            param: true,
            message: "Please enter Last Name"
        }
    });
    self.selectedTimezone.extend({
        required: {
            param: true,
            message: "Please select Timezone"
        }
    });

    self.EmailId.extend({
        pattern: {
            message: 'Invalid Email Id Format',
            params: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
        }
    })

    let AddUserBtnValidationFields = [self.LanId, self.EmployeeId, self.FirstName, self.LastName, self.selectedTimezone, self.EmailId];
    self.addUpdateUserBtnErrors = ko.validation.group(AddUserBtnValidationFields);
}

