﻿function roleViewModel() {
    var self = this;

    self.Departments = ko.observableArray();
    self.Teams = ko.observableArray();
    self.selectedDepartment = ko.observable();
    self.checkedDefaultDepartment = ko.observable(false);
    self.selectedTeamId = ko.observable();
    self.Users = ko.observableArray();
    self.SelectedUserId = ko.observable();

    self.Roles = ko.observableArray();
    self.SelectedRole = ko.observable();//// Used for knockout validation
    self.SelectedRoles = ko.observable(); //// Used to store multiple roles

    self.UserDepartmentRoles = ko.observableArray();
    self.selectedUserIdInGrid = ko.observable()

    self.rowClick = function (row) {
        self.selectedUserIdInGrid(row.Id);
    }

    self.GetInitialData = function () {

        var url = '/api/GetMasterData?departmentId=' + sessionStorage.getItem("DepartmentId");

        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Get Master Data Error', function (result) {

            if (result != null) {
                if (result.Users.length > 0) {
                    self.Users(result.Users);

                    $.fn.modal.Constructor.prototype.enforceFocus = function () { };
                }

                if (result.Departments.length > 0) {
                    self.Departments(result.Departments);
                }
                if (result.Teams.length > 0) {
                    self.Teams(result.Teams);
                }

                if (result.Roles.length > 0) {
                    self.Roles(result.Roles);

                    $.each(result.Roles, function (index, item) {
                        $("#SelectRole").append('<option value=' + item.Id + '>' + item.Value + '</option>');
                        if (index == (result.Roles.length - 1)) {

                            $('#SelectRole').select2({
                                allowClear: true,
                                placeholder: 'Select Role'
                            });
                        }
                    });
                }
            } else {
                var msg = "No Data Found."
                $('#successMsg').text(msg);
                $(".popup_for_disp_msg").show();
            }
        });
    };

    self.AddRole = function () {

        if (self.errors().length == 0) {

            var url = '/api/AddUserDepartmentRoles';
            var model = {
                UserId: self.SelectedUserId(),
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: self.selectedTeamId(),
                RoleIds: self.SelectedRoles(),
                IsDefault: self.checkedDefaultDepartment()
            };

            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                contentType: "application/json;charset=utf-8",
                data: ko.toJSON(model),
                async: false,
                success: function (result) {

                    if (result == null) {
                        var msg = "User Team and Role already exist."
                        $('#successMsg').text(msg);
                        $(".popup_for_disp_msg").show();
                    } else {
                        self.UserDepartmentRoles(result);
                        var msg = "User Team and Role added successfully."
                        $('#successMsg').text(msg);
                        $(".popup_for_disp_msg").show();
                    }
                },
                error: function (returnVal) {
                }
            });
        } else {
            self.errors.showAllMessages();
        }

    };

    self.HidetrueMsg = function () {
        $(".popup_for_disp_msg").hide();
    };
    self.ShowConfirmation = function () {

        var userSelected = self.selectedUserIdInGrid();
        var msg = "Are you sure?"
        $('#cmnMsg').text(msg);

        if (userSelected == undefined || userSelected == null || userSelected == '') {
            var msg = "Please select records to be deleted."
            $('#successMsg').text(msg);
            $(".popup_for_disp_msg").show();
        } else {
            $(".confirmation_popupnew").show();
        }
    };
    self.OkConfirmation = function () {

        var url = '/api/DeleteUserDepartmentById?id=' + self.selectedUserIdInGrid() + '&userId=' + $("#SelectUser").val();

        Commonmethods.AjaxData(url, 'GET', true, '', '', 'DeleteUserDepartmentById not working', function (result) {

            if (result != null) {
                self.UserDepartmentRoles(result);
            } else {
                var msg = "Default Team for user cannot be deleted."
                $('#successMsg').text(msg);
                $(".popup_for_disp_msg").show();
            }

            $(".confirmation_popupnew").hide();

        });
    };

    self.CancelConfirmation = function () {

        $(".confirmation_popupnew").hide();
    };
    ////Validation
    self.selectedTeamId.extend({
        required: {
            param: true,
            message: "Please select Team."
        }
    });

    self.SelectedRole.extend({
        required: {
            param: true,
            message: "Please select atleast one role."
        }
    });

    self.SelectedUserId.extend({
        required: {
            param: true,
            message: "Please select a user."
        }
    });

    let ValidationFields = [self.selectedTeamId, self.SelectedRole, self.SelectedUserId];
    self.errors = ko.validation.group(ValidationFields);
};


$(document).ready(function () {


    ko.validation.registerExtenders();
    var knockoutValidationSettings = {
        registerExtenders: true,
        insertMessages: true,
        decorateElement: true,
        errorMessageClass: 'error',
        messagesOnModified: true,
        decorateElementOnModified: true,
        decorateInputElement: true
    };
    ko.validation.init(knockoutValidationSettings, true);

    var roleVM = new roleViewModel();
    ko.applyBindings(roleVM, document.getElementById('dvUserRole'));

    roleVM.GetInitialData();
    roleVM.errors.showAllMessages(false);

    $("#SelectUser").on("change", function () {
        roleVM.selectedUserIdInGrid('');
        roleVM.SelectedUserId($("#SelectUser").val());

        if ($("#SelectUser").val() != '') {
            var url = '/api/GetUserDepartmentRolesByUserId?userId=' + $("#SelectUser").val() + '&departmentId=' + sessionStorage.getItem("DepartmentId");

            Commonmethods.AjaxData(url, 'GET', true, '', '', 'GetUserDepartmentRolesByUserId no working', function (result) {
                if (result != null) {
                    if (result.length > 0) {
                        roleVM.UserDepartmentRoles(result);
                    }
                    else {
                        if (roleVM.UserDepartmentRoles().length > 0)
                            roleVM.UserDepartmentRoles.removeAll();
                    }
                }
                else {
                    if (roleVM.UserDepartmentRoles().length > 0)
                        roleVM.UserDepartmentRoles.removeAll();
                }

            });
        }
        else {
            if (roleVM.UserDepartmentRoles().length > 0)
                roleVM.UserDepartmentRoles.removeAll();
        }
    });

    $("#SelectRole").on("change", function () {
        var roles = new Array();

        $.each($("#SelectRole").val(), function (index, item) {
            roles.push(item);
        });

        roleVM.SelectedRole(roles);
        roleVM.SelectedRoles(roles);
    });


});