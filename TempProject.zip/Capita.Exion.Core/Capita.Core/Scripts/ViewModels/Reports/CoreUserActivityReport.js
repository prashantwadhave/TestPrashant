﻿function vm() {
    var self = this;

    self.userCoreActivities = ko.observableArray();
    self.errorMsg = ko.observable();
    self.Teams = ko.observableArray();
    self.selectedTeamId = ko.observable();

    var tblActivity;
    self.BindTable = function () {
        //debugger;
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetCoreActivitiesReport?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + $("#dpstartdate").find("input").val().trim() + '&endDate=' + $("#dpenddate").find("input").val().trim() + '&teamId=' + teamId;

        tblActivity = $('#tblActivity').dataTable({
            "serverSide": true,
            "processing": true,
            "orderMulti": false,
            "filter": true,
            "destroy": true,
            "ajax": {
                "url": url,
                "type": "POST",
                "datatype": "json"
            },
            "columns": [
                    { "data": "AgentName", 'bSortable': true, "title": "Agent Name", "autowidth": true },
                    { "data": "StrStartTime", "title": "Start Time", "autowidth": true },
                    { "data": "StrEndTime", "title": "End Time", "autowidth": true },
                    { "data": "Duration", "title": "Duration", "autowidth": true },
                    { "data": "Activity", "title": "Activity", "autowidth": true },
                    { "data": "Task", "title": "Task", "autowidth": true },
                    { "data": "Comments", "title": "Comments", "autowidth": true }
                ],
            "fnInitComplete": function (settings, json) {
                $('#tblActivity_filter input').unbind();
                $('#tblActivity_filter input').bind('keyup', function (e) {
                    if (e.keyCode == 13) {
                        //model.SearchValue(this.value);
                        tblActivity.fnFilter(this.value);
                    }
                });
            }
        });

    };


    self.Submit = function () {

        var data = self.ValidateStartAndEndDate();
        if (data.errorMsg == "") {
            self.errorMsg('');
            var startDate = $("#dpstartdate").find("input").val().trim();
            var endDate = $("#dpenddate").find("input").val().trim();
            var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
            //self.userCoreActivities.removeAll();
            var url = '/api/GetCoreActivitiesReport?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
            tblActivity = $('#tblActivity').dataTable({
                "serverSide": true,
                "processing": true,
                "orderMulti": false,
                "filter": true,
                "destroy": true,
                "ajax": {
                    "url": url,
                    "type": "POST",
                    "datatype": "json"
                },
                "columns": [
                        { "data": "AgentName", 'bSortable': true, "title": "Agent Name", "autowidth": true },
                        { "data": "StrStartTime", "title": "Start Time", "autowidth": true },
                        { "data": "StrEndTime", "title": "End Time", "autowidth": true },
                        { "data": "Duration", "title": "Duration", "autowidth": true },
                        { "data": "Activity", "title": "Activity", "autowidth": true },
                        { "data": "Task", "title": "Task", "autowidth": true },
                        { "data": "Comments", "title": "Comments", "autowidth": true }
                    ]
            });
        }
        else {
            self.errorMsg(data.errorMsg);
        }

    };

    self.ValidateStartAndEndDate = function () {
        var errorMsg = "";
        var checkStartDate = $('#dpstartdate').datepicker('getDate');
        var checkEndDate = $('#dpenddate').datepicker('getDate');
        var dateDiff = (checkEndDate - checkStartDate) / 86400000;
        var startDate = $("#dpstartdate").find("input").val().trim();
        var endDate = $("#dpenddate").find("input").val().trim();
        var checkStartDate_Year = checkStartDate.getFullYear();
        var checkEndDate_Year = checkEndDate.getFullYear();

        if (startDate == "" && endDate == "") {
            errorMsg = "Please select from date and to date";
        }
        else if (startDate == "") {
            errorMsg = "Please select from date";
        }
        else if (endDate == "") {
            errorMsg = "Please select to date";
        }
        else if (startDate != "" && endDate != "") {
            var d = new Date();
            var currentYear = d.getFullYear();
            var yearDiff_StartDate = currentYear - checkStartDate_Year;
            var yearDiff_EndDate = currentYear - checkEndDate_Year;

            if (yearDiff_StartDate > 1 && yearDiff_EndDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (yearDiff_StartDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (yearDiff_EndDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (dateDiff < 0) {
                errorMsg = "Please select to date greater than from date";
            }
            else if (dateDiff > 7) {
                errorMsg = "Please select from date and to date within 7 days range";
            }
        }

        return { errorMsg: errorMsg, checkStartDate: checkStartDate, checkEndDate: checkEndDate, dateDiff: dateDiff, startDate: startDate, endDate: endDate };
    }

    self.ExportToExcel = function () {
        //debugger;
        var resultData = null;
        var data = self.ValidateStartAndEndDate();
        if (data.errorMsg == "") {
            self.errorMsg('');
            var startDate = $("#dpstartdate").find("input").val().trim();
            var endDate = $("#dpenddate").find("input").val().trim();
            var searchValue = $('input[type="search"]').val();
            //self.userCoreActivities.removeAll();
            var url = '/api/GetCoreActivitiesReport?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + startDate + '&endDate=' + endDate + '&searchVal=' + searchValue + '&isExport=' + true;
            var result = null;
            $.ajax({
                url: url,
                type: "POST",
                dataType: "json",
                async: false,
                success: function (returnVal) {
                    //debugger;
                    result = returnVal.data;
                    if (result != null) {
                        if (result.length > 0) {
                            self.userCoreActivities(result);
                        }
                        else {
                            if (self.userCoreActivities().length > 0)
                                self.userCoreActivities.removeAll();
                        }
                    }
                },
                error: function (returnVal) {
                }
            });
        }
        else {
            self.errorMsg(data.errorMsg);
        }
        //debugger;
        var listDynamicJSON = [];
        self.MyOutStandingQueue = ko.observableArray();
        $.each(self.userCoreActivities(), function (index, value) {
            var tempData = { AgentName: value.AgentName, StartTime: value.StrStartTime, EndTime: value.StrEndTime, Duration: value.Duration, Activity: value.Activity, Task: value.Task, Comments: value.Comments };
            self.MyOutStandingQueue.push(tempData);
        });

        listDynamicJSON.push({
            MyJSON: JSON.stringify(self.MyOutStandingQueue())
        });

        if (self.MyOutStandingQueue().length > 0) {
            var result = Commonmethods.ExportToExcel(listDynamicJSON);
            if (result != null)
                window.location = result;
        } else {
            var msg = "No Data to export."
            $('#cmnMsgText').text(msg);
            $(".message_popup").show();
        }
    };



    self.GetInitialData = function () {
        var url = '/api/GetCoreActivitiesReport?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + $("#dpstartdate").find("input").val().trim() + '&endDate=' + $("#dpenddate").find("input").val().trim();
        var result = null;
        self.BindTable();
    };

    self.getAllTeams = function () {

        var result = [];
        var url = '/api/GetAllTeams?DepartmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: false,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {

                        var selectAllItem = { Id: 0, Name: 'All', DepartmentId: parseInt(sessionStorage.getItem("DepartmentId")) };
                        self.Teams(result);
                        self.Teams.push(selectAllItem);
                        if (sessionStorage.getItem("TeamId") != null && sessionStorage.getItem("TeamId") != 0) {
                            self.selectedTeamId(parseInt(sessionStorage.getItem("TeamId")));
                        }
                    }
                    else {
                        if (self.Teams().length > 0)
                            self.Teams.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });

    };
};



$(function () {
    var viewmodel = new vm();
    ko.applyBindings(viewmodel, document.getElementById('CoreUserActivityReport'));
    SetDefaultDateAndFormatForDatePicker();
    viewmodel.getAllTeams();
    viewmodel.GetInitialData();
});

function SetDefaultDateAndFormatForDatePicker() {

    var arr = GetDefaultDateAndDateFormat().split('$');
    var defaultDate = arr[0]; //((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
    var displayDateFormat = arr[1]; //"mm/dd/yyyy";
    $('#dpstartdate').datepicker({
        autoclose: true,
        format: displayDateFormat

    });
    $('#dpenddate').datepicker({
        autoclose: true,
        format: displayDateFormat
    });

    //set today date as default date
    $("#dpstartdate").datepicker('update', defaultDate);
    $("#dpenddate").datepicker('update', defaultDate);

}

function GetDefaultDateAndDateFormat() {
    try {
        var UserTimeZoneDate = sessionStorage.getItem("UserTimeZoneDate");
        var arrDate = UserTimeZoneDate.split('/');
        var date = new Date(arrDate[2], arrDate[0] - 1, arrDate[1]);
        var monthFullName = new Array(12);
        monthFullName[0] = "January"; monthFullName[1] = "February"; monthFullName[2] = "March"; monthFullName[3] = "April"; monthFullName[4] = "May"; monthFullName[5] = "June"; monthFullName[6] = "July"; monthFullName[7] = "August"; monthFullName[8] = "September"; monthFullName[9] = "October"; monthFullName[10] = "November"; monthFullName[11] = "December";
        var monthName = new Array(12);
        monthName[0] = "Jan"; monthName[1] = "Feb"; monthName[2] = "Mar"; monthName[3] = "Apr"; monthName[4] = "May"; monthName[5] = "Jun"; monthName[6] = "Jul"; monthName[7] = "Aug"; monthName[8] = "Sep"; monthName[9] = "Oct"; monthName[10] = "Nov"; monthName[11] = "Dec";
        var dayName = new Array(7);
        dayName[1] = "Mon"; dayName[2] = "Tues"; dayName[3] = "Wed"; dayName[4] = "Thurs"; dayName[5] = "Fri"; dayName[6] = "Sat"; dayName[7] = "Sun";
        var dayFullName = new Array(7);
        dayFullName[1] = "Monday"; dayFullName[2] = "Tuesday"; dayFullName[3] = "Wednesday"; dayFullName[4] = "Thursday"; dayFullName[5] = "Friday"; dayFullName[6] = "Saturday"; dayFullName[7] = "Sunday";
        var dateformatString = sessionStorage.getItem("DateFormat");
        var separator;
        if (dateformatString.indexOf('/') > -1) {
            separator = '/';
        } else if (dateformatString.indexOf('-') > -1) {
            separator = '-';
        } else if (dateformatString.indexOf(' ') > -1) {
            separator = ' ';
        } else if (dateformatString.indexOf('.') > -1) {
            separator = '.';
        } else if (dateformatString.indexOf('|') > -1) {
            separator = '|';
        } else {
            separator = 'undefined'
        }


        var displayDateFormat;
        var arrDateFormat = dateformatString.split(separator);
        var datePickerFormat;
        var datePickerTodayDate;
        var todayDateVal;
        if (separator != 'undefined') {
            $.each(arrDateFormat, function () {

                switch (this.toString()) {
                    case 'd':
                    case 'd,':
                        {
                            datePickerFormat = 'd';
                            todayDateVal = date.getDate();
                            break;
                        }
                    case 'dd':
                    case 'dd,':
                        {
                            datePickerFormat = 'dd';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'D':
                    case 'D,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'ddd':
                    case 'ddd,':
                    case 'DDD':
                    case 'DDD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'dddd':
                    case 'dddd,':
                    case 'DDDD':
                    case 'DDDD,':
                        {
                            datePickerFormat = 'DD';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'DD':
                    case 'DD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate()
                            break;
                        }
                    case 'm':
                    case 'm,':
                    case 'M':
                    case 'M,':
                        {
                            datePickerFormat = 'm';
                            todayDateVal = date.getMonth() + 1;
                            break;
                        }
                    case 'mm':
                    case 'mm,':
                    case 'MM':
                    case 'MM,':
                        {
                            datePickerFormat = 'mm';
                            todayDateVal = (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1);
                            break;
                        }
                    case 'MMM':
                    case 'MMM,':
                    case 'mmm':
                    case 'mmm,':
                        {
                            datePickerFormat = 'M';
                            todayDateVal = monthName[date.getMonth()];
                            break;
                        }
                    case 'MMMM':
                    case 'MMMM,':
                    case 'mmmm':
                    case 'mmmm,':
                        {
                            datePickerFormat = 'MM';
                            todayDateVal = monthFullName[date.getMonth()];
                            break;
                        }
                    case 'yy':
                    case 'yy,':
                    case 'YY':
                    case 'YY,':
                        {
                            datePickerFormat = 'yy';
                            todayDateVal = date.getFullYear() - 2000;
                            break;
                        }
                    case 'yyyy':
                    case 'yyyy,':
                    case 'YYYYY':
                    case 'YYYYY,':
                        {
                            datePickerFormat = 'yyyy';
                            todayDateVal = date.getFullYear();
                            break;
                        }

                }

                if (displayDateFormat == undefined) {
                    displayDateFormat = datePickerFormat;
                    datePickerTodayDate = todayDateVal;
                }
                else {
                    displayDateFormat += separator + datePickerFormat;
                    datePickerTodayDate += separator + todayDateVal;
                }
            });
            //for not supported date formats
            switch (dateformatString) {

                case "dddd, dd MMMM, yyyy":
                    {
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        break;
                    }
                case "d/M/yyyy":
                case "d-M-yyyy":
                case "d M yyyy":
                case "d.M.yyyy":
                    {
                        displayDateFormat = "m" + separator + "d" + separator + "yyyy";
                        datePickerTodayDate = (date.getMonth() + 1) + separator + (date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
                case "dd/MM/yy":
                case "dd-MM-yy":
                case "dd MM yy":
                case "dd.MM.yy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear() - 2000);
                        break;
                    }
                case "dd/MM/yyyy":
                case "dd-MM-yyyy":
                case "dd MM yyyy":
                case "dd.MM.yyyy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
            }
        }
        else {

            displayDateFormat = "mm/dd/yyyy";
            datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
        }
    }
    catch (ex) {
        displayDateFormat = "mm/dd/yyyy";
        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
    }
    return (datePickerTodayDate + "$" + displayDateFormat);
}