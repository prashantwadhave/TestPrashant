﻿

function ViewModel() {
    var self = this;

    self.userName = ko.observable('');
    self.departmentName = ko.observable('');
    self.HasMultipleDepartment = ko.observable(true);
    self.isNonCoreClockVisisble = ko.observable(false);
    self.isNonCoreStartButtonVisible = ko.observable(true);
    self.isNonCoreStopButtonVisible = ko.observable(false);
    self.isNonCoreStartButtonEnabled = ko.observable(true);
    self.isNonCoreStopButtonEnabled = ko.observable(true);

    self.DDNonCoreActivity = ko.observableArray();
    self.selectedNonCoreActivity = ko.observable();
    self.dd_isNonCoreStartActivityEnabled = ko.observable(true);

    self.nonCoreActivityComment = ko.observable();
    self.DD_Departments = ko.observableArray();
    self.selectedDepartment = ko.observable();
    


    self.nonCoreStartButtonClicked = function () {
        $("#IdSwitchTeam").prop('disabled', true); //self.enableUserSwitchTeam(false);
        //$("#CoreActivity").addClass("disabledbutton");
        //$("#callex").addClass("disabledbutton");
        //$("#WebChat").addClass("disabledbutton");
        //$("#outboundcall").addClass("disabledbutton");
       
        
        //$("#mainContent").addClass("disabledbutton");
        //$(".topbar").addClass("disabledbutton");
        //$(".side-menu").addClass("disabledbutton");
        if (self.errors().length == 0) {
            var nonCoreActivity = {
                LanId: '',
                DepartmentId: sessionStorage.getItem("DepartmentId"),
                TeamId: sessionStorage.getItem("TeamId"),
                AuxCodeId: self.selectedNonCoreActivity(),
                StartTime: new Date(),
                EndTime: null,
                Comment: (self.nonCoreActivityComment() == undefined || self.nonCoreActivityComment() == null) ? ' ' : self.nonCoreActivityComment()
            };
            
            var url = '/api/StartNonCoreActivity?activeNonCoreActivityId=' + sessionStorage.getItem("NonCoreActivityId");
            Commonmethods.AjaxData(url, 'POST', false, '', nonCoreActivity, 'Add Non-Core Activity api is not working.', function (result) {
                if (parseInt(result) == 0) {
                    var msg = 'Non Core Activity is not added in DB.';
                    $('#cmnMsgText').text(msg);
                    $(".message_popup").show();
                }               
                else {
                    self.StartTimerNonCore();
                    self.isNonCoreClockVisisble(true);
                    $("#coreActivityForm").addClass("disabledbutton");
                    $(".hidden-small").addClass("disabledbutton");
                    $("#sideLnk_Dashboard").addClass("disabledbutton");
                    sessionStorage.setItem("NonCoreActivityId", result);
                    isPause = true;
                    self.isNonCoreStartButtonVisible(false);
                    self.isNonCoreStopButtonVisible(true);
                    self.dd_isNonCoreStartActivityEnabled(false);

                    coreViewmodel.isCallStartButtonEnabled(false);
                    coreViewmodel.isCallStopButtonEnabled(false);
                    coreViewmodel.isCoreStartButtonEnabled(false);
                    coreViewmodel.isCoreStopButtonEnabled(false);
                }
            });
        } else {
            self.errors.showAllMessages();
        }
    };

    self.nonCoreStopButtonClicked = function () {
        
        var isCoreActivtyStarted = (sessionStorage.getItem('isCoreActivtyStarted') == undefined || sessionStorage.getItem('isCoreActivtyStarted') == null) ? false : sessionStorage.getItem('isCoreActivtyStarted');
        var isCallActivtyStarted = (sessionStorage.getItem('isCallActivtyStarted') == undefined || sessionStorage.getItem('isCallActivtyStarted') == null) ? false : sessionStorage.getItem('isCallActivtyStarted');
        
        var isAnyCoreActivtyStarted = isCoreActivtyStarted == 'true' || isCoreActivtyStarted==true || isCallActivtyStarted=='true' || isCallActivtyStarted==true ? true : false;
     
        var Comment= (self.nonCoreActivityComment() == undefined || self.nonCoreActivityComment() == null) ? ' ' : self.nonCoreActivityComment();

        var url = '/api/StopNonCoreActivity?activeNonCoreActivityId=' + sessionStorage.getItem("NonCoreActivityId") + '&comments=' + Comment + '&isAnyCoreActivtyStarted=' + isAnyCoreActivtyStarted;
        Commonmethods.AjaxData(url, 'PUT', false, '', '', 'Update Non-Core Activity api is not working.', function (result) {
            self.StopClockNonCore();            
            self.isNonCoreClockVisisble(false);
            $("#coreActivityForm").removeClass("disabledbutton");
            $(".hidden-small").removeClass("disabledbutton");
            $("#sideLnk_Dashboard").removeClass("disabledbutton");
            $("#IdSwitchTeam").prop('disabled', false);  //self.enableUserSwitchTeam(true);

            isPause = false;
            sessionStorage.setItem("NonCoreActivityId", result);
            self.selectedNonCoreActivity(null);
            self.nonCoreActivityComment('');
            self.errors.showAllMessages(false);

            self.isNonCoreStartButtonVisible(true);
            self.isNonCoreStopButtonVisible(false);
            self.dd_isNonCoreStartActivityEnabled(true);

            coreViewmodel.isCallStartButtonEnabled(true);
            coreViewmodel.isCallStopButtonEnabled(true);
            coreViewmodel.isCoreStartButtonEnabled(true);
            coreViewmodel.isCoreStopButtonEnabled(true);           
        });
    };

    self.GetNonCoreActivity = function () {
        var url = '/api/GetAllAuxCode?departmentId=' + sessionStorage.getItem("DepartmentId");
        Commonmethods.AjaxData(url, 'GET', false, '', '', 'GetAllAuxCode api is not working.', function (result) {
            self.DDNonCoreActivity(result);
        });
    }

    self.AddIdleAndLoggedInActivity = function () {

        var nonCoreActivity = {
            LanId: '',
            DepartmentId: sessionStorage.getItem("DepartmentId"),
            TeamId: sessionStorage.getItem("TeamId"),
            AuxCodeId: 1,//Idle status
            StartTime: new Date(),
            EndTime: null,
            Comment: self.nonCoreActivityComment()
        };

        var isDepartmentOrRoleChanged = (sessionStorage.getItem("isDepartmentOrRoleChanged") == null || sessionStorage.getItem("isDepartmentOrRoleChanged") == 'undefined') ? false : sessionStorage.getItem("isDepartmentOrRoleChanged");
        var url = '/api/AddUserLoginDetails?isDepartmentOrRoleChanged=' + isDepartmentOrRoleChanged;
        Commonmethods.AjaxData(url, 'POST', false, '', nonCoreActivity, 'Add User Login Details api is not working.', function (result) {
            if (result == null) {
                var msg = 'User Login Details not added in DB';
                $('#cmnMsgText').text(msg);
                $(".message_popup").show();
            }                    
            else {
                sessionStorage.setItem("NonCoreActivityId", result.NonCoreActivityId);  

                if (result.UserLogId != 0 || result.UserLogId != '0')
                    sessionStorage.setItem("UserLogId", result.UserLogId);
                
            }

            sessionStorage.setItem("isDepartmentOrRoleChanged", false);
        });
    }

    self.ChangeDepartmentOrRole = function () {       
        var url = '/api/GetAllDepartments';
        Commonmethods.AjaxData(url, 'GET', false, '', '', 'GetAllDepartments api is not working.', function (result) {
            self.DD_Departments(result);
        });
    }
    
    self.UpdateDepartmentOrRole = function () {
        if (self.selectedDepartment() != undefined) {

            $.each(self.DD_Departments(), function (index, value) {
                if (value.Id == self.selectedDepartment())
                {
                    sessionStorage.setItem("DepartmentName", value.Name);
                }
            });

            sessionStorage.setItem("DepartmentId", self.selectedDepartment());
            //self.GetAllTeamsByUserId();
            sessionStorage.setItem("isDepartmentOrRoleChanged", true);
            sessionStorage.setItem("isUserLoggedIn", false);

            var nonCoreActivityId = sessionStorage.getItem("NonCoreActivityId") == undefined ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));
            var url = '/api/ChangeDepartment?departmentId=' + sessionStorage.getItem("DepartmentId") + '&nonCoreActivityId=' + nonCoreActivityId;
            Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unauthorized user', function (result) {
                
                sessionStorage.setItem("HasAdvisorRole", result.HasAdvisorRole);
                sessionStorage.setItem("UserAccessibleUrls", result.UserAccessibleUrls);
                if (result.UserLogId != 0 || result.UserLogId != '0')
                    sessionStorage.setItem("UserLogId", result.UserLogId);
                //sessionStorage.setItem("TeamId", 0);
                window.location.href = window.location.origin;
            });
        } else {            
            var msg = 'New department id ' + self.selectedDepartment() + '  and new role id ' + self.selectedRole();
            $('#cmnMsgText').text(msg);
            $(".message_popup").show();
        }
       
    }

    self.logout = function () {
        var nonCoreActivityId = sessionStorage.getItem("NonCoreActivityId") == undefined ? 0 : parseInt(sessionStorage.getItem("NonCoreActivityId"));
        var userLogId = sessionStorage.getItem("UserLogId") == undefined ? 0 : parseInt(sessionStorage.getItem("UserLogId"));

        var url = '/api/UserLoggedOut?departmentId=' + sessionStorage.getItem("DepartmentId") + '&nonCoreActivityId=' + nonCoreActivityId + '&userLogId=' + userLogId;
        Commonmethods.AjaxData(url, 'GET', false, '', '', 'Unauthorized user', function (result) {
            sessionStorage.clear();
            window.location.href = window.location.origin + "/Templates/LoggedOutPage.html";
        });        
    }

    //none timer
    var InitialTimeNCore = new Date().getTime();
    var extraSecondsNCore = 0;
    var extraMinsNCore = 0;
    var firstLoadNCore = 0;
    //-------Start Clock
    self.counterNCore = null;
    self.recordtimeNCore = ko.observable();;
    self.secondsNCore = ko.observable(0);
    self.minutesNCore = ko.observable(0);
    self.hoursNCore = ko.observable(0);
    self.cssClockNCore = ko.observable();
    self.idleActivityCounterNCore = ko.observable(0);
    self.isIdleDisplayNCore = ko.observable(true);

    self.setNCoreSeconds = ko.computed(function () {
        if (self.secondsNCore() == 60) {
            return "00";
        }
        else {
            if (self.secondsNCore() < 10)
                return "0" + self.secondsNCore();
            else
                return self.secondsNCore();
        }
    });

    self.setNCoreMinutes = ko.computed(function () {
        if (self.minutesNCore() == 60) {
            return "00";
        }
        else {
            if (self.minutesNCore() < 10)
                return "0" + self.minutesNCore();
            else
                return self.minutesNCore();
        }
    });

    self.setNCoreHours = ko.computed(function () {
        if (self.hoursNCore() < 10)
            return "0" + self.hoursNCore();
        else
            return self.hoursNCore();
    });

    self.tickNCore = function () {

        if (self.secondsNCore() == 59) {
            if (self.minutesNCore() == 59) {
                self.hoursNCore(self.hoursNCore() + 1);
                self.minutesNCore(0);
                self.secondsNCore(0);
            }
            else {
                self.minutesNCore(self.minutesNCore() + 1);
                self.secondsNCore(0);
            }
        }
        else {
            //Code for updating browser idle time in to timer
            var currentTimeNCore = new Date().getTime();
            var secondsDifferenceNCore = 0;
            if (firstLoadNCore === 0) {
                var secondsDifferenceNCore = 0;
                firstLoadNCore = 1;
            }
            else {
                secondsDifferenceNCore = Math.floor((currentTimeNCore - currentTimeNCore) / 1000);
            }

            if (secondsDifferenceNCore == 0) {
                self.secondsNCore(self.secondsNCore() + 1);
            }
            else {
                if (self.secondsNCore() + secondsDifferenceNCore > 59) {
                    extraSecondsNCore = self.secondsNCore() + secondsDifferenceNCore;
                    self.secondsNCore(extraSecondsNCore % 60)
                    extraMinsNCore = self.minutesNCore() + Math.round(extraSecondsNCore / 60);
                    if (extraMinsNCore > 59) {
                        self.minutesNCore(extraMinsNCore % 60);
                        self.hoursNCore(self.hoursNCore() + Math.round(extraMinsNCore / 60));
                    }
                    else { self.minutesNCore(extraMinsNCore); }
                    extraSecondsNCore = 0;
                    extraMinsNCore = 0;
                }
                else {
                    self.secondsNCore(self.secondsNCore() + secondsDifferenceNCore);
                }
            }
            InitialTimeNCore = currentTimeNCore;
        }

        //Code to Display Idle Activity Popup after every 30
        if (sessionStorage.getItem("IsIdleActivity") == "true") {
            //If User have Admin role then
            var roles = sessionStorage.getItem("Roles").split(",");
            if (roles.indexOf("Admin") > -1 || roles.indexOf("Manager") > -1) {
            }
            else {
                //If User have Admin role then validate Idle Activity Time
                self.idleActivityCounterNCore(self.idleActivityCounterNCore() + 1);
                var idleActivityCounterValueNCore = Constants.IdleTimerSettings.DurationInSecondsForPopup;
                if (self.idleActivityCounterNCore() == idleActivityCounterValueNCore) {
                    if (self.isIdleDisplayNCore() == true) {
                        self.isIdleDisplayNCore(false);
                        Commonmethods.CustomAlert('Idle Message', 'You are idle for ' + Constants.IdleTimerSettings.DurationInSecondsForPopup + ' seconds.', 'Info');
                    }
                }
            }
        }
    }
    self.StartTimerNonCore = function () {

        InitialTimeNCore = new Date().getTime();
        firstLoadNCore = 0;
        //set clock
        if (self.counterNCore != null) {
            clearInterval(self.counterNCore);
        }
        self.counterNCore = setInterval(self.tickNCore, 1000)
        // self.cssClock('timer-start');
    }
    self.StopClockNonCore = function () {
        //set clock------------------
        //InitialTime = new Date().getTime();
        firstLoadNCore = 0;
        self.cssClockNCore('');
        self.secondsNCore(0);
        self.minutesNCore(0);
        self.hoursNCore(0);
        clearInterval(self.counterNCore);
    }
    self.ResetIdleActivityCounterNCore = function () {
        self.idleActivityCounterNCore(0);
        self.isIdleDisplayNCore(true);
    }
    //end Non core
    //end timer


    


    ////Validations
    self.selectedNonCoreActivity.extend({
        required: {
            param: true,
            message: "Please select an activity."
        }
    });

    let NonCoreValidationFields = [self.selectedNonCoreActivity];
    self.errors = ko.validation.group(NonCoreValidationFields);
}

var nonCoreViewModel = new ViewModel();

function disableF5(e) {
    if (((e.which || e.keyCode) == 116) || ((e.which || e.keyCode) == 82) && e.ctrlKey) e.preventDefault();
};

function DisableRightClick() {
    alert("Sorry, Right Click Disabled");
    return false;
}


$(document).ready(function () {
    $(document).on("keydown", disableF5);
 
    try {
        sessionStorage.setItem("DateFormat", "dd-mmm-yyyy");
        if (sessionStorage.getItem("isUserLoggedIn") == null || sessionStorage.getItem("isUserLoggedIn") == undefined || sessionStorage.getItem("isUserLoggedIn") == 'false' || sessionStorage.getItem("isUserLoggedIn") == false) {
            sessionStorage.setItem("isUserLoggedIn", true);
        } else {
            sessionStorage.clear();
            window.location.href = window.location.origin + "/Templates/SessionActive.html";
            return;
        }

        DeclareVariableAndSession();
        
        if (sessionStorage.getItem('isUserAuthenticated') != 'true')
            IsUserAuthorized();
        else
            loadSidelinks();
       
        if (!IsUserSessionActiveInDB) {
            ko.validation.registerExtenders();
            var knockoutValidationSettings = {
                registerExtenders: true,
                insertMessages: true,
                decorateElement: true,
                errorMessageClass: 'error',
                messagesOnModified: true,
                decorateElementOnModified: true,
                decorateInputElement: true
            };        
            ko.validation.init(knockoutValidationSettings, true);  
            
            var element = document.getElementById('wrapper');               
            ko.cleanNode(element);
            ko.applyBindings(nonCoreViewModel, element);
            
            nonCoreViewModel.AddIdleAndLoggedInActivity();
            nonCoreViewModel.GetNonCoreActivity();
            nonCoreViewModel.userName(sessionStorage.getItem("UserName"));
            nonCoreViewModel.departmentName(sessionStorage.getItem("DepartmentName"));
            nonCoreViewModel.HasMultipleDepartment(HasMultipleDepartment);
            loadSidelinks();           
        }
    } catch (e) {
        console.log(e);
    }
});

function DeclareVariableAndSession() {
    isUserAuthenticated = false;
    IsUserSessionActiveInDB = false;
    HasMultipleDepartment = true;
}

function IsUserAuthorized() {

    Commonmethods.AjaxData('/api/IsUserAuthorized', 'GET', false, '', '', 'Unauthorized user', function (result) {
        if (result == null || result == undefined) {
            sessionStorage.setItem('isUserAuthenticated', false);
            window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
        }
        else {
            if (result.DepartmentId == '0' || result.DepartmentId == 0) {              
                sessionStorage.clear();
                window.location.href = window.location.origin + "/Templates/Configurations/Users/Unauthorized.html";
                IsUserSessionActiveInDB = true;                
            } else if (result.IsUserSessionActiveInDB == 'true' || result.IsUserSessionActiveInDB == true) {
                sessionStorage.clear();
                window.location.href = window.location.origin + "/Templates/SessionActive.html";
                IsUserSessionActiveInDB = true;
            } else {                
                sessionStorage.setItem("DepartmentName", result.DepartmentName);
                sessionStorage.setItem("DepartmentId", result.DepartmentId);
                sessionStorage.setItem("UserName", result.FullName);
                sessionStorage.setItem("HasAdvisorRole", result.HasAdvisorRole);
                sessionStorage.setItem("TeamId", result.TeamId);
                sessionStorage.setItem("UserId", result.UserId);
                sessionStorage.setItem("UserTimeZoneDate", result.UserTimeZoneDate.Month + '/' + result.UserTimeZoneDate.Day + '/' + result.UserTimeZoneDate.Year);
                HasMultipleDepartment = result.HasMultipleDepartment;
                if (!HasMultipleDepartment) {
                    $('.fullsc').addClass('userswidth');
                    $('.logoutl').addClass('userswidth');
                }
                else {
                    $('.fullsc').removeClass('userswidth');
                    $('.logoutl').removeClass('userswidth');
                }
                //loadSidelinks();
                isUserAuthenticated = true;
                sessionStorage.setItem("UserAccessibleUrls", result.UserAccessibleUrls);
                sessionStorage.setItem('isUserAuthenticated', true);  
               
            }
        }
    });
}

function loadSidelinks() {
    
    $('#SideLinks').empty();
    var homepg = $('#2')[0];
    if (homepg == undefined)
        $('#sideLinks').load('Templates/Sidelinks.html');

    $('#leftMenu').show();
    $('.page-container').removeClass('login-container');

    var window = $(".k-window-content").data("kendoWindow");
    if (window != null)
        window.destroy();
}


