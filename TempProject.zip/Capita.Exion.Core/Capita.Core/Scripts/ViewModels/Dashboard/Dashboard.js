﻿
$(function () {
    var objVmForDashBoard = new vmForDashboard();
    ko.applyBindings(objVmForDashBoard, document.getElementById('divDashboard'));
    objVmForDashBoard.GetAllTeamsByUserId();
    objVmForDashBoard.LoadData();
});

function vmForDashboard() {
    var self = this;
    self.realTimeDashboard = ko.observableArray();
    self.UserTeams = ko.observableArray();
    self.selectedUserTeamId = ko.observable();
    self.TeamName = ko.observable();


    self.GetInitialData = function (defaultDate) {

        var url = '/api/GetRealTimeDashboard?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + defaultDate + '&endDate=' + defaultDate + '&teamId=' + sessionStorage.getItem("TeamId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.realTimeDashboard(result);
                    }
                    else {
                        if (self.realTimeDashboard().length > 0)
                            self.realTimeDashboard.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    };

    self.DrawProductiveNonProductive = function (defaultDate) {
        var colors = ['#dd5555', '#55dd55', '#5555dd', '#ddd'];
        var url = '/api/GetProductiveNonProductive?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + defaultDate + '&endDate=' + defaultDate + '&teamId=' + sessionStorage.getItem("TeamId");
        var result = null;
        
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_productive").empty();
                        var chart = c3.generate({
                            bindto: '#ProductiveChartContainer',
                            size: {
                                width: 400,
                                height: 300
                            },
                            padding: {
                                top: 20,
                                right: 20
                            },
                            data: {
                                json: result,
                                keys: {
                                    x: 'Name',
                                    value: ['Core', 'NonCore'],
                                },
                                type: 'bar',
                                labels: {
                                    show: true,
                                    format: function (value) {
                                        return d3.format(",.2f")(value);
                                    }
                                }
                            },
                            bar: {
                                space: 0.25
                            },
                            axis: {
                                y: {
                                    label: {
                                        text: 'Time',
                                        position: 'outer-middle'
                                    }
                                },
                                x: {
                                    type: 'categorized'
                                }
                            },
                            tooltip: {
                                format: {
                                    value: function (value, ratio, id) {
                                        if (id == 'Core') { return result[0].TotalTimeProductive; }
                                        else { return result[0].TotalTimeNonProductive; }
                                    }
                                }
                            }
                        });
                    }
                    else {
                        $("#ProductiveChartContainer").empty();
                        $("#nodatamsg_productive").text("No Data Available");
                        $("#nodatamsg_productive").show();
                    }
                }
                else {
                    $("#ProductiveChartContainer").empty();
                }
            },
            error: function (returnVal) {
            }
        });

    }
    self.CurrentStatistics = function (defaultDate) {


        var url = '/api/GetUserCurrentStatistic?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + defaultDate + '&endDate=' + defaultDate + '&teamId=' + sessionStorage.getItem("TeamId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_stats").empty();
                        var data = {};
                        var activity = [];
                        result.forEach(function (e) {
                            activity.push(e.ActivityType);
                            data[e.ActivityType] = e.TaskCount;
                        })

                        var chart = c3.generate({
                            bindto: '#CurrentStatsChartContainer',
                            size: {
                                width: 400,
                                height: 300
                            },
                            padding: {
                                top: 20,
                                right: 20
                            },
                            data: {
                                json: [data],
                                keys: {
                                    value: activity
                                },
                                type: 'bar',
                                labels: {
                                    show: true
                                }
                            },
                            bar: {
                                space: 0.25
                            },
                            axis: {
                                y: {
                                    label: {
                                        text: 'Task Count',
                                        position: 'outer-middle'
                                    }
                                },
                                x: {
                                    type: 'category',
                                    categories: ['Task Name']
                                }
                            },
                            tooltip: {
                                grouped: false
                            }
                        });
                    }
                    else {
                        $("#CurrentStatsChartContainer").empty();
                        $("#nodatamsg_stats").text("No Data Available");
                        $("#nodatamsg_stats").show();
                    }
                }
                else {
                    $("#CurrentStatsChartContainer").empty();
                }
            },
            error: function (returnVal) {
            }
        });

    }
    self.DrawCoreNonCore = function (defaultDate) {

        var url = '/api/GetCoreNonCoreTime?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + defaultDate + '&endDate=' + defaultDate + '&teamId=' + sessionStorage.getItem("TeamId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_timeUtil").empty();
                        var data = {};
                        var activity = [];
                        result.forEach(function (e) {
                            activity.push(e.Name);
                            data[e.Name] = e.Hours;
                        });

                        var chart = c3.generate({
                            bindto: '#CoreNonCoreChart',
                            size: {
                                width: 400,
                                height: 300
                            },
                            padding: {
                                top: 20,
                                right: 20
                            },
                            data: {
                                json: [data],
                                keys: {
                                    value: activity,
                                },
                                type: 'donut'
                            },
                            donut: {
                                label: {
                                    format: function (value) {
                                        return d3.format(",.2f")(value);
                                    }
                                }
                            },
                            tooltip: {
                                format: {
                                    value: function (value, ratio, id) {
                                        if (id!="") {
                                            var r = jQuery.grep(result, function (item) { return id == item.Name; });
                                            return r[0].DisplayName;
                                        }
                                    }
                                }
                            }

                        });
                    }
                    else {
                        $("#CoreNonCoreChart").empty();
                        $("#nodatamsg_timeUtil").text("No Data Available");
                        $("#nodatamsg_timeUtil").show();

                    }
                }
                else {
                    $("#CoreNonCoreChart").empty();
                }
            },
            error: function (returnVal) {
            }
        });
    }
    self.LoadData = function () {
        var arr = GetDefaultDateAndDateFormat().split('$');
        var defaultDate = arr[0];

        self.GetInitialData(defaultDate);
        self.DrawProductiveNonProductive(defaultDate);
        self.CurrentStatistics(defaultDate);
        self.DrawCoreNonCore(defaultDate);
    }


    //SwitchTeams - START
    self.OpenSwitchTeam = function () {
        $("#dvSwitchTeam").show();
    }


    self.ClosePopupSwitchTeam = function () {
        $("#dvSwitchTeam").hide();
    }

    self.GetAllTeamsByUserId = function () {
        var result = [];
        var url = '/api/GetAllTeamsByUserId?userId=' + sessionStorage.getItem("UserId") + '&departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        var isDefaultTeam = false;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.UserTeams(result);
                        
                        if (sessionStorage.getItem("TeamId") != null && sessionStorage.getItem("TeamId") != 0) {
                            ko.utils.arrayForEach(self.UserTeams(), function (item) {
                                if (parseInt(sessionStorage.getItem("TeamId")) == item.Id) {
                                    self.TeamName(item.Name);
                                    isDefaultTeam = true;
                                }
                            });

                            if (!isDefaultTeam) {
                                sessionStorage.setItem("TeamId", result[0].Id);
                                self.TeamName(result[0].Name);
                            }
                            self.selectedUserTeamId(parseInt(sessionStorage.getItem("TeamId")));
                        }
                    }
                    else {
                        if (self.UserTeams().length > 0)
                            self.UserTeams.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
    }


    self.SwitchTeam = function () {
        sessionStorage.setItem("TeamId", self.selectedUserTeamId());
        ko.utils.arrayForEach(self.UserTeams(), function (item) {
            if (parseInt(sessionStorage.getItem("TeamId")) == item.Id) {
                self.TeamName(item.Name);
            }
        });
        $("#dvSwitchTeam").hide();
        self.LoadData();
        self.OnSwitchTeamAddIdleEntryWithCurrentTeam();
    }

    self.OnSwitchTeamAddIdleEntryWithCurrentTeam = function () {
        var nonCoreActivity = {
            LanId: '',
            DepartmentId: sessionStorage.getItem("DepartmentId"),
            TeamId: sessionStorage.getItem("TeamId"),
            AuxCodeId: 1,
            StartTime: new Date(),
            EndTime: null,
            Comment: 'Team Changed'
        };
        var url = '/api/StartNonCoreActivity?activeNonCoreActivityId=' + sessionStorage.getItem("NonCoreActivityId");
        Commonmethods.AjaxData(url, 'POST', false, '', nonCoreActivity, 'Add Non-Core Activity api is not working.', function (result) {
            var r = result;
            sessionStorage.setItem("NonCoreActivityId", result);
        });
    };


    // Teams - END

};

function GetDefaultDateAndDateFormat() {
    try {
        var UserTimeZoneDate = sessionStorage.getItem("UserTimeZoneDate");
        var arrDate = UserTimeZoneDate.split('/');
        var date = new Date(arrDate[2], arrDate[0] - 1, arrDate[1]);
        var monthFullName = new Array(12);
        monthFullName[0] = "January"; monthFullName[1] = "February"; monthFullName[2] = "March"; monthFullName[3] = "April"; monthFullName[4] = "May"; monthFullName[5] = "June"; monthFullName[6] = "July"; monthFullName[7] = "August"; monthFullName[8] = "September"; monthFullName[9] = "October"; monthFullName[10] = "November"; monthFullName[11] = "December";
        var monthName = new Array(12);
        monthName[0] = "Jan"; monthName[1] = "Feb"; monthName[2] = "Mar"; monthName[3] = "Apr"; monthName[4] = "May"; monthName[5] = "Jun"; monthName[6] = "Jul"; monthName[7] = "Aug"; monthName[8] = "Sep"; monthName[9] = "Oct"; monthName[10] = "Nov"; monthName[11] = "Dec";
        var dayName = new Array(7);
        dayName[1] = "Mon"; dayName[2] = "Tues"; dayName[3] = "Wed"; dayName[4] = "Thurs"; dayName[5] = "Fri"; dayName[6] = "Sat"; dayName[7] = "Sun";
        var dayFullName = new Array(7);
        dayFullName[1] = "Monday"; dayFullName[2] = "Tuesday"; dayFullName[3] = "Wednesday"; dayFullName[4] = "Thursday"; dayFullName[5] = "Friday"; dayFullName[6] = "Saturday"; dayFullName[7] = "Sunday";
        var dateformatString = sessionStorage.getItem("DateFormat");
        var separator;
        if (dateformatString.indexOf('/') > -1) {
            separator = '/';
        } else if (dateformatString.indexOf('-') > -1) {
            separator = '-';
        } else if (dateformatString.indexOf(' ') > -1) {
            separator = ' ';
        } else if (dateformatString.indexOf('.') > -1) {
            separator = '.';
        } else if (dateformatString.indexOf('|') > -1) {
            separator = '|';
        } else {
            separator = 'undefined'
        }


        var displayDateFormat;
        var arrDateFormat = dateformatString.split(separator);
        var datePickerFormat;
        var datePickerTodayDate;
        var todayDateVal;
        if (separator != 'undefined') {
            $.each(arrDateFormat, function () {

                switch (this.toString()) {
                    case 'd':
                    case 'd,':
                        {
                            datePickerFormat = 'd';
                            todayDateVal = date.getDate();
                            break;
                        }
                    case 'dd':
                    case 'dd,':
                        {
                            datePickerFormat = 'dd';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'D':
                    case 'D,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'ddd':
                    case 'ddd,':
                    case 'DDD':
                    case 'DDD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'dddd':
                    case 'dddd,':
                    case 'DDDD':
                    case 'DDDD,':
                        {
                            datePickerFormat = 'DD';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'DD':
                    case 'DD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate()
                            break;
                        }
                    case 'm':
                    case 'm,':
                    case 'M':
                    case 'M,':
                        {
                            datePickerFormat = 'm';
                            todayDateVal = date.getMonth() + 1;
                            break;
                        }
                    case 'mm':
                    case 'mm,':
                    case 'MM':
                    case 'MM,':
                        {
                            datePickerFormat = 'mm';
                            todayDateVal = (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1);
                            break;
                        }
                    case 'MMM':
                    case 'MMM,':
                    case 'mmm':
                    case 'mmm,':
                        {
                            datePickerFormat = 'M';
                            todayDateVal = monthName[date.getMonth()];
                            break;
                        }
                    case 'MMMM':
                    case 'MMMM,':
                    case 'mmmm':
                    case 'mmmm,':
                        {
                            datePickerFormat = 'MM';
                            todayDateVal = monthFullName[date.getMonth()];
                            break;
                        }
                    case 'yy':
                    case 'yy,':
                    case 'YY':
                    case 'YY,':
                        {
                            datePickerFormat = 'yy';
                            todayDateVal = date.getFullYear() - 2000;
                            break;
                        }
                    case 'yyyy':
                    case 'yyyy,':
                    case 'YYYYY':
                    case 'YYYYY,':
                        {
                            datePickerFormat = 'yyyy';
                            todayDateVal = date.getFullYear();
                            break;
                        }

                }

                if (displayDateFormat == undefined) {
                    displayDateFormat = datePickerFormat;
                    datePickerTodayDate = todayDateVal;
                }
                else {
                    displayDateFormat += separator + datePickerFormat;
                    datePickerTodayDate += separator + todayDateVal;
                }
            });
            //for not supported date formats
            switch (dateformatString) {

                case "dddd, dd MMMM, yyyy":
                    {
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        break;
                    }
                case "d/M/yyyy":
                case "d-M-yyyy":
                case "d M yyyy":
                case "d.M.yyyy":
                    {
                        displayDateFormat = "m" + separator + "d" + separator + "yyyy";
                        datePickerTodayDate = (date.getMonth() + 1) + separator + (date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
                case "dd/MM/yy":
                case "dd-MM-yy":
                case "dd MM yy":
                case "dd.MM.yy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear() - 2000);
                        break;
                    }
                case "dd/MM/yyyy":
                case "dd-MM-yyyy":
                case "dd MM yyyy":
                case "dd.MM.yyyy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
            }
        }
        else {

            displayDateFormat = "mm/dd/yyyy";
            datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
        }
    }
    catch (ex) {
        displayDateFormat = "mm/dd/yyyy";
        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
    }
    return (datePickerTodayDate + "$" + displayDateFormat);
}