﻿
$(function () {
    var objvm = new vm();
    ko.applyBindings(objvm, document.getElementById('divManagerDashboard'));
    var arr = GetDefaultDateAndDateFormat().split('$');
    var defaultDate = arr[0];
    var displayDateFormat = arr[1]; //"mm/dd/yyyy";
    $('#datepicker1').datepicker({
        autoclose: true,
        format: displayDateFormat

    });
    $('#datepicker2').datepicker({
        autoclose: true,
        format: displayDateFormat

    });

    $("#datepicker1").datepicker('update', defaultDate);
    $("#datepicker2").datepicker('update', defaultDate);
    objvm.getAllTeams();
    objvm.GetInitialData();
    objvm.GetRealTimeDashboard(0, defaultDate, defaultDate);
    objvm.CurrentStatistics(0, defaultDate, defaultDate);

});

function vm() {
    var self = this;
    self.realTimeDashboard = ko.observableArray();
    self.coreNonCoreDashboard = ko.observableArray();
    self.RTA_Dashboard = ko.observableArray();
    self.empList = ko.observableArray();
    self.selectedUserId = ko.observable(0);
    self.errorMsg = ko.observable();
    self.Teams = ko.observableArray();
    self.selectedTeamId = ko.observable();
    
    var tblManagerRTA;

    self.GetInitialData = function () {
        var startDate = $("#datepicker1").find("input").val().trim();
        var endDate = $("#datepicker2").find("input").val().trim();
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetEmployeesByManagerIdLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId ;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
             
                if (result.LstProductiveNonProductiveHours != null) {
                    if (result.LstProductiveNonProductiveHours.length > 0) {
                        $("#nodatamsg_productive").empty();
                        self.DrawBarChart(result.LstProductiveNonProductiveHours);
                    }
                    else {
                        $("#ProductiveChartContainer").empty();
                        $("#nodatamsg_productive").text("No Data Available");
                        $("#nodatamsg_productive").show();
                    }
                }
                else {
                    $("#ProductiveChartContainer").empty();
                    //$("#CurrentStatsChartContainer").empty();
                }

                if (result.LstCoreNonCoreTimeHours != null) {
                    if (result.LstCoreNonCoreTimeHours.length > 0) {
                        $("#nodatamsg_timeUtil").empty();
                        self.DrawDonutChart(result.LstCoreNonCoreTimeHours);
                    }
                    else {
                        $("#CoreNonCoreChart").empty();
                        $("#nodatamsg_timeUtil").text("No Data Available");
                        $("#nodatamsg_timeUtil").show();
                    }
                }
                else {
                    $("#CoreNonCoreChart").empty();
                }
            },
            error: function (returnVal) {
            }
        });

        if (startDate != "" && endDate != "") {
            self.DrawEmployeesCoreNonCoreData(0, startDate, endDate);
        }

    }

    self.GetRealTimeDashboard = function (userId, startDate, endDate) {

        var checkStartDate = $('#datepicker1').datepicker('getDate');
        var checkEndDate = $('#datepicker2').datepicker('getDate');
        var dateDiff = (checkEndDate - checkStartDate) / 86400000;
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();

        if (dateDiff >= 0 && dateDiff <= 7) {
            var url = '/api/GetRealTimeDashboardLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + userId + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
            tblManagerRTA = $('#tblManagerDashboard').dataTable({
                "serverSide": true,
                "processing": true,
                "orderMulti": false,
                "filter": true,
                "destroy": true,
                "ajax": {
                    "url": url,
                    "type": "POST",
                    "datatype": "json"
                },
                "columns": [

                    { "data": "Name", 'bSortable': true, "title": "Name", "autowidth": true },
                    { "data": "ActivityName", "title": "Activity Name", "autowidth": true },
                    { "data": "Comment", "title": "Comment", "autowidth": true },
                    { "data": "StrStartTime", "title": "Start Time", "autowidth": true },
                    { "data": "StrEndTime", "title": "End Time", "autowidth": true },
                    { "data": "ConsumeTime", "title": "Consume Time", "autowidth": true }],
                "fnInitComplete": function (settings, json) {
                    $('#tblManagerDashboard_filter input').unbind();
                    $('#tblManagerDashboard_filter input').bind('keyup', function (e) {
                        if (e.keyCode == 13) {
                            //model.SearchValue(this.value);
                            tblManagerRTA.fnFilter(this.value);
                        }
                    });
                }
            });

        }
        else {
            //show alert
        }

    };

    self.DrawProductiveNonProductive = function (userId, startDate, endDate) {
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetProductiveNonProductiveLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + userId + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_productive").empty();
                        self.DrawBarChart(result);
                    }
                    else {
                        $("#ProductiveChartContainer").empty();
                        $("#nodatamsg_productive").text("No Data Available");
                        $("#nodatamsg_productive").show();
                    }
                }
                else {
                    $("#ProductiveChartContainer").empty();
                }
            },
            error: function (returnVal) {
            }
        });

    }

    self.CurrentStatistics = function (userId, startDate, endDate) {
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var arr = GetDefaultDateAndDateFormat().split('$');
        var defaultDate = arr[0];
        var url = '/api/GetUserCurrentStatisticLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + userId + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_stats").empty();
                        var data = {};
                        var activity = [];
                        result.forEach(function (e) {
                            activity.push(e.ActivityType);
                            data[e.ActivityType] = e.TaskCount;
                        })

                        var chart = c3.generate({
                            bindto: '#CurrentStatsChartContainer',
                            size: {
                                width: 400,
                                height: 300
                            },
                            padding: {
                                top: 20,
                                right: 20
                            },
                            data: {
                                json: [data],
                                keys: {
                                    value: activity
                                },
                                type: 'bar',
                                labels: {
                                    show: true
                                }
                            },
                            bar: {
                                space: 0.25
                            },
                            axis: {
                                y: {
                                    label: {
                                        text: 'Task Count',
                                        position: 'outer-middle'
                                    }
                                },
                                x: {
                                    type: 'category',
                                    categories: ['Task Name']
                                }
                            },
                            tooltip: {
                                grouped: false
                            }
                        });
                    }
                    else {
                        $("#CurrentStatsChartContainer").empty();
                        $("#nodatamsg_stats").text("No Data Available");
                        $("#nodatamsg_stats").show();
                    }
                }
                else {
                    $("#CurrentStatsChartContainer").empty();
                }
            },
            error: function (returnVal) {
            }
        });

    }

    self.DrawCoreNonCore = function (userId, startDate, endDate) {
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetCoreNonCoreTimeLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + userId + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        $("#nodatamsg_timeUtil").empty();
                        self.DrawDonutChart(result);
                    }
                    else {
                        $("#CoreNonCoreChart").empty();
                        $("#nodatamsg_timeUtil").text("No Data Available");
                        $("#nodatamsg_timeUtil").show();
                    }
                }
                else {
                    $("#CoreNonCoreChart").empty();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.DisplayCurrentUsersActivity = function () {
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetCurrentUsersActivity?departmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.RTA_Dashboard(result);
                    }
                    else {
                        //alert();
                    }
                }
                else {
                    //$("#CoreNonCoreChart").empty();
                }
            },
            error: function (returnVal) {
            }
        });
    }

    self.GetDataGOclicked = function () {
        var data = self.ValidateStartAndEndDate();

        if (data.errorMsg == "") {
            self.errorMsg('');

            var checkStartDate = data.checkStartDate;
            var checkEndDate = data.checkEndDate;
            var dateDiff = data.dateDiff;
            var startDate = data.startDate;
            var endDate = data.endDate;

            if (self.selectedUserId() != undefined) {
                self.GetRealTimeDashboard(self.selectedUserId(), startDate, endDate);
                self.DrawProductiveNonProductive(self.selectedUserId(), startDate, endDate);
                self.CurrentStatistics(self.selectedUserId(), startDate, endDate);
                self.DrawCoreNonCore(self.selectedUserId(), startDate, endDate);
                self.DrawEmployeesCoreNonCoreData(self.selectedUserId(), startDate, endDate);
            }


        }
        else {
            self.errorMsg(data.errorMsg);
        }
    }

    self.ValidateStartAndEndDate = function () {
        var errorMsg = "";
        var checkStartDate = $('#datepicker1').datepicker('getDate');
        var checkEndDate = $('#datepicker2').datepicker('getDate');
        var dateDiff = (checkEndDate - checkStartDate) / 86400000;
        var startDate = $("#datepicker1").find("input").val().trim();
        var endDate = $("#datepicker2").find("input").val().trim();
        var checkStartDate_Year = checkStartDate.getFullYear();
        var checkEndDate_Year = checkEndDate.getFullYear();

        if (startDate == "" && endDate == "") {
            errorMsg = "Please select from date and to date";
        }
        else if (startDate == "") {
            errorMsg = "Please select from date";
        }
        else if (endDate == "") {
            errorMsg = "Please select to date";
        }
        else if (startDate != "" && endDate != "") {
            var d = new Date();
            var currentYear = d.getFullYear();
            var yearDiff_StartDate = currentYear - checkStartDate_Year;
            var yearDiff_EndDate = currentYear - checkEndDate_Year;

            if (yearDiff_StartDate > 1 && yearDiff_EndDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (yearDiff_StartDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (yearDiff_EndDate > 1) {
                errorMsg = "Data for past one year can only be filtered";
            }
            else if (dateDiff < 0) {
                errorMsg = "Please select to date greater than from date";
            }
            else if (dateDiff > 7) {
                errorMsg = "Please select from date and to date within 7 days range";
            }
        }

        return { errorMsg: errorMsg, checkStartDate: checkStartDate, checkEndDate: checkEndDate, dateDiff: dateDiff, startDate: startDate, endDate: endDate };
    }

    self.DrawEmployeesCoreNonCoreData = function (userId, startDate, endDate) {
        var teamId = (self.selectedTeamId() == undefined || self.selectedTeamId() == null) ? 0 : self.selectedTeamId();
        var url = '/api/GetEmployeesCoreNonCoreDataLM?departmentId=' + sessionStorage.getItem("DepartmentId") + '&userId=' + userId + '&startDate=' + startDate + '&endDate=' + endDate + '&teamId=' + teamId;
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: true,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {
                        self.coreNonCoreDashboard(result);
                    }
                    else {
                        if (self.coreNonCoreDashboard().length > 0)
                            self.coreNonCoreDashboard.removeAll();
                    }
                }
                else {
                    if (self.coreNonCoreDashboard().length > 0)
                        self.coreNonCoreDashboard.removeAll();
                }
            },
            error: function (returnVal) {
            }
        });

    }

    self.DrawHorizontalBarChart = function (result) {
        var chart = c3.generate({
            bindto: '#EmployeesCoreNonCoreDataChart',
            size: {
                width: 400,
                height: 300
            },
            padding: {
                top: 20,
                right: 20
            },
            data: {
                json: result,
                keys: {
                    x: 'Name',
                    value: ['Core', 'NonCore'],
                },
                type: 'bar',
                labels: true
            },
            bar: {
                space: 0.25
            },
            //bar: {
            //    space: 0.50,
            //    width: {
            //        ratio: 1.5 // this makes bar width 50% of length between ticks
            //    }
            //},
            axis: {
                rotated: true,
                y: {
                    tick: {
                        format: d3.format(".2f") // ADD
                    }
                },
                x: {
                    type: 'categorized'
                }
            },
            tooltip: {
                grouped: false
            }
        });
    }
    
    self.DrawBarChart = function (result) {

        var chart = c3.generate({
            bindto: '#ProductiveChartContainer',
            size: {
                width: 400,
                height: 300
            },
            padding: {
                top: 20,
                right: 20
            },
            data: {
                json: result,
                keys: {
                    x: 'Name',
                    value: ['Core', 'NonCore'],
                },
                type: 'bar',
                labels: {
                    show: true,
                    format: function (value) {
                        return d3.format(",.2f")(value);
                    }
                }
            },
            bar: {
                space: 0.25,
            
            },
            axis: {
                y: {
                    label: {
                        text: 'Time',
                        position: 'outer-middle'
                    },
                    tick: {
                        format: d3.format(".2f") // ADD
                    }
                },
                x: {
                    type: 'categorized'
                }
            },
            tooltip: {
                format: {
                    value: function (value, ratio, id) {
                        if (id == 'Core') { return result[0].TotalTimeProductive; }
                        else { return result[0].TotalTimeNonProductive; }
                    }
                }
            }
        });
    }
    
    self.DrawDonutChart = function (result) {
        var data = {};
        var activity = [];
        result.forEach(function (e) {
            activity.push(e.Name);
            data[e.Name] = e.Hours;
        })

        var chart = c3.generate({
            bindto: '#CoreNonCoreChart',
            size: {
                width: 400,
                height: 300
            },
            padding: {
                top: 20,
                right: 20
            },
            data: {
                json: [data],
                keys: {
                    value: activity,
                },
                type: 'donut'
            },
            donut: {
                label: {
                    format: function (value) {
                        return d3.format(",.2f")(value);
                    }
                }
            },
            tooltip: {
                format: {
                    value: function (value, ratio, id) {
                        if (id != "") {
                            var r = jQuery.grep(result, function (item) { return id == item.Name; });
                            return r[0].DisplayName;
                        }
                    }
                }
            }
        });
    }
    
    // Teams - START
    self.getAllTeams = function () {
        var result = [];
        var url = '/api/GetAllTeams?DepartmentId=' + sessionStorage.getItem("DepartmentId");
        var result = null;
        $.ajax({
            url: url,
            type: "GET",
            dataType: "json",
            async: false,
            success: function (returnVal) {
                result = returnVal;
                if (result != null) {
                    if (result.length > 0) {                      
                        var selectAllItem = { Id: 0, Name: 'All', DepartmentId: parseInt(sessionStorage.getItem("DepartmentId")) };
                        self.Teams(result);
                        self.Teams.push(selectAllItem);
                        if (sessionStorage.getItem("TeamId") != null && sessionStorage.getItem("TeamId") != 0) {
                            self.selectedTeamId(parseInt(sessionStorage.getItem("TeamId")));
                        }
                    }
                    else {
                        if (self.Teams().length > 0)
                            self.Teams.removeAll();
                    }
                }
            },
            error: function (returnVal) {
            }
        });
        
    }
    // Teams - END

};

function GetDefaultDateAndDateFormat() {
    try {
        var UserTimeZoneDate = sessionStorage.getItem("UserTimeZoneDate");
        var arrDate = UserTimeZoneDate.split('/');
        var date = new Date(arrDate[2], arrDate[0] - 1, arrDate[1]);

        var monthFullName = new Array(12);
        monthFullName[0] = "January"; monthFullName[1] = "February"; monthFullName[2] = "March"; monthFullName[3] = "April"; monthFullName[4] = "May"; monthFullName[5] = "June"; monthFullName[6] = "July"; monthFullName[7] = "August"; monthFullName[8] = "September"; monthFullName[9] = "October"; monthFullName[10] = "November"; monthFullName[11] = "December";
        var monthName = new Array(12);
        monthName[0] = "Jan"; monthName[1] = "Feb"; monthName[2] = "Mar"; monthName[3] = "Apr"; monthName[4] = "May"; monthName[5] = "Jun"; monthName[6] = "Jul"; monthName[7] = "Aug"; monthName[8] = "Sep"; monthName[9] = "Oct"; monthName[10] = "Nov"; monthName[11] = "Dec";
        var dayName = new Array(7);
        dayName[1] = "Mon"; dayName[2] = "Tues"; dayName[3] = "Wed"; dayName[4] = "Thurs"; dayName[5] = "Fri"; dayName[6] = "Sat"; dayName[7] = "Sun";
        var dayFullName = new Array(7);
        dayFullName[1] = "Monday"; dayFullName[2] = "Tuesday"; dayFullName[3] = "Wednesday"; dayFullName[4] = "Thursday"; dayFullName[5] = "Friday"; dayFullName[6] = "Saturday"; dayFullName[7] = "Sunday";
        var dateformatString = sessionStorage.getItem("DateFormat");
        var separator;
        if (dateformatString.indexOf('/') > -1) {
            separator = '/';
        } else if (dateformatString.indexOf('-') > -1) {
            separator = '-';
        } else if (dateformatString.indexOf(' ') > -1) {
            separator = ' ';
        } else if (dateformatString.indexOf('.') > -1) {
            separator = '.';
        } else if (dateformatString.indexOf('|') > -1) {
            separator = '|';
        } else {
            separator = 'undefined'
        }


        var displayDateFormat;
        var arrDateFormat = dateformatString.split(separator);
        var datePickerFormat;
        var datePickerTodayDate;
        var todayDateVal;
        if (separator != 'undefined') {
            $.each(arrDateFormat, function () {

                switch (this.toString()) {
                    case 'd':
                    case 'd,':
                        {
                            datePickerFormat = 'd';
                            todayDateVal = date.getDate();
                            break;
                        }
                    case 'dd':
                    case 'dd,':
                        {
                            datePickerFormat = 'dd';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'D':
                    case 'D,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'ddd':
                    case 'ddd,':
                    case 'DDD':
                    case 'DDD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'dddd':
                    case 'dddd,':
                    case 'DDDD':
                    case 'DDDD,':
                        {
                            datePickerFormat = 'DD';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate();
                            break;
                        }
                    case 'DD':
                    case 'DD,':
                        {
                            datePickerFormat = 'D';
                            todayDateVal = date.getDate() < 10 ? "0" + date.getDate() : date.getDate()
                            break;
                        }
                    case 'm':
                    case 'm,':
                    case 'M':
                    case 'M,':
                        {
                            datePickerFormat = 'm';
                            todayDateVal = date.getMonth() + 1;
                            break;
                        }
                    case 'mm':
                    case 'mm,':
                    case 'MM':
                    case 'MM,':
                        {
                            datePickerFormat = 'mm';
                            todayDateVal = (date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1);
                            break;
                        }
                    case 'MMM':
                    case 'MMM,':
                    case 'mmm':
                    case 'mmm,':
                        {
                            datePickerFormat = 'M';
                            todayDateVal = monthName[date.getMonth()];
                            break;
                        }
                    case 'MMMM':
                    case 'MMMM,':
                    case 'mmmm':
                    case 'mmmm,':
                        {
                            datePickerFormat = 'MM';
                            todayDateVal = monthFullName[date.getMonth()];
                            break;
                        }
                    case 'yy':
                    case 'yy,':
                    case 'YY':
                    case 'YY,':
                        {
                            datePickerFormat = 'yy';
                            todayDateVal = date.getFullYear() - 2000;
                            break;
                        }
                    case 'yyyy':
                    case 'yyyy,':
                    case 'YYYYY':
                    case 'YYYYY,':
                        {
                            datePickerFormat = 'yyyy';
                            todayDateVal = date.getFullYear();
                            break;
                        }

                }

                if (displayDateFormat == undefined) {
                    displayDateFormat = datePickerFormat;
                    datePickerTodayDate = todayDateVal;
                }
                else {
                    displayDateFormat += separator + datePickerFormat;
                    datePickerTodayDate += separator + todayDateVal;
                }
            });
            //for not supported date formats
            switch (dateformatString) {

                case "dddd, dd MMMM, yyyy":
                    {
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        break;
                    }
                case "d/M/yyyy":
                case "d-M-yyyy":
                case "d M yyyy":
                case "d.M.yyyy":
                    {
                        displayDateFormat = "m" + separator + "d" + separator + "yyyy";
                        datePickerTodayDate = (date.getMonth() + 1) + separator + (date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
                case "dd/MM/yy":
                case "dd-MM-yy":
                case "dd MM yy":
                case "dd.MM.yy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear() - 2000);
                        break;
                    }
                case "dd/MM/yyyy":
                case "dd-MM-yyyy":
                case "dd MM yyyy":
                case "dd.MM.yyyy":
                    {
                        displayDateFormat = "mm" + separator + "dd" + separator + "yyyy";
                        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + separator + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + separator + (date.getFullYear());
                        break;
                    }
            }
        }
        else {

            displayDateFormat = "mm/dd/yyyy";
            datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
        }
    }
    catch (ex) {
        displayDateFormat = "mm/dd/yyyy";
        datePickerTodayDate = ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "/" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate()) + "/" + (date.getFullYear());
    }
    return (datePickerTodayDate + "$" + displayDateFormat);
}