﻿using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.DataModels;
using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace Capita.Core.Filters
{
    public class LogExceptionAttribute : ExceptionHandler
    {
        private readonly ILogger logger;
        private readonly IEmailService emailService;

        //private readonly IUser userService;
        public LogExceptionAttribute()
            : this((ILogger)GlobalConfiguration.Configuration.DependencyResolver.GetService(typeof(ILogger)), (IEmailService)GlobalConfiguration.Configuration.DependencyResolver.GetService(typeof(IEmailService)))
        {

        }

        public LogExceptionAttribute(ILogger logger, IEmailService emailService)
        {
            this.logger = logger;
            this.emailService = emailService;
        }

        public override void Handle(ExceptionHandlerContext context)
        {

            try
            {
                var empInfo = HttpContext.Current.User.Identity.Name;
                int logged = logger.Log(context.Exception, empInfo);

                if (Settings.AppSetting.IsExceptionMailRequired)
                {
                    bool sended = emailService.SendEmail(Settings.AppSetting.ExceptionDL, string.Empty, context.Exception.Message, context.Exception.StackTrace);
                }

                context.Result = new TextPlainErrorResult
                {
                    Request = context.ExceptionContext.Request,
                    Content = logged.ToString() + ":" + context.Exception.Message
                };
            }
            catch (Exception ex)
            {
                LogInTextFile("Error - " + DateTimeHelper.Now.ToString("dd MMM yyyy hh:mm:ss tt") + " - " + ex.Message + " - " + ex.StackTrace);
            }
        }

        private void LogInTextFile(string info)
        {
            try
            {
                var dir = System.Web.HttpContext.Current.Server.MapPath("~\\LogFiles");
                string fileName = dir + "\\" + DateTimeHelper.Now.ToString("ddMMMyyyy") + ".log";

                string logInfo = "Exception : " + DateTimeHelper.Now.ToString(Settings.AppSetting.DisplayDateFormat) + " : " + info;

                FileInfo fi = new FileInfo(fileName);
                if (!fi.Exists)
                {
                    //Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fi.FullName))
                    {
                        sw.WriteLine(logInfo);
                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fi.FullName))
                    {
                        sw.WriteLine(logInfo);
                    }
                }
            }
            catch
            { }

        }



        private class TextPlainErrorResult : IHttpActionResult
        {
            public HttpRequestMessage Request { get; set; }

            public string Content { get; set; }

            public Task<HttpResponseMessage> ExecuteAsync(CancellationToken cancellationToken)
            {
                HttpResponseMessage response =
                                 new HttpResponseMessage(HttpStatusCode.InternalServerError)
                                 {
                                     Content = new StringContent(Content),
                                     RequestMessage = Request
                                 };
                return Task.FromResult(response);
            }
        }
    }

}