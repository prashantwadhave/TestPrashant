using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Data;
using Capita.Core.Repositories;
using Capita.Core.Services;
using Capita.Core.Services.Services;
using Microsoft.Practices.Unity;
using System.Web.Http;
using Unity.WebApi;

namespace Capita.Core
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            container.RegisterType<IUnitOfWork, UnitOfWork>(new PerResolveLifetimeManager());
            container.RegisterType<IDataContext, DataContext>();
            container.RegisterType<ILogger, ExceptionLoggerService>();
            container.RegisterType<IAuxCode, AuxCodeService>();
            container.RegisterType<IDepartment, DepartmentService>();
            container.RegisterType<IRole, RoleService>();
            container.RegisterType<IUser, UserService>();
            container.RegisterType<INonCoreActivity, NonCoreActivityService>();
            container.RegisterType<INavigation, NavigationService>();
            container.RegisterType<IDashboard, DashboardService>();
            container.RegisterType<ICommon, CommonService>();
            container.RegisterType<ICoreActivity, CoreActivityService>();
            container.RegisterType<IActivity, ActivityService>();
            container.RegisterType<ICalls, CallsService>();
            container.RegisterType<IReports, ReportService>();
            container.RegisterType<IMappingUserDepartment, UserDepartmentService>();
            container.RegisterType<IWebChat, WebChatService>();
            container.RegisterType<IOutbondCall, OutboundCallService>();
            container.RegisterType<ITeam, TeamService>();
            container.RegisterType<IEmailService, EmailService>();

            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}