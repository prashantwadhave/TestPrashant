﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Utility
{
    public class ExportToExcel
    {
        public void ExportDataTableToExcel(DataTable dtExport, FileInfo newFile, string sheetName)
        {

            using (ExcelPackage pck = new ExcelPackage(newFile))
            {
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add(sheetName);
                ws.Cells["A1"].LoadFromDataTable(dtExport, true);
                ws.Row(1).Style.Font.Bold = true;
                var dPos = new List<int>();
                for (var i = 0; i < dtExport.Columns.Count; i++)
                {
                    if (dtExport.Columns[i].DataType.Name.Equals("DateTime")) dPos.Add(i);
                }
                foreach (var pos in dPos)
                {
                    ws.Column(pos + 1).Style.Numberformat.Format = "dd-mm-yyyy hh:mm:ss AM/PM";
                }

                ws.Cells.AutoFitColumns();
                pck.Save();
            }

        }
    }
}
