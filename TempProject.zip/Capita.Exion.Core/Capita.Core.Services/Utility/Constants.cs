﻿namespace Capita.Core.Services.Utility
{
    public static class Settings
    {
        public static class Constants
        {
            public const string NonCoreActivity = "NonCoreActivity";

            public const string CoreActivity = "CoreActivity";

            public const int IdleActivityId = 1;            
        }        
    }
}
