﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services.Services
{
    public class UserDepartmentService : IMappingUserDepartment
    {
        private readonly IUnitOfWork _uow = null;
        private IDataContext _dataContext = null;
        private IUser _UserService = null;
        private IGenericRepository<MappingUserDepartment> _mappingUserDepartmentRepository = null;
        private IGenericRepository<MstRole> _RoleRepository = null;
        private IGenericRepository<MstDepartment> _DepartmentRepository = null;
        private IGenericRepository<MstTeam> _TeamRepository = null;
        private IGenericRepository<UserPrimaryDetails> _UserRepository = null;

        public UserDepartmentService(IUnitOfWork uow, IUser userService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _mappingUserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
        }

        public IEnumerable<MappingUserDepartment> GetAllMappingUserDepartment()
        {
            IEnumerable<MappingUserDepartment> lstMappingUserDepartment = _mappingUserDepartmentRepository.Get();
            return lstMappingUserDepartment;
        }

        public IEnumerable<DisplayUserDepartmentRole> GetUserDepartmentRolesByUserId(int userId, int departmentId)
        {
            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = userId.ToString()},
               new spParameter() { Name = "@DepartmentId",  Value = departmentId.ToString()}
            };

            IEnumerable<DisplayUserDepartmentRole> lstUserDepartment = _uow.GetRepository<DisplayUserDepartmentRole>().GetSP("GetUserDepartmentRoles", spParameters);
            return lstUserDepartment;
        }

        public IEnumerable<DisplayUserDepartmentRole> GetUserDepartmentRolesByUserIdForAdmin(int userId)
        {
            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = userId.ToString()}
            };

            IEnumerable<DisplayUserDepartmentRole> lstUserDepartment = _uow.GetRepository<DisplayUserDepartmentRole>().GetSP("GetUserDepartmentRolesForAdmin", spParameters);
            return lstUserDepartment;
        }

        public IEnumerable<DisplayUserDepartmentRole> AddMappingUserDepartment(UserDepartmentRoles userDepartmentRoles, string lanId)
        {
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            IEnumerable<DisplayUserDepartmentRole> lstUserDepartmentRole = null;
            UserPrimaryDetails loggedInUserDetail = _UserService.GetUserDetailsFromLanId(lanId);
            DateTime currentDate = DateTimeHelper.Now;
            _TeamRepository = _uow.GetRepository<MstTeam>();
            MappingUserDepartment mappingUserDepartment = null;

            bool isUserAlreadyExist = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userDepartmentRoles.UserId && x.TeamId == userDepartmentRoles.TeamId && x.DepartmentId == userDepartmentRoles.DepartmentId && userDepartmentRoles.RoleIds.Contains(x.RoleId)).Any();

            if (!isUserAlreadyExist)
            {
                //// Check department is adding 1st time or not, if it is 1st time then make is as default
                UserPrimaryDetails userDetail = _UserService.GetUserById(userDepartmentRoles.UserId);
                
                bool anyDefaultDepartmentExistForUser = userDetail.TeamId != 0 ? true : false;
                userDepartmentRoles.IsDefault = _TeamRepository.GetByID(userDepartmentRoles.TeamId).DepartmentId == userDetail.DepartmentId ? true : false;

                if (userDepartmentRoles.IsDefault || !anyDefaultDepartmentExistForUser)
                {
                    userDetail.TeamId = userDepartmentRoles.TeamId;
                    _UserRepository.Update(userDetail);
                }

                foreach (int role in userDepartmentRoles.RoleIds)
                {
                    mappingUserDepartment = new MappingUserDepartment() { CreatedBy = loggedInUserDetail.Id, CreatedDate = currentDate, DepartmentId = userDepartmentRoles.DepartmentId, TeamId = userDepartmentRoles.TeamId, ModifiedBy = loggedInUserDetail.Id, UserId = userDepartmentRoles.UserId, ModifiedDate = currentDate };
                    mappingUserDepartment.RoleId = role;
                    _mappingUserDepartmentRepository.Add(mappingUserDepartment);
                }

                if (_uow.Commit())
                    lstUserDepartmentRole = GetUserDepartmentRolesByUserId(userDepartmentRoles.UserId, userDepartmentRoles.DepartmentId);
            }

            return lstUserDepartmentRole;
        }

        public IEnumerable<DisplayUserDepartmentRole> AddMappingUserDepartmentForAdmin(UserDepartmentRoles userDepartmentRoles, string lanId)
        {
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            IEnumerable<DisplayUserDepartmentRole> lstUserDepartmentRole = null;
            UserPrimaryDetails loggedInUserDetail = _UserService.GetUserDetailsFromLanId(lanId);
            DateTime currentDate = DateTimeHelper.Now;

            MappingUserDepartment mappingUserDepartment = null;

            bool isUserAlreadyExist = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userDepartmentRoles.UserId  && x.DepartmentId == userDepartmentRoles.DepartmentId && userDepartmentRoles.RoleIds.Contains(x.RoleId)).Any();

            if (!isUserAlreadyExist)
            {
                //// Check department is adding 1st time or not, if it is 1st time then make is as default
                UserPrimaryDetails userDetail = _UserService.GetUserById(userDepartmentRoles.UserId);
                bool anyDefaultDepartmentExistForUser = userDetail.DepartmentId != 0 ? true : false;

                if (userDepartmentRoles.IsDefault || !anyDefaultDepartmentExistForUser)
                {
                    userDetail.DepartmentId = userDepartmentRoles.DepartmentId;
                    _UserRepository.Update(userDetail);
                }

                foreach (int role in userDepartmentRoles.RoleIds)
                {
                    mappingUserDepartment = new MappingUserDepartment() { CreatedBy = loggedInUserDetail.Id, CreatedDate = currentDate, DepartmentId = userDepartmentRoles.DepartmentId, ModifiedBy = loggedInUserDetail.Id, UserId = userDepartmentRoles.UserId, ModifiedDate = currentDate };
                    mappingUserDepartment.RoleId = role;
                    _mappingUserDepartmentRepository.Add(mappingUserDepartment);
                }

                if (_uow.Commit())
                    lstUserDepartmentRole = GetUserDepartmentRolesByUserIdForAdmin(userDepartmentRoles.UserId);
            }

            return lstUserDepartmentRole;
        }


        public IEnumerable<DisplayUserDepartmentRole> DeleteMappingUserDepartmentById(int id, int userId)
        {
            IEnumerable<DisplayUserDepartmentRole> lstUserDepartmentRole = null;

            UserPrimaryDetails userDetail = _UserService.GetUserById(userId);
            var departments = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userId).Select(x => new { DepartmentId = x.DepartmentId, Id = x.Id }).ToList();
            int deletingDepartmentId = departments.Where(x => x.Id == id).Select(x => x.DepartmentId).FirstOrDefault();

            if (userDetail.DepartmentId == deletingDepartmentId)
            {
                if (departments.Where(x => x.DepartmentId == deletingDepartmentId).Count() > 1)
                {
                    _mappingUserDepartmentRepository.Delete(id);

                    if (_uow.Commit())
                        lstUserDepartmentRole = GetUserDepartmentRolesByUserId(userId, deletingDepartmentId);
                }
            }
            else
            {
                _mappingUserDepartmentRepository.Delete(id);

                if (_uow.Commit())
                    lstUserDepartmentRole = GetUserDepartmentRolesByUserId(userId, deletingDepartmentId);
            }




            return lstUserDepartmentRole;
        }
        public IEnumerable<DisplayUserDepartmentRole> DeleteMappingUserDepartmentByIdForAdmin(int id, int userId)
        {
            IEnumerable<DisplayUserDepartmentRole> lstUserDepartmentRole = null;

            UserPrimaryDetails userDetail = _UserService.GetUserById(userId);
            var departments = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userId).Select(x => new { DepartmentId = x.DepartmentId, Id = x.Id }).ToList();
            int deletingDepartmentId = departments.Where(x => x.Id == id).Select(x => x.DepartmentId).FirstOrDefault();

            if (userDetail.DepartmentId == deletingDepartmentId)
            {
                if (departments.Where(x => x.DepartmentId == deletingDepartmentId).Count() > 1)
                {
                    _mappingUserDepartmentRepository.Delete(id);

                    if (_uow.Commit())
                        lstUserDepartmentRole = GetUserDepartmentRolesByUserIdForAdmin(userId);
                }
            }
            else
            {
                _mappingUserDepartmentRepository.Delete(id);

                if (_uow.Commit())
                    lstUserDepartmentRole = GetUserDepartmentRolesByUserIdForAdmin(userId);
            }




            return lstUserDepartmentRole;
        }
        // chnages as per the department
        public MastersData GetAllUserRoleDepartment(string lanId, int departmentId)
        {
            MastersData masterData = new MastersData();
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _RoleRepository = _uow.GetRepository<MstRole>();
            _DepartmentRepository = _uow.GetRepository<MstDepartment>();
            _TeamRepository = _uow.GetRepository<MstTeam>();


            int userid = _UserService.GetUserIdFromLanId(lanId);

            //masterData.Users = _UserRepository.FindBy(x => x.IsActive && x.DepartmentId == departmentId).Select(x => new IdValuePair() { Id = x.Id, Value = x.FirstName + " " + x.LastName }).ToList();

            masterData.Users = (from u in _UserRepository.Get()
                                join d in _mappingUserDepartmentRepository.Get() on  u.Id equals d.UserId
                                into ResultEmp from output in ResultEmp.DefaultIfEmpty()
                                where (output.DepartmentId == departmentId || u.DepartmentId==departmentId) && u.IsActive==true
                                select new IdValuePair
                                {
                                    Id = u.Id,
                                    Value = u.FirstName + " " + u.LastName
                                }).Distinct().ToList();


            var departmentRolesForLoggedinUser = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userid && x.DepartmentId == departmentId).Select(x => new { DepartmentId = x.DepartmentId, RoleId = x.RoleId }).ToList();

            List<int> roles = departmentRolesForLoggedinUser.Select(x => x.RoleId).Distinct().ToList();

            if (roles.Contains(Settings.Constants.AdminRoleId))
            {
                masterData.Departments = _DepartmentRepository.FindBy(x => x.IsActive && departmentId == x.Id).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
                masterData.Teams = _TeamRepository.FindBy(x => x.IsActive && x.DepartmentId == departmentId).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
                masterData.Roles = _RoleRepository.FindBy(x => x.Id != Settings.Constants.AdminRoleId).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
            }
            else
            {
                masterData.Roles = _RoleRepository.FindBy(x => x.Id != Settings.Constants.AdminRoleId).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
                List<int> departments = departmentRolesForLoggedinUser.Select(y => y.DepartmentId).Distinct().ToList();
                masterData.Departments = _DepartmentRepository.FindBy(x => departments.Contains(x.Id)).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
                masterData.Teams = _TeamRepository.FindBy(x => x.IsActive && x.DepartmentId == departmentId).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
            }

            return masterData;
        }
        // method is used for add admin page
        public MastersData GetAllUserRoleDepartment(string lanId)
        {
            MastersData masterData = new MastersData();
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _RoleRepository = _uow.GetRepository<MstRole>();
            _DepartmentRepository = _uow.GetRepository<MstDepartment>();
            _TeamRepository = _uow.GetRepository<MstTeam>();


            int userid = _UserService.GetUserIdFromLanId(lanId);

            masterData.Users = _UserRepository.FindBy(x => x.IsActive ).Select(x => new IdValuePair() { Id = x.Id, Value = x.FirstName + " " + x.LastName }).ToList();

            var departmentRolesForLoggedinUser = _mappingUserDepartmentRepository.FindBy(x => x.UserId == userid ).Select(x => new { DepartmentId = x.DepartmentId, RoleId = x.RoleId }).ToList();

            List<int> roles = departmentRolesForLoggedinUser.Select(x => x.RoleId).Distinct().ToList();

            if (roles.Contains(Settings.Constants.AdminRoleId))
            {
                masterData.Departments = _DepartmentRepository.FindBy(x => x.IsActive ).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
               
                masterData.Roles = _RoleRepository.FindBy(x => x.Id == Settings.Constants.AdminRoleId).Select(x => new IdValuePair() { Id = x.Id, Value = x.Name }).ToList();
            }
           
            return masterData;
        }
    }
}
