﻿namespace Capita.Core.Services.Services
{
    using Capita.Core.Contracts;
    using Capita.Core.Models.DataModels;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class RoleService : IRole
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IGenericRepository<MstRole> _RoleRepository = null;

        private IGenericRepository<MappingRoleNavigation> _MappingRoleNavigation = null;

        public RoleService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _RoleRepository = _uow.GetRepository<MstRole>();
        }

        public IEnumerable<MstRole> GetAllRoles(int departmentId)
        {
            _MappingRoleNavigation = _uow.GetRepository<MappingRoleNavigation>();

            List<int> lstRoleIds = _MappingRoleNavigation.Get().Select(x => x.RoleId).Distinct().ToList();
            IEnumerable<MstRole> lstRoles = _RoleRepository.FindBy(x=> lstRoleIds.Contains(x.Id)).ToList();
            return lstRoles;
        }
        
        public MstRole GetRoleById(int id)
        {
            MstRole lstRoles = _RoleRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return lstRoles;
        }

        public bool AddRole(MstRole role)
        {
            role.ModifiedDate = role.CreatedDate = DateTimeHelper.Now;            
            _RoleRepository.Add(role);
            return this.CommintToDB();
        }

        public bool UpdateRole(MstRole role)
        {
            bool status = false;
            MstRole existingRole = this.GetRoleById(role.Id);

            if (existingRole != null)
            {
                existingRole.Name = role.Name;
                existingRole.ModifiedBy = role.ModifiedBy;
                existingRole.ModifiedDate = DateTimeHelper.Now;

                _RoleRepository.Update(existingRole);
                status = this.CommintToDB();
            }

            return status;
        }

        public bool DeleteRoleById(int id)
        {
            _RoleRepository.Delete(id);
            return this.CommintToDB();
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
