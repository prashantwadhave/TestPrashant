﻿using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class CallsService : ICalls
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private ICoreActivity _CoreService = null;

        private IGenericRepository<UserPrimaryDetails> _UserRepository = null;

        private IGenericRepository<CoreActivityJourney> _CARepository = null;

        private IGenericRepository<Calls> _CallsRepository = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;

        public CallsService(IUser userService, IUnitOfWork uow, ICoreActivity coreService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _CoreService = coreService;
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _CallsRepository = _uow.GetRepository<Calls>();
            _CARepository = _uow.GetRepository<CoreActivityJourney>();
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
        }
        public List<CallsReport> GetCallList(int departmentId, DateTime startDate, DateTime endDate, string lanId)
        {

            string timeZone = _UserRepository.FindBy(x => x.LanId == lanId).FirstOrDefault().TimeZone;

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.MonthDateFormat) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.MonthDateFormat) }

            };
            IEnumerable<CallsReport> result = _uow.GetRepository<CallsReport>().GetSP("SpGetCallList", spParameters);
            if (result != null)
            {
                result = result.Select(x => new CallsReport()
                {
                    AgentName = x.AgentName,
                    DepartmentId = x.DepartmentId,
                    StartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone),
                    EndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone) : x.EndTime,
                    StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                    StrEndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.EndTime.ToString(),
                    Duration = x.Duration,
                    Scheme = x.Scheme,
                    CallCode = x.CallCode,
                    CallCodeResolution = x.CallCodeResolution
                });
            }

            return result.ToList();
        }

        public int AddCallActivity(Calls callActivity, int activeNonCoreActivityId, string lanId)
        {
            int activityId = 0;
            DateTime currentTime = DateTimeHelper.Now;

            CoreActivityJourney callCoreActivity = new CoreActivityJourney();

            callCoreActivity.ActivityType = Settings.Constants.Call;
            callCoreActivity.UserId = _UserService.GetUserIdFromLanId(lanId);
            callCoreActivity.DepartmentId = callActivity.DepartmentId;
            callCoreActivity.TeamId = callActivity.TeamId;
            callCoreActivity.StartTime = currentTime;
            callCoreActivity.EndTime = null;
            callCoreActivity.Param1 = string.IsNullOrEmpty(callActivity.Scheme) ? string.Empty : callActivity.Scheme;
            callCoreActivity.Param2 = string.IsNullOrEmpty(callActivity.CallCode) ? string.Empty : callActivity.CallCode;
            callCoreActivity.Param3 = string.IsNullOrEmpty(callActivity.CallCodeResolution) ? string.Empty : callActivity.CallCodeResolution;
            _CARepository.Add(callCoreActivity);            

            NonCoreActivityJourney idleNonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));

            if (idleNonCoreActivity != null && !idleNonCoreActivity.EndTime.HasValue)
            {
                idleNonCoreActivity.Comment = string.Empty;
                idleNonCoreActivity.EndTime = currentTime;
                idleNonCoreActivity.TeamId = callActivity.TeamId;
                idleNonCoreActivity.Duration = Convert.ToInt64(currentTime.Subtract(idleNonCoreActivity.StartTime).TotalSeconds);
                _NCARepository.Update(idleNonCoreActivity);
            }

            //// Update Current Activity
            _UserService.AddOrUpdateCurrentActivity(callCoreActivity.UserId, Settings.Constants.CoreActivity, 0, callCoreActivity.DepartmentId, Settings.Constants.Call, callActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme

            if (this.CommintToDB())
                activityId = callCoreActivity.Id;

            return activityId;
        }

        public int UpdateCallActivity(Calls callActivityJourney,bool isCoreActivtyStarted, bool isWebChatActivityStarted)
        {
            int nonCoreActivityId = 0;
            CoreActivityJourney callCoreActivity = _CARepository.GetByID(callActivityJourney.Id);

            if (callCoreActivity != null)
            {
                callCoreActivity.Param1 = callActivityJourney.Scheme;
                callCoreActivity.Param2 = callActivityJourney.CallCode;
                callCoreActivity.Param3 = callActivityJourney.CallCodeResolution;
                callCoreActivity.TeamId = callActivityJourney.TeamId;

                DateTime currentTime = DateTimeHelper.Now;
                callCoreActivity.EndTime = currentTime;
                callCoreActivity.Duration = Convert.ToInt64((currentTime.Subtract(callCoreActivity.StartTime)).TotalSeconds);

                NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = callCoreActivity.DepartmentId,TeamId=callCoreActivity.TeamId, StartTime = currentTime, EndTime = null, UserId = callCoreActivity.UserId };

                if (!isCoreActivtyStarted && !isWebChatActivityStarted)
                {
                    ////Add idle entry 
                    _NCARepository.Add(idleNonCoreActivity);                    

                    ////Update current activity            
                    _UserService.AddOrUpdateCurrentActivity(callCoreActivity.UserId, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, callCoreActivity.DepartmentId, string.Empty, callActivityJourney.TeamId);
                }
                else
                {
                    if (isWebChatActivityStarted)
                    {
                        _UserService.AddOrUpdateCurrentActivity(callCoreActivity.UserId, Settings.Constants.CoreActivity, 0, callCoreActivity.DepartmentId, Settings.Constants.WebChat, callActivityJourney.TeamId);////Aux code 0 for core activity, Param1 is scheme                        
                    }
                    else
                    {
                        CoreActivityJourney currentActivity = _CoreService.GetCurrentActivity(callCoreActivity.UserId, callCoreActivity.DepartmentId, Settings.Constants.CoreActivity);

                        //// Update Current Activity
                        string currentActivityName = string.IsNullOrWhiteSpace(currentActivity.Param3) == false ? currentActivity.Param1 + '-' + currentActivity.Param3 : currentActivity.Param1;

                        if (currentActivity != null)
                            _UserService.AddOrUpdateCurrentActivity(callCoreActivity.UserId, Settings.Constants.CoreActivity, 0, callCoreActivity.DepartmentId, currentActivityName, callActivityJourney.TeamId);////Aux code 0 for core activity, Param1 is scheme
                        else
                            _UserService.AddOrUpdateCurrentActivity(callCoreActivity.UserId, Settings.Constants.CoreActivity, 0, callCoreActivity.DepartmentId, string.Empty, callActivityJourney.TeamId);////Aux code 0 for core activity, Param1 is scheme
                    }
                }

                _CARepository.Update(callCoreActivity);
                this.CommintToDB();
                nonCoreActivityId = idleNonCoreActivity.Id;
            }

            return nonCoreActivityId;
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
