﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services.Services
{
    public class DepartmentService : IDepartment
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private IGenericRepository<MstDepartment> _DepartmentRepository = null;

        private IGenericRepository<MappingUserDepartment> _MappingUserDepartmentRepository = null;

        private IGenericRepository<MappingRoleNavigation> _MappingRoleNavigationRepository = null;

        private IGenericRepository<MappingAuxCodeDepartment> _MappingAuxCodeDepartmentRepository = null;

        public DepartmentService(IUnitOfWork uow, IUser userService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _DepartmentRepository = _uow.GetRepository<MstDepartment>();
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
            _MappingRoleNavigationRepository = _uow.GetRepository<MappingRoleNavigation>();
        }

        private int GetMaxId()
        {
            return _DepartmentRepository.Get().Max(x => x.Id) + 1;
        }

        public IEnumerable<MstDepartment> GetAllDepartments(string lanId)
        {
            int userId = _UserService.GetUserIdFromLanId(lanId);
            _MappingUserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            List<int> lstDepartmentIds = _MappingUserDepartmentRepository.FindBy(x => x.UserId == userId).Select(x => x.DepartmentId).Distinct().ToList();
            IEnumerable<MstDepartment> lstDepartments = _DepartmentRepository.FindBy(x => lstDepartmentIds.Contains(x.Id)).ToList();
            return lstDepartments;
        }

        public IEnumerable<MstDepartment> GetAllDepartmentsInApp()
        {
            var lstDepartments = _DepartmentRepository.Get().OrderByDescending(x => x.CreatedDate);
            return lstDepartments;
        }

        public MstDepartment GetDepartmentById(int id)
        {
            MstDepartment lstDepartments = _DepartmentRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return lstDepartments;
        }

        public bool AddDepartment(MstDepartment department, UserPrimaryDetails createdBy)
        {
            department.Id = this.GetMaxId();
            department.IsActive = true;
            department.CreatedBy = department.ModifiedBy = createdBy.Id;
            department.CreatedDate = department.ModifiedDate = DateTimeHelper.Now;
            _DepartmentRepository.Add(department);

            List<MappingRoleNavigation> lstMappingRoleNavigation = this.GetDefaultRoleNavigationDetails(department, createdBy);

            foreach (MappingRoleNavigation roleNav in lstMappingRoleNavigation)
            {
                _MappingRoleNavigationRepository.Add(roleNav);
            }

            List<MappingAuxCodeDepartment> auxCodes = new List<MappingAuxCodeDepartment>()
            {
                new MappingAuxCodeDepartment(){ AuxCodeId = Settings.Constants.BreakAuxCodeId, DepartmentId = department.Id, IsVisibile = true },
                new MappingAuxCodeDepartment(){ AuxCodeId = Settings.Constants.LunchAuxCodeId, DepartmentId = department.Id, IsVisibile = true },
                new MappingAuxCodeDepartment(){ AuxCodeId = Settings.Constants.DiscussionAuxCodeId, DepartmentId = department.Id, IsVisibile = true }
            };

            foreach (MappingAuxCodeDepartment auxCode in auxCodes)
            {
                _MappingAuxCodeDepartmentRepository.Add(auxCode);
            }

            return this.CommintToDB();
        }

        private List<MappingRoleNavigation> GetDefaultRoleNavigationDetails(MstDepartment department, UserPrimaryDetails createdBy)
        {
            List<MappingRoleNavigation> lstMappingRoleNavigation = new List<MappingRoleNavigation>()
            {
                ////Advisor
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdvisorRoleId, NavigationId = Settings.Constants.DashboardNavigationId, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},

                ////Manager
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.ManagerDashboard, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.RTA_Dashboard, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.UserManagement, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.AddUser, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.AddRole, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.LoggedInUser, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.Reports, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.LoginLogoutReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.NonCoreActivityReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.CoreActivityReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.STTReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.ActiveUserReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.ManagerRoleId, NavigationId = Settings.Constants.AddTeam, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},

                ////admin
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.ManagerDashboard, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.RTA_Dashboard, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.UserManagement, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddUser, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddRole, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.LoggedInUser, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.Settings, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddDepartment, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddActivity, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddAuxCode, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.Reports, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.LoginLogoutReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.NonCoreActivityReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.CoreActivityReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.STTReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.ActiveUserReport, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddTeam, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now},
                new MappingRoleNavigation(){ DepartmentId = department.Id, RoleId = Settings.Constants.AdminRoleId, NavigationId = Settings.Constants.AddAdmin, CreatedBy = createdBy.Id,Created = DateTimeHelper.Now,ModifiedBy = createdBy.Id,Modified = DateTimeHelper.Now}
            };
            return lstMappingRoleNavigation;
        }

        public bool CheckDepartmentExists(MstDepartment department)
        {
            return _DepartmentRepository.Get().Where(x => x.Name.ToLower().Trim() == department.Name.ToLower().Trim() && x.Id != department.Id).Any();
        }

        public bool CheckDepartmentExists(string departmentName)
        {
            return _DepartmentRepository.Get().Where(x => x.Name.ToLower().Trim() == departmentName.ToLower().Trim()).Any();
        }

        public bool UpdateDepartment(MstDepartment department, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            MstDepartment existingDepartment = this.GetDepartmentById(department.Id);

            if (existingDepartment != null)
            {
                existingDepartment.Name = department.Name;
                existingDepartment.IsActive = department.IsActive;
                existingDepartment.ModifiedBy = modifiedBy.Id;
                existingDepartment.ModifiedDate = DateTimeHelper.Now;

                _DepartmentRepository.Update(existingDepartment);
                status = this.CommintToDB();
            }

            return status;
        }

        public bool DeleteDepartmentById(int id, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            MstDepartment existingDepartment = this.GetDepartmentById(id);

            if (existingDepartment != null)
            {
                existingDepartment.IsActive = false;
                existingDepartment.ModifiedBy = modifiedBy.Id;
                existingDepartment.ModifiedDate = DateTimeHelper.Now;

                _DepartmentRepository.Update(existingDepartment);
                status = this.CommintToDB();
            }

            return status;
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
