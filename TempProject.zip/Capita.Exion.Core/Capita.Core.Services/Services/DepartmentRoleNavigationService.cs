﻿using System.Collections.Generic;
using System.Linq;
using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services.Services
{
    public class DepartmentRoleNavigationService : IMappingDepartmentRoleNavigation
    {
        private readonly IUnitOfWork _uow = null;
        private IDataContext _dataContext = null;
        private IGenericRepository<MappingDepartmentRoleNavigation> _MappingDepartmentRoleNavigationRepository = null;

        public DepartmentRoleNavigationService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _MappingDepartmentRoleNavigationRepository = _uow.GetRepository<MappingDepartmentRoleNavigation>();
        }

        public IEnumerable<MappingDepartmentRoleNavigation> GetAllMappingDepartmentRoleNavigation()
        {
            IEnumerable<MappingDepartmentRoleNavigation> lstMappingDepartmentRoleNavigation = _MappingDepartmentRoleNavigationRepository.Get();
            return lstMappingDepartmentRoleNavigation;
        }

        public MappingDepartmentRoleNavigation GetMappingDepartmentRoleNavigationById(int id)
        {
            MappingDepartmentRoleNavigation mappingDepartmentRoleNavigation = _MappingDepartmentRoleNavigationRepository.FindBy(x => x.Id == id).FirstOrDefault();
            return mappingDepartmentRoleNavigation;
        }

        public bool AddMappingDepartmentRoleNavigation(MappingDepartmentRoleNavigation mappingDepartmentRoleNavigation)
        {
            _MappingDepartmentRoleNavigationRepository.Add(mappingDepartmentRoleNavigation);
            return _uow.Commit();
        }

        public bool UpdateMappingDepartmentRoleNavigation(MappingDepartmentRoleNavigation mappingDepartmentRoleNavigation)
        {
            bool status = false;
            MappingDepartmentRoleNavigation existingMappingDepartmentRoleNavigation = this.GetMappingDepartmentRoleNavigationById(mappingDepartmentRoleNavigation.Id);

            if (existingMappingDepartmentRoleNavigation != null)
            {
                existingMappingDepartmentRoleNavigation.IsActive = mappingDepartmentRoleNavigation.IsActive;

                _MappingDepartmentRoleNavigationRepository.Update(existingMappingDepartmentRoleNavigation);
                status = _uow.Commit();
            }

            return status;
        }

        public bool DeleteMappingDepartmentRoleNavigationById(int id)
        {
            _MappingDepartmentRoleNavigationRepository.Delete(id);
            return _uow.Commit();
        }
    }
}
