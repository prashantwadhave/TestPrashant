﻿namespace Capita.Core.Services.Services
{
    using Capita.Core.Contracts;
    using Capita.Core.Models;
    using Capita.Core.Models.CustomModels;
    using Capita.Core.Models.DataModels;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
        
    public class AuxCodeService : IAuxCode
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IGenericRepository<MstAuxCode> _AuxRepository = null;

        private IGenericRepository<MappingAuxCodeDepartment> _MappingAuxCodeDepartmentRepository = null;
        private IGenericRepository<MstDepartment> _MstDepartmentRepository = null;

        public AuxCodeService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _AuxRepository = _uow.GetRepository<MstAuxCode>();
        }

        private int GetMaxId()
        {
            return _AuxRepository.Get().Max(x => x.Id) + 1;
        }
        public bool CheckAuxCodeExists(MstAuxCode auxcode)
        {
            return _AuxRepository.Get().Where(x => x.ActivityName.ToLower().Trim() == auxcode.ActivityName.ToLower().Trim() && x.Id != auxcode.Id).Any();
        }

        public IEnumerable<MstAuxCode> GetAllAuxCodeList()
        {
            var auxCodeIdList = _AuxRepository.Get().Where(x => x.ActivityName.ToLower().Trim() != "idle").OrderByDescending(x => x.Id).ToList();
            return auxCodeIdList;
        }

        public IEnumerable<MstAuxCode> GetAllAssignedAuxCode(int departmentId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
            IQueryable<int> queryAssignedAuxCodeIdList = _MappingAuxCodeDepartmentRepository.Get().Where(x => x.IsVisibile == true && x.DepartmentId == departmentId).Select(x => x.AuxCodeId).Distinct();
            var assignedAuxCodeIdList = queryAssignedAuxCodeIdList.ToList();
            var assignedAuxCodeIdListForDept = _AuxRepository.Get().Where(x => assignedAuxCodeIdList.Contains(x.Id) && x.ActivityName.ToLower().Trim() != "idle").OrderByDescending(x => x.Id);
            return assignedAuxCodeIdListForDept;
        }

        public List<KeyValuePair> GetAllAuxCode()
        {
            List<KeyValuePair> lstAuxCode = _AuxRepository.Get().Where(x=> x.ActivityName.ToLower().Trim() != "idle").Select(x=> new KeyValuePair() { Key = x.Id.ToString() , Value = x.ActivityName } ).OrderBy(x=> x.Value).ToList();
            return lstAuxCode;
        }

        public IEnumerable<MstAuxCode> GetAllAuxCode(int departmentId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
             List<int> lstDeptAuxCode = _MappingAuxCodeDepartmentRepository.Get().Where(x => x.DepartmentId == departmentId && x.IsVisibile).Select(x=>x.AuxCodeId).ToList();

            IEnumerable<MstAuxCode> lstAuxCode = _AuxRepository.Get().Where(x => lstDeptAuxCode.Contains(x.Id)).OrderBy(x => x.ActivityName).ToList();
            return lstAuxCode;            
        }

        public IEnumerable<AuxCodeDepartment> GetAllAuxCodeDepartment(int departmentId, int auxCodeId)
        {
            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentID", Value = departmentId.ToString() },
               new spParameter() { Name = "@AuxCodeId", Value = auxCodeId.ToString() }
            };
            IEnumerable<AuxCodeDepartment> result = _uow.GetRepository<AuxCodeDepartment>().GetSP("GetAuxcodeByDepartmentId", spParameters);

            return result;
        }

        public MstAuxCode GetAuxCodeById(int id)
        {
            MstAuxCode lstDepartments = _AuxRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return lstDepartments;
        }

        public bool AddAuxCode(MstAuxCode auxCode, UserPrimaryDetails createdBy)
        {
            auxCode.Id = this.GetMaxId();
            auxCode.CreatedBy = auxCode.ModifiedBy = createdBy.Id;
            auxCode.CreatedDate = auxCode.ModifiedDate = DateTimeHelper.Now;
            _AuxRepository.Add(auxCode);
            return this.CommitToDB();
        }

        public bool UpdateAuxCode(MstAuxCode auxCode, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            MstAuxCode existingAuxCode = this.GetAuxCodeById(auxCode.Id);

            if (existingAuxCode != null)
            {
                existingAuxCode.ActivityName = auxCode.ActivityName;
                existingAuxCode.ModifiedBy = modifiedBy.Id;
                existingAuxCode.ModifiedDate = DateTimeHelper.Now;

                _AuxRepository.Update(existingAuxCode);
                status = this.CommitToDB();
            }

            return status;
        }

        public bool DeleteAuxCodeById(int id)
        {
            _AuxRepository.Delete(id);
            return this.CommitToDB();
        }

        public List<KeyValuePair> GetDepartmentsWhichDontHaveSelectedAuxCode(int auxCodeId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
            _MstDepartmentRepository = _uow.GetRepository<MstDepartment>();

            List<int> departmentIdList = _MappingAuxCodeDepartmentRepository.Get().Where(x => x.AuxCodeId == auxCodeId && x.IsVisibile == true).Select(x => x.DepartmentId).ToList();

            List<KeyValuePair> departmentList = _MstDepartmentRepository.Get().Where(x => !(departmentIdList.Contains(x.Id)) && x.IsActive).Select(x=> new KeyValuePair() { Key = x.Id.ToString(), Value = x.Name }).OrderBy(x => x.Value).ToList();

            return departmentList;
        }

        private bool CommitToDB()
        {
            return _uow.Commit();
        }

        public bool AddUpdateMappingAuxCodeDepartment(int auxCodeId, int departmentId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
            var mapping = _MappingAuxCodeDepartmentRepository.Get().Where(x => x.AuxCodeId == auxCodeId && x.DepartmentId == departmentId).FirstOrDefault();
            if(mapping!= null)
            {
                return this.UpdateMappingAuxCodeDepartment(auxCodeId, departmentId);
            }
            else
            {
                return this.AddMappingAuxCodeDepartment(auxCodeId, departmentId);
            }
        }

        private bool AddMappingAuxCodeDepartment(int auxCodeId, int departmentId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();

            MappingAuxCodeDepartment mappingAuxCodeDepartment = new MappingAuxCodeDepartment();

            mappingAuxCodeDepartment.AuxCodeId = auxCodeId;
            mappingAuxCodeDepartment.DepartmentId = departmentId;
            mappingAuxCodeDepartment.IsVisibile = true;

            _MappingAuxCodeDepartmentRepository.Add(mappingAuxCodeDepartment);
            return this.CommitToDB();
        }

        private bool UpdateMappingAuxCodeDepartment(int auxCodeId, int departmentId)
        {
            bool status = false;
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();

            MappingAuxCodeDepartment existingAuxCodeDepartment = _MappingAuxCodeDepartmentRepository.Get().Where(x => x.AuxCodeId == auxCodeId && x.DepartmentId == departmentId).FirstOrDefault();

            if (existingAuxCodeDepartment != null)
            {
                existingAuxCodeDepartment.IsVisibile = true;

                _MappingAuxCodeDepartmentRepository.Update(existingAuxCodeDepartment);
                status = this.CommitToDB();
            }
            return status;
        }

        public bool DeleteMapAuxCodeAndDepartment(int auxCodeId, int departmentId)
        {
            bool status = false;
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();

            MappingAuxCodeDepartment existingAuxCodeDepartment = _MappingAuxCodeDepartmentRepository.Get().Where(x=> x.AuxCodeId == auxCodeId && x.DepartmentId == departmentId).FirstOrDefault();

            if (existingAuxCodeDepartment != null)
            {
                existingAuxCodeDepartment.IsVisibile = false;

                _MappingAuxCodeDepartmentRepository.Update(existingAuxCodeDepartment);
                status = this.CommitToDB();
            }
            return status;
        }

        public bool CheckMappingExistsAuxCodeAndDepartment(int auxCodeId, int departmentId)
        {
            _MappingAuxCodeDepartmentRepository = _uow.GetRepository<MappingAuxCodeDepartment>();
            return _MappingAuxCodeDepartmentRepository.Get().Where(x => x.AuxCodeId == auxCodeId && x.DepartmentId == departmentId && x.IsVisibile).Any();
        }
    }
}
