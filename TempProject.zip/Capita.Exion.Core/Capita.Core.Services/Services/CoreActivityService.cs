﻿using Capita.Core.Contracts.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Models.DataModels;
using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using System.Data.SqlClient;

namespace Capita.Core.Services.Services
{
    public class CoreActivityService : ICoreActivity
    {

        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private IGenericRepository<CoreActivityJourney> _CARepository = null;

        private IGenericRepository<UserPrimaryDetails> _UserRepository = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;

        public CoreActivityService(IUser userService, IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _CARepository = _uow.GetRepository<CoreActivityJourney>();
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
        }

        public List<CoreActivity> GetCoreActivities(int departmentId, DateTime startDate, DateTime endDate, string lanId)
        {
            List<CoreActivity> coreActivities = new List<CoreActivity>();

            string timeZone = _UserRepository.FindBy(x => x.LanId == lanId).FirstOrDefault().TimeZone;
            if (startDate == endDate)
            {
                endDate = endDate.AddDays(1);
            }
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate, userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.MonthDateFormat) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.MonthDateFormat) }
            };
            IEnumerable<CoreActivity> result = _uow.GetRepository<CoreActivity>().GetSP("SpGetUserActivityReport", spParameters);
            if (result != null)
            {
                result = result.Select(x => new CoreActivity()
                {
                    AgentName = x.AgentName,
                    DepartmentId = x.DepartmentId,
                    StartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone),
                    EndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone) : x.EndTime,
                    StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                    StrEndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.EndTime.ToString(),
                    Duration = x.Duration,
                    Remarks = x.Remarks,
                    Scheme = x.Scheme,
                    UID = x.UID,
                    Task = x.Task

                });
            }

            return result.ToList();

        }

        public int AddCoreActivity(CoreActivityJourney coreActivity, int activeNonCoreActivityId, string lanId)
        {
            int activityId = 0;
            DateTime currentTime = DateTimeHelper.Now;
            int userId = _UserService.GetUserIdFromLanId(lanId);
            coreActivity.ActivityType = Settings.Constants.CoreActivity;
            coreActivity.UserId = userId;
            coreActivity.EndTime = null;
            coreActivity.StartTime = currentTime;
            _CARepository.Add(coreActivity);

            NonCoreActivityJourney idleNonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));

            if (idleNonCoreActivity != null)
            {
                idleNonCoreActivity.Comment = string.Empty;
                idleNonCoreActivity.EndTime = currentTime;
                idleNonCoreActivity.Duration = Convert.ToInt64(currentTime.Subtract(idleNonCoreActivity.StartTime).TotalSeconds);
                _NCARepository.Update(idleNonCoreActivity);
            }

            string currentActivity;

            if (!string.IsNullOrWhiteSpace(coreActivity.Param3))
            {
                currentActivity = coreActivity.Param1 + '-' + coreActivity.Param3;
            }
            else
            {
                currentActivity = coreActivity.Param1;
            }
            //// Update Current Activity
            _UserService.AddOrUpdateCurrentActivity(userId, Settings.Constants.CoreActivity, 0, coreActivity.DepartmentId, currentActivity, coreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme

            if (this.CommitToDB())
                activityId = coreActivity.Id;

            return activityId;
        }

        public int UpdateCoreActivity(CoreActivityJourney coreActivityJourney)
        {
            int nonCoreActivityId = 0;

            bool isUniqueIdExist = _CARepository.Get().Where(x => x.DepartmentId == coreActivityJourney.DepartmentId && x.Param2.ToLower() == coreActivityJourney.Param2.ToLower()).Any();

            CoreActivityJourney coreActivity = _CARepository.GetByID(coreActivityJourney.Id);

            if (coreActivity != null)
            {
                coreActivity.Remarks = coreActivityJourney.Remarks;
                coreActivity.Param1 = coreActivityJourney.Param1;
                coreActivity.Param2 = coreActivityJourney.Param2;
                coreActivity.Param3 = coreActivityJourney.Param3;
                coreActivity.Param4 = coreActivityJourney.Param4;
                coreActivity.Param5 = coreActivityJourney.Param5;
                coreActivity.Param6 = coreActivityJourney.Param6;
                coreActivity.Param7 = coreActivityJourney.Param7;
                coreActivity.Param8 = coreActivityJourney.Param8;
                coreActivity.Param9 = coreActivityJourney.Param9;
                coreActivity.Param10 = coreActivityJourney.Param10;
                coreActivity.Param11 = coreActivityJourney.Param11;
                coreActivity.Param12 = coreActivityJourney.Param12;
                coreActivity.Param13 = coreActivityJourney.Param13;
                coreActivity.Param14 = coreActivityJourney.Param14;
                coreActivity.Param15 = coreActivityJourney.Param15;
                coreActivity.Param16 = coreActivityJourney.Param16;
                coreActivity.Param17 = coreActivityJourney.Param17;
                coreActivity.Param18 = coreActivityJourney.Param18;
                coreActivity.Param19 = coreActivityJourney.Param19;
                coreActivity.Param20 = coreActivityJourney.Param20;
                coreActivity.Param21 = coreActivityJourney.Param21;
                coreActivity.Param22 = coreActivityJourney.Param22;
                coreActivity.Param23 = coreActivityJourney.Param23;
                coreActivity.Param24 = coreActivityJourney.Param24;
                coreActivity.Param25 = coreActivityJourney.Param25;
                coreActivity.Param26 = coreActivityJourney.Param26;

                DateTime currentTime = DateTimeHelper.Now;
                coreActivity.EndTime = currentTime;

                _CARepository.Update(coreActivity);

                ////Add idle entry 
                NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = coreActivity.DepartmentId, TeamId = coreActivity.TeamId, StartTime = currentTime, EndTime = null, UserId = coreActivity.UserId };
                _NCARepository.Add(idleNonCoreActivity);

                //// Update Current Activity                
                _UserService.AddOrUpdateCurrentActivity(coreActivity.UserId, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, coreActivity.DepartmentId, string.Empty, coreActivity.TeamId);//// Param1 is scheme

                if (this.CommitToDB())
                {
                    List<spParameter> spParameters = new List<spParameter>()
                    {
                        new spParameter() { Name = "@CoreActivityId",  Value = coreActivity.Id.ToString()},
                        new spParameter() { Name = "@UserId", Value = coreActivity.UserId.ToString() },
                        new spParameter() { Name = "@DepartmentId", Value = coreActivity.DepartmentId.ToString() }
                    };

                    IEnumerable<IdValuePair> result = _uow.GetRepository<IdValuePair>().GetSP("UpdateCoreActivityDuration", spParameters);
                }

                nonCoreActivityId = idleNonCoreActivity.Id;
            }

            return nonCoreActivityId;
        }

        public CoreActivityJourney GetCurrentActivity(int userId, int departmentId, string activityType)
        {
            return _CARepository.Get().Where(x => x.UserId == userId && x.DepartmentId == departmentId && x.ActivityType == activityType).OrderByDescending(x => x.Id).FirstOrDefault();
        }

        private bool CommitToDB()
        {
            return _uow.Commit();
        }
    }
}
