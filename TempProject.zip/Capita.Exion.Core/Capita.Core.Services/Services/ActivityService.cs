﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class ActivityService : IActivity
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IGenericRepository<MstActivity> _ActivityRepository = null;
        private IGenericRepository<MstActivityGroup> _ActivityGroupRepository = null;

        public ActivityService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _ActivityRepository = _uow.GetRepository<MstActivity>();
            _ActivityGroupRepository = _uow.GetRepository<MstActivityGroup>();
        }
        public int GetMaxId()
        {
            return _ActivityRepository.Get().Max(x => x.Id) + 1;
        }
        public bool AddActivity(MstActivity activity, UserPrimaryDetails createdBy)
        {
            activity.STT = activity.STT == 0 ? 1 : activity.STT;
            activity.Id = this.GetMaxId();
            activity.IsActive = true;
            activity.CreatedBy = activity.ModifiedBy = createdBy.Id;
            activity.CreatedDate = activity.ModifiedDate = DateTimeHelper.Now;
            _ActivityRepository.Add(activity);
            return this.CommintToDB();
        }

        public bool CheckActivityExists(string activityName)
        {
            return _ActivityRepository.Get().Where(x => x.ActivityName.ToLower().Trim() == activityName.ToLower().Trim()).Any();
        }

        public bool CheckActivityExists(MstActivity activity)
        {
            return _ActivityRepository.Get().Where(x => x.ActivityName.ToLower().Trim() == activity.ActivityName.ToLower().Trim() && x.Id != activity.Id && x.ActivityGroup == activity.ActivityGroup && x.DepartmnetId == activity.DepartmnetId && x.ParentId == activity.ParentId).Any();
        }

        public bool DeleteActivityById(int id, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            MstActivity existingActivity = this.GetActivityById(id);

            if (existingActivity != null)
            {
                existingActivity.IsActive = false;
                existingActivity.ModifiedBy = modifiedBy.Id;
                existingActivity.ModifiedDate = DateTimeHelper.Now;

                _ActivityRepository.Update(existingActivity);
                status = this.CommintToDB();
            }

            return status;
        }

        public IEnumerable<Activity> GetActivity(int departmentId)
        {
            return _ActivityRepository.Get().Where(x => x.DepartmnetId == departmentId && x.IsActive)
                                        .Select(x => new Activity()
                                        {
                                            Id = x.Id,
                                            ActivityGroup = x.ActivityGroup,
                                            ActivityName = x.ActivityName,
                                            DepartmnetId = x.DepartmnetId,
                                            ParentId = x.ParentId,
                                            STT = x.STT
                                        }
                                        ).OrderBy(x=>x.ActivityName);
        }
        public IList<Activity> GetAllActivities(int departmentId)
        {
            IQueryable<MstActivity> childActivity = _ActivityRepository.Get().Where(x => x.DepartmnetId == departmentId).AsQueryable();
            IQueryable<MstActivity> ParentActivity = _ActivityRepository.Get().Where(x => x.DepartmnetId == departmentId).AsQueryable();

            var q = (from c in childActivity
                     join p in ParentActivity on c.ParentId equals p.Id into ps
                     from p in ps.DefaultIfEmpty()
                     select new Activity()
                     {
                         Id = c.Id,
                         ActivityName = c.ActivityName != null ? c.ActivityName : string.Empty,
                         ActivityGroup = c.ActivityGroup,
                         ParentActivityName = p.ActivityName ?? string.Empty,
                         ParentId = c.ParentId,
                         STT = c.STT,
                         IsActive = c.IsActive
                     }).ToList();

            return q.ToList();
        }

        public MstActivity GetActivityById(int id)
        {
            MstActivity lstAcivityes = _ActivityRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return lstAcivityes;
        }

        public bool UpdateActivity(MstActivity activity, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            MstActivity existingActivity = this.GetActivityById(activity.Id);

            if (existingActivity != null)
            {
                existingActivity.ActivityName = activity.ActivityName;
                existingActivity.ActivityGroup = activity.ActivityGroup;
                existingActivity.ParentId = activity.ParentId;
                existingActivity.STT = activity.STT;
                existingActivity.IsActive = activity.IsActive;
                existingActivity.ModifiedBy = modifiedBy.Id;
                existingActivity.ModifiedDate = DateTimeHelper.Now;

                _ActivityRepository.Update(existingActivity);
                status = this.CommintToDB();
            }

            return status;
        }
        private bool CommintToDB()
        {
            return _uow.Commit();
        }

        public IList<MstActivityGroup> GetActivityGroups()
        {

            return _ActivityGroupRepository.Get().ToList();
        }
    }
}
