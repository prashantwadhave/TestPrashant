﻿using System.Collections.Generic;
using System.Linq;
using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services.Services
{
    public class NavigationService : INavigation
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private IGenericRepository<MstNavigation> _navigationRepository = null;

        private IGenericRepository<MappingUserDepartment> _MappingUserDepartment = null;

        private IGenericRepository<MappingRoleNavigation> _MappingRoleNavigation = null;

        public NavigationService(IUnitOfWork uow, IUser userService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _navigationRepository = _uow.GetRepository<MstNavigation>();
        }

        public List<MstNavigation> GetAllNavigations(int departmentId, string lanId)
        {
            List<MstNavigation> lstNavigation = null;
            int userId =_UserService.GetUserIdFromLanId(lanId);

            _MappingUserDepartment = _uow.GetRepository<MappingUserDepartment>();
            _MappingRoleNavigation = _uow.GetRepository<MappingRoleNavigation>();

            List<int> lstRoles = _MappingUserDepartment.Get().Where(x => x.UserId == userId && x.DepartmentId == departmentId).Select(x => x.RoleId).Distinct().ToList();

            List<int> navigationIds = _MappingRoleNavigation.Get().Where(x => lstRoles.Contains(x.RoleId) && x.DepartmentId == departmentId).Select(x => x.NavigationId).Distinct().ToList();

            if (navigationIds != null && navigationIds.Count > 0)
            {               
                lstNavigation = _navigationRepository.Get().Where(x=> x.IsActive && navigationIds.Contains(x.Id)).OrderBy(x=>x.SortOrder).ToList();
            }

            return lstNavigation;
        }

        //public MstNavigation GetNavigationById(int id)
        //{
        //    MstNavigation navigation = _navigationRepository.FindBy(x => x.Id == id).FirstOrDefault();
        //    return navigation;
        //}

        //public bool AddNavigation(MstNavigation navigation)
        //{
        //    _navigationRepository.Add(navigation);
        //    return _uow.Commit();
        //}

        //public bool UpdateNavigation(MstNavigation navigation)
        //{
        //    bool status = false;
        //    MstNavigation existingNavigation = this.GetNavigationById(navigation.Id);

        //    if (existingNavigation != null)
        //    {
        //        existingNavigation.DisplayName = navigation.DisplayName;

        //        _navigationRepository.Update(existingNavigation);
        //        status = _uow.Commit();
        //    }

        //    return status;
        //}

        //public bool DeleteNavigationById(int id)
        //{
        //    _navigationRepository.Delete(id);
        //    return _uow.Commit();
        //}
    }
}
