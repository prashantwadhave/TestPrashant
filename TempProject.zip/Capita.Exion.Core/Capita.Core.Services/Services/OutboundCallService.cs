﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class OutboundCallService: IOutbondCall
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private ICoreActivity _CoreService = null;

        private IGenericRepository<CoreActivityJourney> _CARepository = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;

        public OutboundCallService(IUser userService, IUnitOfWork uow, ICoreActivity coreService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _CoreService = coreService;
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
            _CARepository = _uow.GetRepository<CoreActivityJourney>();
        }

        public int AddOutboundCallActivity(int departmentId, string comment, int activeNonCoreActivityId, string lanId, int teamId)
        {
            int activityId = 0;
            DateTime currentTime = DateTimeHelper.Now;

            CoreActivityJourney OcallsCoreActivity = new CoreActivityJourney();

            OcallsCoreActivity.ActivityType = Settings.Constants.OutbondCall;
            OcallsCoreActivity.UserId = _UserService.GetUserIdFromLanId(lanId);
            OcallsCoreActivity.DepartmentId = departmentId;
            OcallsCoreActivity.TeamId = teamId;
            OcallsCoreActivity.StartTime = currentTime;
            OcallsCoreActivity.EndTime = null;

            _CARepository.Add(OcallsCoreActivity);

            NonCoreActivityJourney idleNonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));

            if (idleNonCoreActivity != null && !idleNonCoreActivity.EndTime.HasValue)
            {
                idleNonCoreActivity.Comment = string.Empty;
                idleNonCoreActivity.EndTime = currentTime;
                idleNonCoreActivity.TeamId = teamId;
                idleNonCoreActivity.Duration = Convert.ToInt64(currentTime.Subtract(idleNonCoreActivity.StartTime).TotalSeconds);
                _NCARepository.Update(idleNonCoreActivity);
            }

            //// Update Current Activity
            _UserService.AddOrUpdateCurrentActivity(OcallsCoreActivity.UserId, Settings.Constants.CoreActivity, 0, OcallsCoreActivity.DepartmentId, Settings.Constants.OutbondCall,teamId);////Aux code 0 for core activity, Param1 is scheme

            if (this.CommintToDB())
                activityId = OcallsCoreActivity.Id;

            return activityId;
        }

        public int UpdateOutboundCallActivity(int OCallId, string comment, bool isCoreActivtyStarted, bool isWebChatActivtyStarted)
        {
            int nonCoreActivityId = 0;
            CoreActivityJourney OcallCoreActivity = _CARepository.GetByID(OCallId);

            if (OcallCoreActivity != null)
            {
                OcallCoreActivity.Remarks = comment;

                DateTime currentTime = DateTimeHelper.Now;
                OcallCoreActivity.EndTime = currentTime;
                OcallCoreActivity.Duration = Convert.ToInt64((currentTime.Subtract(OcallCoreActivity.StartTime)).TotalSeconds);

                NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = OcallCoreActivity.DepartmentId,TeamId= OcallCoreActivity.TeamId, StartTime = currentTime, EndTime = null, UserId = OcallCoreActivity.UserId };

                if (!isCoreActivtyStarted && !isWebChatActivtyStarted)
                {
                    ////Add idle entry 
                    _NCARepository.Add(idleNonCoreActivity);

                    ////Update current activity            
                    _UserService.AddOrUpdateCurrentActivity(OcallCoreActivity.UserId, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, OcallCoreActivity.DepartmentId, string.Empty, OcallCoreActivity.TeamId);
                }
                else
                {
                    //// Update Current Activity
                    if (isWebChatActivtyStarted)
                    {
                        _UserService.AddOrUpdateCurrentActivity(OcallCoreActivity.UserId, Settings.Constants.CoreActivity, 0, OcallCoreActivity.DepartmentId, Settings.Constants.WebChat, OcallCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                                            
                    }
                    else
                    {
                        CoreActivityJourney currentCoreActivity = _CoreService.GetCurrentActivity(OcallCoreActivity.UserId, OcallCoreActivity.DepartmentId, Settings.Constants.CoreActivity);

                        string currentActivity= string.IsNullOrWhiteSpace(currentCoreActivity.Param3)==false? currentCoreActivity.Param1 + '-' + currentCoreActivity.Param3: currentCoreActivity.Param1;
                        
                        if (currentCoreActivity != null)
                            _UserService.AddOrUpdateCurrentActivity(OcallCoreActivity.UserId, Settings.Constants.CoreActivity, 0, OcallCoreActivity.DepartmentId, currentActivity, OcallCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                    
                        else
                            _UserService.AddOrUpdateCurrentActivity(OcallCoreActivity.UserId, Settings.Constants.CoreActivity, 0, OcallCoreActivity.DepartmentId, string.Empty, OcallCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                    
                    }
                }

                _CARepository.Update(OcallCoreActivity);
                this.CommintToDB();
                nonCoreActivityId = idleNonCoreActivity.Id;
            }

            return nonCoreActivityId;
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
