﻿using Capita.Core.Contracts;
using Capita.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class EmailService : IEmailService
    {
        ExceptionLoggerService exceptionLoggerService;
        public EmailService(ExceptionLoggerService exceptionLoggerService)
        {
            this.exceptionLoggerService = exceptionLoggerService;
        }
        public bool SendEmail(string emailTo, string emailCC, string msgSubject, string msgBody)
        {
            bool IsSend = false;
            try
            {
                if (!string.IsNullOrEmpty(emailTo))
                {
                    //Create the mail message and supply it with from and to info
                    using (MailMessage mail = new MailMessage())
                    {
                        mail.From = new MailAddress(Settings.AppSetting.FromAddress, Settings.AppSetting.FromAddressTitle);

                        if (emailTo.Contains(';'))
                        {
                            string[] ToId = emailTo.Split(';');

                            foreach (string ToEmail in ToId)
                            {
                                if (!string.IsNullOrEmpty(ToEmail) && !ToEmail.Equals("&nbsp;"))
                                {
                                    mail.To.Add(new MailAddress(ToEmail)); //Adding Multiple To email Id
                                }
                            }
                        }
                        else
                        {
                            mail.To.Add(new MailAddress(emailTo));
                        }

                        if (!string.IsNullOrEmpty(emailCC))
                        {
                            if (emailCC.Contains(';'))
                            {
                                string[] CCId = emailCC.Split(';');

                                foreach (string CCEmail in CCId)
                                {
                                    if (!string.IsNullOrEmpty(CCEmail) && !CCEmail.Equals("&nbsp;"))
                                    {
                                        mail.CC.Add(new MailAddress(CCEmail)); //Adding Multiple CC email Id
                                    }
                                }
                            }
                            else
                            {
                                mail.CC.Add(new MailAddress(emailCC));
                            }
                        }

                        //Set the subject only with 100 char and body of the message
                        if (msgSubject.Length > 254) msgSubject = msgSubject.Substring(0, 254);
                        mail.Subject = msgSubject.Trim().Replace('\r', ' ').Replace('\n', ' ');
                        mail.Body = msgBody;
                        mail.BodyEncoding = System.Text.Encoding.ASCII;
                        mail.IsBodyHtml = true;
                        //Create the SMTP client object and send the message
                        SmtpClient smtpClient = new SmtpClient
                        {
                            Host = Settings.AppSetting.SmtpServer,
                            Port = Settings.AppSetting.Port,
                            UseDefaultCredentials = true
                        };
                        smtpClient.Send(mail);
                        IsSend = true;
                    }
                }
            }

            catch (Exception ex)
            {
                IsSend = false;
                exceptionLoggerService.Log(ex, string.Empty);
            }
            return IsSend;

        }
    }

}
