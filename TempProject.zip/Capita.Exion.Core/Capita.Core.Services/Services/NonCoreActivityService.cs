﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models;
using Capita.Core.Models.DataModels;
using Capita.Core.Services.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class NonCoreActivityService : INonCoreActivity
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private ICoreActivity _CoreService = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;

        public NonCoreActivityService(IUnitOfWork uow, IUser userService, ICoreActivity coreService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _CoreService = coreService;
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
        }

        public int AddActivity(NonCoreActivityJourney nonCoreActivityJourney, int userId, int activeNonCoreActivityId)
        {
            NonCoreActivityJourney idleNonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));
            DateTime currentTime = DateTimeHelper.Now;

            if (idleNonCoreActivity != null)
            {
                idleNonCoreActivity.EndTime = currentTime;
                idleNonCoreActivity.Duration = Convert.ToInt64(currentTime.Subtract(idleNonCoreActivity.StartTime).TotalSeconds);                
                _NCARepository.Update(idleNonCoreActivity);
            }

            if (nonCoreActivityJourney != null)
            {
                nonCoreActivityJourney.UserId = userId;
                nonCoreActivityJourney.StartTime = DateTimeHelper.Now;
                nonCoreActivityJourney.EndTime = null;
                nonCoreActivityJourney.Duration = 0;
                
                if (string.IsNullOrEmpty(nonCoreActivityJourney.Comment))
                    nonCoreActivityJourney.Comment = string.Empty;                    

                _NCARepository.Add(nonCoreActivityJourney);

                //// Update Current Activity
                _UserService.AddOrUpdateCurrentActivity(userId, Settings.Constants.NonCoreActivity, nonCoreActivityJourney.AuxCodeId, nonCoreActivityJourney.DepartmentId, string.Empty, nonCoreActivityJourney.TeamId);
            }

            if (this.CommintToDB())
                return nonCoreActivityJourney.Id;
            else
                return 0;
        }

        public int UpdateActivity(string activeNonCoreActivityId, string comments, bool isAnyCoreActivtyStarted)
        {
            int newNonCoreActivityId = 0;
            DateTime currentDatetime = DateTimeHelper.Now;
            NonCoreActivityJourney nonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));            

            if (nonCoreActivity != null)
            {                
                if(string.IsNullOrEmpty(comments))
                    nonCoreActivity.Comment = string.Empty;
                else
                    nonCoreActivity.Comment = comments;

                nonCoreActivity.EndTime = currentDatetime;
                nonCoreActivity.Duration = Convert.ToInt64(currentDatetime.Subtract(nonCoreActivity.StartTime).TotalSeconds);
                _NCARepository.Update(nonCoreActivity);

                NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Duration = 0, AuxCodeId = 1, Comment = string.Empty, DepartmentId = nonCoreActivity.DepartmentId, TeamId=nonCoreActivity.TeamId, StartTime = currentDatetime, EndTime = null, UserId = nonCoreActivity.UserId };

                if (!isAnyCoreActivtyStarted)
                {
                    _NCARepository.Add(idleNonCoreActivity);
                    //// Update Current Activity                
                    _UserService.AddOrUpdateCurrentActivity(nonCoreActivity.UserId, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, nonCoreActivity.DepartmentId, string.Empty, nonCoreActivity.TeamId);
                }
                else
                {
                    CoreActivityJourney currentActivity = _CoreService.GetCurrentActivity(nonCoreActivity.UserId, nonCoreActivity.DepartmentId, Settings.Constants.CoreActivity);
                    string currentActivityName = string.IsNullOrWhiteSpace(currentActivity.Param3) == false ? currentActivity.Param1 + '-' + currentActivity.Param3 : currentActivity.Param1;

                    //// Update Current Activity
                    if (currentActivity != null)
                        _UserService.AddOrUpdateCurrentActivity(nonCoreActivity.UserId, Settings.Constants.CoreActivity, 0, nonCoreActivity.DepartmentId, currentActivityName, nonCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme
                    else
                        _UserService.AddOrUpdateCurrentActivity(nonCoreActivity.UserId, Settings.Constants.CoreActivity, 0, nonCoreActivity.DepartmentId, string.Empty, nonCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme
                }

                this.CommintToDB();

                if(!isAnyCoreActivtyStarted)
                    newNonCoreActivityId = idleNonCoreActivity.Id;
            }

            return newNonCoreActivityId;
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
