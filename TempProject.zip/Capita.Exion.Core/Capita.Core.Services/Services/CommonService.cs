﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;
using Capita.Core.Services.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace Capita.Core.Services.Services
{
    public class CommonService : ICommon
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private IGenericRepository<UserPrimaryDetails> _UserRepository = null;

        private IGenericRepository<UserLoggedIn> _UserLoginRepository = null;

        private IGenericRepository<UserCurrentActivity> _UserCurrentActivityRepository = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;
        private IGenericRepository<CoreActivityJourney> _CARepository = null;

        private IGenericRepository<MstDepartment> _DepartmentRepository = null;

        private IGenericRepository<MstNavigation> _NavigationRepository = null;

        private IGenericRepository<MappingRoleNavigation> _MappingRoleNavigationRepository = null;

        private IGenericRepository<MappingUserDepartment> _MappingUserDepartmentRepository = null;

        private IGenericRepository<UserLogs> _UserLogsRepository = null;

        public CommonService(IUser userService, IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _UserLoginRepository = _uow.GetRepository<UserLoggedIn>();
            _UserCurrentActivityRepository = _uow.GetRepository<UserCurrentActivity>();
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
            _CARepository = _uow.GetRepository<CoreActivityJourney>();
            _UserLogsRepository = _uow.GetRepository<UserLogs>();
        }

        public ActivityIds AddUserLoginDetails(NonCoreActivityJourney nonCoreActivityJourney, string lanId, bool isDepartmentOrRoleChanged)
        {            
            UserPrimaryDetails userDetails =_UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault();////CheckUserExist
            ActivityIds activityId = null;
            UserLogs userLog = null;
            if (userDetails != null)
            {
                activityId = new ActivityIds();
                if (!isDepartmentOrRoleChanged)
                {
                    userLog = new UserLogs()
                    {
                        ActivityName = Models.Settings.Constants.Login,
                        DepartmentId = nonCoreActivityJourney.DepartmentId,
                        UserId = userDetails.Id,
                        UserName = userDetails.FirstName + " " + userDetails.LastName,
                        LoginTime = DateTimeHelper.Now,
                        Duration = 0,
                        LogOutTime = null
                    };
                    _UserService.AddUserLog(userLog);
                }
                this.AddUserLoginTime(userDetails.Id, nonCoreActivityJourney.DepartmentId); //// add login details                
                _UserService.AddOrUpdateCurrentActivity(userDetails.Id, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, nonCoreActivityJourney.DepartmentId, string.Empty, nonCoreActivityJourney.TeamId);////sub activity fetch from auxcode in case pf non core
                this.AddNonCoreActivity(nonCoreActivityJourney, userDetails.Id);////add non core activity                 
                _uow.Commit();

                activityId.NonCoreActivityId = nonCoreActivityJourney != null ? nonCoreActivityJourney.Id : 0;
                activityId.UserLogId = userLog != null ? userLog.Id : 0;
            }

            return activityId;            
        }

        public bool UpdateUserLogOutDetails(int departmentId, string lanId, int nonCoreActivityId, int userLogId)
        {
            DateTime currentTime = DateTimeHelper.Now;
            UserPrimaryDetails userDetails = _UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault();////CheckUserExist
            UserLoggedIn userLoginDetails = _UserLoginRepository.Get().Where(x => x.UserId == userDetails.Id && x.DepartmentId == departmentId).FirstOrDefault();
            UserCurrentActivity userActivity = _UserCurrentActivityRepository.Get().Where(x => x.UserId == userDetails.Id && x.DepartmentId == departmentId).FirstOrDefault();
            NonCoreActivityJourney nonCoreActivityJourney = _NCARepository.GetByID(nonCoreActivityId);

            if (userLoginDetails != null)
            {
                userLoginDetails.LoggedOut = currentTime;
                _UserLoginRepository.Update(userLoginDetails);
            }

            if (userActivity != null)
                _UserCurrentActivityRepository.Delete(userActivity.Id);

            if (nonCoreActivityJourney != null)
            {
                if (nonCoreActivityJourney.EndTime == null)
                {
                    nonCoreActivityJourney.Duration = Convert.ToInt64(currentTime.Subtract(nonCoreActivityJourney.StartTime).TotalSeconds);
                    nonCoreActivityJourney.EndTime = currentTime;
                    _NCARepository.Update(nonCoreActivityJourney);
                }
            }

            UserLogs userLog =_UserService.GetUserLog(userLogId);

            if (userLog != null)
            {
                userLog.LogOutTime = currentTime;
                userLog.Duration = Convert.ToInt32((currentTime - userLog.LoginTime).TotalSeconds);
                _UserService.UpdateUserLog(userLog);
            }
            else
            {
                userLog = _UserLogsRepository.Get().Where(x => x.UserId == userDetails.Id && x.LogOutTime == null).OrderByDescending(x => x.Id).FirstOrDefault();
                userLog.LogOutTime = currentTime;
                userLog.Duration = Convert.ToInt32((currentTime - userLog.LoginTime).TotalSeconds);
                _UserService.UpdateUserLog(userLog);
            }

            return _uow.Commit();
        }

        public bool UpdateUserLogOutDetailsByUserLoggedInId(int departmentId, string UserLoggedInId, UserPrimaryDetails modifiedBy)
        {
            bool status = false;
            DateTime currentTime = DateTimeHelper.Now;//need to use modifiedBy

            List<int> lstUserLoggedInId = new List<int>();
            lstUserLoggedInId = UserLoggedInId.Split(',').Select(x=> Convert.ToInt32(x)).ToList();

            List<CoreActivityJourney> lstCoreActivityToUpdate = new List<CoreActivityJourney>();

            foreach (int userLoggedId in lstUserLoggedInId)
            {
                UserLoggedIn userLoginDetails = _UserLoginRepository.FindBy(x => x.Id == userLoggedId && x.DepartmentId == departmentId).FirstOrDefault();
                UserPrimaryDetails userDetails = _UserRepository.FindBy(x => x.Id == userLoginDetails.UserId).FirstOrDefault();
                UserCurrentActivity userActivity = _UserCurrentActivityRepository.FindBy(x => x.UserId == userLoginDetails.UserId && x.DepartmentId == departmentId).FirstOrDefault();
                List<CoreActivityJourney> lstCoreActivityJourneyForUser = new List<CoreActivityJourney>();
                lstCoreActivityJourneyForUser = _CARepository.Get().Where(x => x.UserId == userLoginDetails.UserId && x.EndTime == null && x.StartTime >= userLoginDetails.LoggedIn).ToList();

                var lastNonCoreActivity = _NCARepository.Get().Where(x => x.UserId == userLoginDetails.UserId && x.DepartmentId == departmentId && x.EndTime == null)
                                                          .OrderByDescending(x => x.StartTime).FirstOrDefault();
                int nonCoreActivityId = lastNonCoreActivity != null ? lastNonCoreActivity.Id : 0;

                var lastUserLog = _UserLogsRepository.Get().Where(x => x.UserId == userLoginDetails.UserId && x.DepartmentId == departmentId && x.LogOutTime == null)
                                                       .OrderByDescending(x => x.LoginTime).FirstOrDefault();
                int userLogId = lastUserLog != null ? lastUserLog.Id : 0;

                NonCoreActivityJourney nonCoreActivityJourney = _NCARepository.GetByID(nonCoreActivityId);

                DateTime maxStartTime;
                DateTime updatedEndTime;
                DateTime? maxStartTime_nonCore = null;
                DateTime? maxStartTime_Core = null;

                if (nonCoreActivityJourney != null)
                {
                    maxStartTime_nonCore = nonCoreActivityJourney.StartTime; 
                }
                if (lstCoreActivityJourneyForUser.Count > 0)
                {
                    maxStartTime_Core = lstCoreActivityJourneyForUser.Max(x=> x.StartTime);
                }

                if(maxStartTime_nonCore == null)
                {
                    maxStartTime = Convert.ToDateTime(maxStartTime_Core);
                }
                else if (maxStartTime_Core == null)
                {
                    maxStartTime = Convert.ToDateTime(maxStartTime_nonCore);
                }
                else
                {
                    Int64 diff_maxStartTimeCore_maxStartTimeNonCore = Convert.ToInt64(Convert.ToDateTime(maxStartTime_Core).Subtract(Convert.ToDateTime(maxStartTime_nonCore)).TotalSeconds);
                    if(diff_maxStartTimeCore_maxStartTimeNonCore > 0)
                    {
                        maxStartTime = Convert.ToDateTime(maxStartTime_Core);
                    }
                    else
                    {
                        maxStartTime = Convert.ToDateTime(maxStartTime_nonCore);
                    }
                }

                Int64 timeToAddToMaxStartTime = Convert.ToInt64(currentTime.Subtract(Convert.ToDateTime(maxStartTime)).TotalSeconds);

                if (timeToAddToMaxStartTime > 900) //900= 15 mins
                    timeToAddToMaxStartTime = 900;

                updatedEndTime = maxStartTime.AddSeconds(timeToAddToMaxStartTime);


                if (modifiedBy.Id != userLoginDetails.UserId)
                {
                    if (userLoginDetails != null)
                    {
                        userLoginDetails.LoggedOut = updatedEndTime;
                        _UserLoginRepository.Update(userLoginDetails);
                    }

                    if (userActivity != null)
                        _UserCurrentActivityRepository.Delete(userActivity.Id);

                    if (nonCoreActivityJourney != null)
                    {
                        nonCoreActivityJourney.EndTime = updatedEndTime;
                        nonCoreActivityJourney.Duration = Convert.ToInt64(updatedEndTime.Subtract(nonCoreActivityJourney.StartTime).TotalSeconds);
                        _NCARepository.Update(nonCoreActivityJourney);
                    }

                    UserLogs userLog = _UserService.GetUserLog(userLogId);

                    if (userLog != null)
                    {
                        userLog.LogOutTime = updatedEndTime;
                        userLog.Duration = Convert.ToInt32((Convert.ToDateTime(userLog.LogOutTime) - userLog.LoginTime).TotalSeconds);
                        _UserService.UpdateUserLog(userLog);
                    }

                    if (lstCoreActivityJourneyForUser.Count > 0)
                    {
                        bool isAnyCoreActivityEndTimeNull = lstCoreActivityJourneyForUser.Where(x => x.ActivityType == Settings.Constants.CoreActivity).Any();
                        var allActivityOtherThanCore = lstCoreActivityJourneyForUser.Where(x => x.ActivityType != Settings.Constants.CoreActivity).ToList();

                        if (isAnyCoreActivityEndTimeNull)//there is a core activity
                        {
                            var coreAct = lstCoreActivityJourneyForUser.Where(x => x.ActivityType == Settings.Constants.CoreActivity).FirstOrDefault();
                            
                            if (allActivityOtherThanCore.Count > 0)
                            {
                                foreach (var act in allActivityOtherThanCore)
                                {
                                    act.EndTime = updatedEndTime;
                                    act.Duration = Convert.ToInt64(updatedEndTime.Subtract(act.StartTime).TotalSeconds);
                                    _CARepository.Update(act);
                                }

                                coreAct.EndTime = updatedEndTime; 

                                lstCoreActivityToUpdate.Add(new CoreActivityJourney() { Id = coreAct.Id, UserId = userLoginDetails.UserId, DepartmentId = userLoginDetails.DepartmentId });
                            }
                            else
                            {
                                coreAct.EndTime = updatedEndTime;
                                coreAct.Duration = Convert.ToInt64(updatedEndTime.Subtract(coreAct.StartTime).TotalSeconds);
                            }

                            _CARepository.Update(coreAct);
                        }
                        else
                        {
                            if (allActivityOtherThanCore.Count > 0)
                            {
                                foreach (var act in allActivityOtherThanCore)
                                {
                                    act.EndTime = updatedEndTime;
                                    act.Duration = Convert.ToInt64(updatedEndTime.Subtract(act.StartTime).TotalSeconds);
                                    _CARepository.Update(act);
                                }
                            }    
                        }
                    }
                }
            }

            status = _uow.Commit();

            if(status)
            {
                foreach(var coreAct in lstCoreActivityToUpdate)
                {
                    List<spParameter> spParameters = new List<spParameter>()
                    {
                        new spParameter() { Name = "@CoreActivityId",  Value = coreAct.Id.ToString()},
                        new spParameter() { Name = "@UserId", Value = coreAct.UserId.ToString() },
                        new spParameter() { Name = "@DepartmentId", Value = coreAct.DepartmentId.ToString() }
                    };

                    _uow.GetRepository<IdValuePair>().GetSP("UpdateCoreActivityDuration", spParameters);
                }
            }
            status = _uow.Commit();

            return status;
        }

        public UserAuthorizationDetail ChangeDepartment(int departmentId, string lanId, int nonCoreActivityId)
        {
            _NavigationRepository = _uow.GetRepository<MstNavigation>();
            _MappingRoleNavigationRepository = _uow.GetRepository<MappingRoleNavigation>();
            _MappingUserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            UserPrimaryDetails userDetails = _UserService.GetUserDetailsFromLanId(lanId);
            NonCoreActivityJourney nonCoreActivityJourney = _NCARepository.GetByID(nonCoreActivityId);
            DateTime currentTime = DateTimeHelper.Now;
            if (nonCoreActivityJourney != null)
            {
                if (nonCoreActivityJourney.EndTime == null)
                {
                    nonCoreActivityJourney.EndTime = currentTime;
                    nonCoreActivityJourney.Duration = Convert.ToInt64(currentTime.Subtract(nonCoreActivityJourney.StartTime).TotalSeconds);
                    _NCARepository.Update(nonCoreActivityJourney);
                }
            }

            UserLogs userLog = _UserLogsRepository.Get().Where(x => x.UserId == userDetails.Id && x.LogOutTime == null).OrderByDescending(x=>x.Id).FirstOrDefault();

            if (userLog != null)
            {
                userLog.LogOutTime = currentTime;
                userLog.Duration = Convert.ToInt32((currentTime - userLog.LoginTime).TotalSeconds);
                _UserService.UpdateUserLog(userLog);
            }

            UserLogs userLogAdd = new UserLogs()
            {
                ActivityName = Settings.Constants.Login,
                DepartmentId = departmentId,
                UserId = userDetails.Id,
                UserName = userDetails.FirstName + " " + userDetails.LastName,
                LoginTime = DateTimeHelper.Now,
                Duration = 0,
                LogOutTime = null
            };
            _UserService.AddUserLog(userLogAdd);

            _uow.Commit();

            UserAuthorizationDetail userAuthorizationDetail = new UserAuthorizationDetail();
            userAuthorizationDetail.UserLogId= userLogAdd != null ? userLogAdd.Id : 0;
            List<int> lstRoles = _MappingUserDepartmentRepository.Get().Where(x => x.UserId == userDetails.Id && x.DepartmentId == departmentId).Select(x => x.RoleId).Distinct().ToList();
            userAuthorizationDetail.HasAdvisorRole = lstRoles.Contains(Settings.Constants.AdvisorRoleId);

            List<int> lstNavigationIds = _MappingRoleNavigationRepository.Get().Where(x => x.DepartmentId == departmentId && lstRoles.Contains(x.RoleId)).Select(x => x.NavigationId).Distinct().ToList();

            if (lstNavigationIds != null && lstNavigationIds.Count > 0)
            {
                userAuthorizationDetail.UserAccessibleUrls = _NavigationRepository.Get().Where(x => lstNavigationIds.Contains(x.Id)).Select(x => x.SourceUrl).Distinct().ToList();
            }

            return userAuthorizationDetail;
        }

        public UserInfo IsUserAuthorized(string lanId)
        {
            UserInfo userInfo = null;

            _NavigationRepository = _uow.GetRepository<MstNavigation>();
            _MappingRoleNavigationRepository = _uow.GetRepository<MappingRoleNavigation>();
            _MappingUserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            UserPrimaryDetails userDetails = _UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault();

            if (userDetails != null)
            {
                userInfo = new UserInfo() { DepartmentId = userDetails.DepartmentId, FullName = userDetails.FirstName + " " + userDetails.LastName, IsUserSessionActiveInDB = false };

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(userDetails.TimeZone);
                DateTime userTimeZoneDate = TimeZoneInfo.ConvertTimeFromUtc(DateTimeHelper.Now, userTimeZone);
                userInfo.UserTimeZoneDate.Day = userTimeZoneDate.Day;
                userInfo.UserTimeZoneDate.Month = userTimeZoneDate.Month;
                userInfo.UserTimeZoneDate.Year = userTimeZoneDate.Year;

                _DepartmentRepository = _uow.GetRepository<MstDepartment>();

                if (userDetails.DepartmentId != 0)
                {
                    userInfo.DepartmentName = _DepartmentRepository.Get().Where(x => x.Id == userDetails.DepartmentId).FirstOrDefault().Name;
                    List<int> lstRoles = _MappingUserDepartmentRepository.Get().Where(x => x.UserId == userDetails.Id && x.DepartmentId == userDetails.DepartmentId).Select(x => x.RoleId).Distinct().ToList();

                    userInfo.TeamId = userDetails.TeamId==null? 0: userDetails.TeamId;
                    userInfo.UserId = userDetails.Id;
                    userInfo.HasAdvisorRole = lstRoles.Contains(Settings.Constants.AdvisorRoleId);                       

                    List<int> lstNavigationIds = _MappingRoleNavigationRepository.Get().Where(x => x.DepartmentId == userDetails.DepartmentId && lstRoles.Contains(x.RoleId)).Select(x => x.NavigationId).Distinct().ToList();

                    if (lstNavigationIds != null && lstNavigationIds.Count > 0)
                    {
                        userInfo.UserAccessibleUrls = _NavigationRepository.Get().Where(x => lstNavigationIds.Contains(x.Id)).Select(x => x.SourceUrl).Distinct().ToList();
                    }
                }

                UserLoggedIn loggedInDetail = _UserLoginRepository.Get().Where(x => x.UserId == userDetails.Id).FirstOrDefault();

                if (loggedInDetail != null)
                {
                    userInfo.IsUserSessionActiveInDB = !loggedInDetail.LoggedOut.HasValue;
                }
                
                userInfo.HasMultipleDepartment = _MappingUserDepartmentRepository.Get().Where(x => x.UserId == userDetails.Id).Select(x=>x.DepartmentId).Distinct().ToList().Count > 1 ? true : false;
            }

            return userInfo;
        }

        public List<TimeZoneCustom> GetTimezones()
        {
            return TimeZoneInfo.GetSystemTimeZones().Select(x=> new TimeZoneCustom() { Id = x.Id, DisplayName = x.DisplayName }).ToList();
        }

        private void AddUserLoginTime(int userId, int departmentId)
        {
            UserLoggedIn user = this.GetUserLoginDetails(userId);            

            if (user != null)
            {
                user.LoggedIn = DateTimeHelper.Now;
                user.LoggedOut = null;
                user.DepartmentId = departmentId;
                this.UpdateUserLoginTime(user);
            }
            else
            {
                user = new UserLoggedIn() { LoggedIn = DateTimeHelper.Now, LoggedOut = null, UserId = userId, DepartmentId = departmentId };                
                _UserLoginRepository.Add(user);
            }
        }

        private void UpdateUserLoginTime(UserLoggedIn user)
        {            
            _UserLoginRepository.Update(user);
        }

        private UserLoggedIn GetUserLoginDetails(int userId)
        {
            UserLoggedIn user = _UserLoginRepository.FindBy(x => x.UserId == userId).FirstOrDefault();
            return user;
        }        

        private void AddNonCoreActivity(NonCoreActivityJourney nonCoreActivityJourney, int userId)
        {
            nonCoreActivityJourney.UserId = userId;
            nonCoreActivityJourney.StartTime = DateTimeHelper.Now;
            nonCoreActivityJourney.EndTime = null;
            nonCoreActivityJourney.Comment = string.Empty;
            _NCARepository.Add(nonCoreActivityJourney);
        }

        public string ExportToExcel(DataTable dataTableToExport)
        {
            

            string fileName = Guid.NewGuid().ToString() + ".xlsx";
            var filePath = System.Web.HttpContext.Current.Server.MapPath("~/FileDownload/" + fileName);

            bool exists = System.IO.Directory.Exists(System.Web.HttpContext.Current.Server.MapPath("~/FileDownload/"));

            if (!exists)
                System.IO.Directory.CreateDirectory(System.Web.HttpContext.Current.Server.MapPath("~/FileDownload/"));

            ExportToExcel OUtilities = new ExportToExcel();
            FileInfo Ofile = new FileInfo(filePath);
            if (dataTableToExport.Rows.Count > 0)
            {
                OUtilities.ExportDataTableToExcel(dataTableToExport, Ofile, "Details");
                return fileName;
            }
            else
                return null;
        }      
    }
}
