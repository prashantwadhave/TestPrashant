﻿using Capita.Core.Contracts;
using Capita.Core.Contracts.Interface;
using Capita.Core.Models;
using Capita.Core.Models.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capita.Core.Services.Services
{
    public class WebChatService : IWebChat
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private ICoreActivity _CoreService = null;

        private IGenericRepository<CoreActivityJourney> _CARepository = null;

        private IGenericRepository<NonCoreActivityJourney> _NCARepository = null;

        public WebChatService(IUser userService, IUnitOfWork uow, ICoreActivity coreService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _CoreService = coreService;
            _NCARepository = _uow.GetRepository<NonCoreActivityJourney>();
            _CARepository = _uow.GetRepository<CoreActivityJourney>();
        }

        public int AddWebChatActivity(int departmentId, string comment, int activeNonCoreActivityId, string lanId, int teamId)
        {
            int activityId = 0;
            DateTime currentTime = DateTimeHelper.Now;

            CoreActivityJourney webChatCoreActivity = new CoreActivityJourney();

            webChatCoreActivity.ActivityType = Settings.Constants.WebChat;
            webChatCoreActivity.UserId = _UserService.GetUserIdFromLanId(lanId);
            webChatCoreActivity.DepartmentId = departmentId;
            webChatCoreActivity.TeamId = teamId;
            webChatCoreActivity.StartTime = currentTime;
            webChatCoreActivity.EndTime = null;
            
            _CARepository.Add(webChatCoreActivity);

            NonCoreActivityJourney idleNonCoreActivity = _NCARepository.GetByID(Convert.ToInt32(activeNonCoreActivityId));

            if (idleNonCoreActivity != null && !idleNonCoreActivity.EndTime.HasValue)
            {
                idleNonCoreActivity.Comment = string.Empty;
                idleNonCoreActivity.EndTime = currentTime;
                idleNonCoreActivity.Duration = Convert.ToInt64(currentTime.Subtract(idleNonCoreActivity.StartTime).TotalSeconds);
                _NCARepository.Update(idleNonCoreActivity);
            }

            //// Update Current Activity
            _UserService.AddOrUpdateCurrentActivity(webChatCoreActivity.UserId, Settings.Constants.CoreActivity, 0, webChatCoreActivity.DepartmentId, Settings.Constants.WebChat,teamId);////Aux code 0 for core activity, Param1 is scheme

            if (this.CommintToDB())
                activityId = webChatCoreActivity.Id;

            return activityId;          
        }

        public int UpdateWebChatActivity(int webChatID, string comment, bool isCoreActivtyStarted, bool isCallActivtyStarted, bool isOutBoundActivtyStarted)
        {
            int nonCoreActivityId = 0;
            CoreActivityJourney weChatCoreActivity = _CARepository.GetByID(webChatID);

            if (weChatCoreActivity != null)
            {
                weChatCoreActivity.Remarks = comment;
                
                DateTime currentTime = DateTimeHelper.Now;
                weChatCoreActivity.EndTime = currentTime;
                weChatCoreActivity.Duration = Convert.ToInt64((currentTime.Subtract(weChatCoreActivity.StartTime)).TotalSeconds);

                NonCoreActivityJourney idleNonCoreActivity = new NonCoreActivityJourney() { Duration = 0, AuxCodeId = Settings.Constants.IdleActivityId, Comment = string.Empty, DepartmentId = weChatCoreActivity.DepartmentId, TeamId=weChatCoreActivity.TeamId, StartTime = currentTime, EndTime = null, UserId = weChatCoreActivity.UserId };

                if (!isCoreActivtyStarted && !isCallActivtyStarted && !isOutBoundActivtyStarted)
                {
                    ////Add idle entry 
                    _NCARepository.Add(idleNonCoreActivity);

                    ////Update current activity            
                    _UserService.AddOrUpdateCurrentActivity(weChatCoreActivity.UserId, Settings.Constants.NonCoreActivity, Settings.Constants.IdleActivityId, weChatCoreActivity.DepartmentId, string.Empty, weChatCoreActivity.TeamId);
                }
                else
                {
                    //// Update Current Activity
                    if (isCallActivtyStarted)
                    {
                        _UserService.AddOrUpdateCurrentActivity(weChatCoreActivity.UserId, Settings.Constants.CoreActivity, 0, weChatCoreActivity.DepartmentId, Settings.Constants.Call, weChatCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                                            
                    }
                    else if (isOutBoundActivtyStarted)
                    {
                        _UserService.AddOrUpdateCurrentActivity(weChatCoreActivity.UserId, Settings.Constants.CoreActivity, 0, weChatCoreActivity.DepartmentId, Settings.Constants.OutbondCall, weChatCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                                            
                    }
                    else
                    {
                        CoreActivityJourney currentCoreActivity = _CoreService.GetCurrentActivity(weChatCoreActivity.UserId, weChatCoreActivity.DepartmentId, Settings.Constants.CoreActivity);
                        string currentActivity = string.IsNullOrWhiteSpace(currentCoreActivity.Param3) == false ? currentCoreActivity.Param1 + '-' + currentCoreActivity.Param3 : currentCoreActivity.Param1;

                        if (currentCoreActivity != null)
                            _UserService.AddOrUpdateCurrentActivity(weChatCoreActivity.UserId, Settings.Constants.CoreActivity, 0, weChatCoreActivity.DepartmentId, currentActivity, weChatCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                    
                        else
                            _UserService.AddOrUpdateCurrentActivity(weChatCoreActivity.UserId, Settings.Constants.CoreActivity, 0, weChatCoreActivity.DepartmentId, string.Empty, weChatCoreActivity.TeamId);////Aux code 0 for core activity, Param1 is scheme                    
                    }
                }

                _CARepository.Update(weChatCoreActivity);
                this.CommintToDB();
                nonCoreActivityId = idleNonCoreActivity.Id;
            }

            return nonCoreActivityId;
        }

        private bool CommintToDB()
        {
            return _uow.Commit();
        }
    }
}
