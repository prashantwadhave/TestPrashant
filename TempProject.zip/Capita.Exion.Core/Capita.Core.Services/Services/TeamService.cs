﻿using Capita.Core.Contracts.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Models.DataModels;
using Capita.Core.Contracts;

namespace Capita.Core.Services.Services
{
    public class TeamService : ITeam
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IUser _UserService = null;

        private IGenericRepository<MstTeam> _TeamRepository = null;

        public TeamService(IUnitOfWork uow, IUser userService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _UserService = userService;
            _TeamRepository = _uow.GetRepository<MstTeam>();

        }
        private int GetMaxId()
        {
            return _TeamRepository.Get().Max(x => x.Id) + 1;
        }

        public bool AddTeam(MstTeam team, string createdBy)
        {
            team.Id = this.GetMaxId();
            team.IsActive = true;
            team.DepartmentId = team.DepartmentId;
            team.CreatedBy = team.ModifiedBy = Convert.ToInt32(createdBy);
            team.CreatedDate = team.ModifiedDate = DateTimeHelper.Now;
            _TeamRepository.Add(team);

            return this.CommintToDB();
        }

        public bool CheckTeamExists(string teamName, int DepartmentId)
        {
            return _TeamRepository.Get().Where(x => x.Name.ToLower().Trim() == teamName.ToLower().Trim() && x.DepartmentId == DepartmentId).Any();
        }

        public bool CheckTeamExists(MstTeam team)
        {
            return _TeamRepository.Get().Where(x => x.Name.ToLower().Trim() == team.Name.ToLower().Trim() && x.Id != team.Id && x.DepartmentId == team.DepartmentId).Any();
        }

        public bool DeleteTeamById(int id, string modifiedBy)
        {
            bool status = false;
            MstTeam existingTeam = this.GetTeamById(id);

            if (existingTeam != null)
            {
                existingTeam.IsActive = false;
                existingTeam.ModifiedBy = Convert.ToInt32(modifiedBy);
                existingTeam.ModifiedDate = DateTimeHelper.Now;

                _TeamRepository.Update(existingTeam);
                status = this.CommintToDB();
            }

            return status;
        }

        public List<MstTeam> GetAllTeamsByDepartment(int departmentId)
        {
            List<MstTeam> result = _TeamRepository.Get().Where(x => x.DepartmentId == departmentId).OrderByDescending(x => x.ModifiedBy).ToList();
            return result;
        }

        public MstTeam GetTeamById(int id)
        {
            MstTeam mstTeam = _TeamRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return mstTeam;
        }

        public bool UpdateTeam(MstTeam team, string modifiedBy)
        {
            bool status = false;
            MstTeam existingTeam = this.GetTeamById(team.Id);

            if (existingTeam != null)
            {
                existingTeam.Name = team.Name;
                existingTeam.IsActive = team.IsActive;
                existingTeam.ModifiedBy = Convert.ToInt32(modifiedBy);
                existingTeam.ModifiedDate = DateTimeHelper.Now;

                _TeamRepository.Update(existingTeam);
                status = this.CommintToDB();
            }

            return status;
        }
        private bool CommintToDB()
        {
            return _uow.Commit();
        }

        public List<MstTeam> GetAllTeamsByUserId(int userId, int departmentId)
        {
            var result = (from t in _TeamRepository.Get()
                          join m in _uow.GetRepository<MappingUserDepartment>().Get() on t.Id equals m.TeamId
                          where m.UserId == userId && m.DepartmentId==departmentId
                          select t).Distinct().ToList();
            
            return result;
        }
    }
}
