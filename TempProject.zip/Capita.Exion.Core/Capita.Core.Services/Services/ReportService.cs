﻿using Capita.Core.Contracts.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capita.Core.Models.CustomModels;
using Capita.Core.Contracts;
using Capita.Core.Models.DataModels;
using Capita.Core.Models;
using System.Data;
using System.Reflection;

namespace Capita.Core.Services.Services
{
    public class ReportService : IReports
    {
        private readonly IUnitOfWork uow = null;

        private IDataContext dataContext = null;
        private IGenericRepository<UserPrimaryDetails> UserRepository = null;
        private IUser _UserService = null;

        public ReportService(IUser userService, IUnitOfWork _uow)
        {
            uow = _uow;
            dataContext = _uow.DbContext;
            UserRepository = _uow.GetRepository<UserPrimaryDetails>();
            _UserService = userService;
        }

        public List<LoginLogoutReport> GetLoginLogoutReport(int departmentId, DateTime startDate, DateTime endDate, string lanId, int userId)
        {
            try
            {
                string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);


                List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) }

            };
                IEnumerable<LoginLogoutReport> result = uow.GetRepository<LoginLogoutReport>().GetSP("SpGetLoginLogoutReport", spParameters);
                if (result != null)
                {
                    result = result.Select(x => new LoginLogoutReport()
                    {
                        UserId = x.UserId,
                        UserName = x.UserName,
                        LoginTime = TimeZoneInfo.ConvertTimeFromUtc(x.LoginTime, userTimeZone),
                        StrLoginTime = TimeZoneInfo.ConvertTimeFromUtc(x.LoginTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                        LogoutTime = x.LogoutTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.LogoutTime), userTimeZone) : x.LogoutTime,
                        StrLogoutTime = x.LogoutTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.LogoutTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.LogoutTime.ToString(),
                        Duration = x.Duration
                    });
                }
                if (result != null && userId != 0)
                {
                    result = result.Where(x => x.UserId == userId);
                }
                if (result != null)
                {
                    return result.ToList();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<ProductivityReport> GetProductivity(int departmentId, DateTime startDate, DateTime endDate, string lanId, string user_Id,int teamId)
        {
            try
            {
                string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

                string userId = string.Empty;
                if (user_Id == null || user_Id == "")
                {
                    user_Id = "0";
                }


                List<spParameter> spParameters = new List<spParameter>()
                 {
                        new spParameter() { Name = "@EmployeeId", Value = user_Id.ToString() },
                        new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                        new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                        new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                        new spParameter() { Name = "@TeamId", Value = teamId.ToString() },
                 };
                IEnumerable<ProductivityReport> result = uow.GetRepository<ProductivityReport>().GetSP("GetProductivityReport", spParameters);
                //if (result != null)
                //{
                //    result = result.Select(x => new ProductivityReport()
                //    {
                //        AgentName = x.AgentName,
                //        Timelogged = x.Timelogged,
                //        NonCoreDuration = x.NonCoreDuration,
                //        CoreDuration = x.CoreDuration,
                //        IdleTime=x.IdleTime,
                //        Productivity = x.Productivity
                //    });
                //}

                return result.ToList();

            }
            catch (Exception)
            {
                return null;
            }
        }

        public DataSet GetTaskAverage(int departmentId, DateTime startDate, DateTime endDate, string lanId, string Scheme, int teamId)
        {
            try
            {

                string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

                List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }

            };
                IEnumerable<TaskAverageReport> result = uow.GetRepository<TaskAverageReport>().GetSP("SpGetAverageTaskReport", spParameters);
                if (result != null)
                {
                    result = result.Select(x => new TaskAverageReport()
                    {
                        Scheme = x.Scheme,
                        Task = x.Task,
                        TotalTask = x.TotalTask,
                        TotalHandlingTime = x.TotalHandlingTime,
                        AverageHandlingTime = x.AverageHandlingTime
                    });

                    if (!string.IsNullOrEmpty(Scheme))
                    {
                        result = result.Where(x => x.Scheme == Scheme);
                    }
                    else
                        Scheme = string.Empty;
                }

               
                
                

                // for Totals ---------
                List<spParameter> spParameters1 = new List<spParameter>()
                {
                new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@Scheme", Value = Scheme },
                new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
                };
                IEnumerable<TaskTotals> totals = uow.GetRepository<TaskTotals>().GetSP("SpGetAverageTaskReportTotals", spParameters1);

                if (totals != null)
                {
                    totals = totals.Select(x => new TaskTotals()
                    {
                        
                        TotalTaskCount = x.TotalTaskCount,
                        TotalHandlingTime = x.TotalHandlingTime,
                        TotalAverageHandlingTime = x.TotalAverageHandlingTime
                    });
                }

                DataSet ds = new DataSet();
                DataTable dtresult = new DataTable("EmployeeData");
                if (result!=null && result.Count()>0)
                {
                    dtresult = ToDataTable<TaskAverageReport>(result);
                    ds.Tables.Add(dtresult);
                }
                
                DataTable dttotals = new DataTable("Totals");
                if (totals != null && totals.Count() > 0)
                {
                    dttotals = ToDataTable<TaskTotals>(totals);
                    ds.Tables.Add(dttotals);
                }
                //-------------------

                return ds;

            }
            catch (Exception)
            {
                return null;
            }
        }
        // method for convert Ienumarable to datatbale
        public DataTable ToDataTable<T>(IEnumerable<T> items)
        {
            var tb = new DataTable(typeof(T).Name);

            PropertyInfo[] props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (var prop in props)
            {
                tb.Columns.Add(prop.Name, prop.PropertyType);
            }

            foreach (var item in items)
            {
                var values = new object[props.Length];
                for (var i = 0; i < props.Length; i++)
                {
                    values[i] = props[i].GetValue(item, null);
                }

                tb.Rows.Add(values);
            }

            return tb;
        }

        // get core activities for report for SBSS
        public List<CoreActivity> GetCoreActivities(int departmentId, DateTime startDate, DateTime endDate, string lanId, int skip, int pageSize, string searchValue, bool isExport,string Scheme, int userId, string ActivityType,int teamId, out int totalCount)
        {
            // List<CoreActivity> coreActivities = new List<CoreActivity>();

            string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            IQueryable<CoreActivityJourney> coredata = uow.GetRepository<CoreActivityJourney>().Get().Where(x => x.DepartmentId == departmentId && x.StartTime >= startDate && x.EndTime <= endDate && (x.TeamId==teamId || teamId==0));
            if (userId != 0)
            {
                coredata = coredata.Where(x => x.UserId == userId);
            }
            if (!string.IsNullOrEmpty(ActivityType))
            {
                coredata = coredata.Where(x => x.ActivityType == ActivityType);
            }
            if (!string.IsNullOrEmpty(Scheme))
            {
                coredata = coredata.Where(x => x.Param1 == Scheme);
            }
            totalCount = (from d in coredata
                          join u in UserRepository.Get().Where(x => x.FirstName.Contains(searchValue) || x.LastName.Contains(searchValue)) on d.UserId equals u.Id
                          select new CoreActivity()
                          {
                              AgentName = u.FirstName
                          }).Count();

            if (isExport)
            {
                skip = 0;
                pageSize = totalCount;
            }

            var data = (from d in coredata
                        join u in UserRepository.Get().Where(x => x.FirstName.Contains(searchValue) || x.LastName.Contains(searchValue)) on d.UserId equals u.Id
                        select new CoreActivity()
                        {
                            AgentName = u.FirstName,
                            LastName = u.LastName,
                            DepartmentId = d.DepartmentId,
                            StartTime = d.StartTime,// TimeZoneInfo.ConvertTimeFromUtc(d.StartTime, userTimeZone),
                            EndTime = d.EndTime,// != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(d.EndTime), userTimeZone) : d.EndTime,
                            ActivityType = d.ActivityType,
                            Duration = d.Duration.ToString(),// TimeSpan.FromSeconds(d.Duration).ToString(@"hh\:mm\:ss"),                            
                            Remarks = d.Remarks,
                            Scheme = d.Param1,// store as Scheme
                            UID = d.Param2,// store as UID
                            Task = d.Param3 // store as Task
                        }).OrderBy(x => x.StartTime).ThenBy(x => x.StartTime).Skip(skip).Take(pageSize).ToList();

            data = data.Select(d => new CoreActivity()
            {
                AgentName = d.AgentName + ' ' + d.LastName,
                ActivityType = d.ActivityType,
                DepartmentId = d.DepartmentId,
                StartTime = TimeZoneInfo.ConvertTimeFromUtc(d.StartTime, userTimeZone),
                EndTime = d.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(d.EndTime), userTimeZone) : d.EndTime,
                Duration = !string.IsNullOrEmpty(d.Duration) ? getTime(Convert.ToDouble(d.Duration)) : "00:00:00",// TimeSpan.FromSeconds(d.Duration).ToString(@"hh\:mm\:ss"),                            
                Remarks = d.Remarks,
                Scheme = d.Scheme,// store as Scheme
                UID = d.UID,// store as UID
                Task = d.Task, // store as Task
                StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(d.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                StrEndTime = d.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(d.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : d.EndTime.ToString(),
            }).ToList();


            return data.ToList();

        }

        // get core activities for report
        public List<CoreActivityReport> GetCoreActivitiesReport(int departmentId, DateTime startDate, DateTime endDate, string lanId, int skip, int pageSize, string searchValue, bool isExport,int teamId,out int totalCount)
        {
            List<CoreActivity> coreActivities = new List<CoreActivity>();

            string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            totalCount = (from d in uow.GetRepository<CoreActivityJourney>().Get().Where(x => x.DepartmentId == departmentId && x.StartTime >= startDate && x.EndTime <= endDate && (x.TeamId==teamId || teamId==0))
                          join u in UserRepository.Get().Where(x => x.FirstName.Contains(searchValue) || x.LastName.Contains(searchValue)) on d.UserId equals u.Id
                          select new CoreActivity()
                          {
                              AgentName = u.FirstName
                          }).Count();


            if (isExport)
            {
                skip = 0;
                pageSize = totalCount;
            }

            var data = (from d in uow.GetRepository<CoreActivityJourney>().Get().Where(x => x.DepartmentId == departmentId && x.StartTime >= startDate && x.EndTime <= endDate && (x.TeamId == teamId || teamId == 0))
                        join u in UserRepository.Get().Where(x => x.FirstName.Contains(searchValue) || x.LastName.Contains(searchValue)) on d.UserId equals u.Id
                        select new CoreActivityReport()
                        {
                            AgentName = u.FirstName,
                            LastName = u.LastName,
                            StartTime = d.StartTime,
                            EndTime = d.EndTime,
                            Duration = d.Duration.ToString(),
                            Activity = d.Param1,
                            Task = d.Param3,
                            Comments = d.Remarks

                        }).OrderBy(x => x.StartTime).ThenBy(x => x.StartTime).Skip(skip).Take(pageSize).ToList();

            data = data.Select(d => new CoreActivityReport()
            {
                AgentName = d.AgentName + ' ' + d.LastName,
                StartTime = TimeZoneInfo.ConvertTimeFromUtc(d.StartTime, userTimeZone),
                EndTime = d.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(d.EndTime), userTimeZone) : d.EndTime,
                Duration = !string.IsNullOrEmpty(d.Duration) ? getTime(Convert.ToDouble(d.Duration)) : "00:00:00",
                Activity = d.Activity,
                Task = d.Task,
                Comments = d.Comments,
                StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(d.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                StrEndTime = d.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(d.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : d.EndTime.ToString(),
            }).ToList();


            return data.ToList();

        }
        public string getTime(double seconds)
        {
            return TimeSpan.FromSeconds(seconds).ToString(@"hh\:mm\:ss");
        }

        public List<STTReport> GetSTTRepot(int departmentId, DateTime startDate, DateTime endDate, string lanId, int teamId)
        {
            try
            {
                string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);


                List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@TeamId", Value = teamId.ToString() }

            };
                IEnumerable<STTReport> result = uow.GetRepository<STTReport>().GetSP("SpGetSTTReport", spParameters);
                if (result != null)
                {
                    result = result.Select(x => new STTReport()
                    {
                        AgentName = x.AgentName,
                        Activity = x.Activity,
                        Task = x.Task,
                        Task_Count = x.Task_Count,
                        AHT = x.AHT,
                        STT = x.STT,
                        Color = x.Color
                    });
                }

                if (result != null)
                {
                    return result.ToList();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        public List<ActiveUsersReport> GetActiveUsers(int departmentId, DateTime startDate, DateTime endDate, string lanId)
        {
            string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) }

            };
            IEnumerable<ActiveUsersReport> result = uow.GetRepository<ActiveUsersReport>().GetSP("SpGetActiveUsrs", spParameters);
            if (result != null)
            {
                result = result.Select(x => new ActiveUsersReport()
                {
                    AgentName = x.AgentName,
                    SrNo = x.SrNo
                });
            }

            if (result == null)
            {
                return null;
            }
            else
            {
                return result.ToList();
            }

        }

        public DataSet GetAgentTaskAverage(int departmentId, DateTime startDate, DateTime endDate, string lanId, string userId, int teamId)
        {
            try
            {

                if (userId == "0" || userId == null)
                {
                    userId = string.Empty;
                }

                string timeZone = UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault().TimeZone;

                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

                List<spParameter> spParameters = new List<spParameter>()
                 {
                        new spParameter() { Name = "@EmployeeId", Value = userId.ToString() },
                        new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                        new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                        new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                        new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
                 };

                IEnumerable<AgentTaskAverageReport> result = uow.GetRepository<AgentTaskAverageReport>().GetSP("SpGetAgentWiseAverageTaskReport", spParameters);
                if (result != null)
                {
                    result = result.Select(x => new AgentTaskAverageReport()
                    {
                        AgentName = x.AgentName,
                        Scheme = x.Scheme,
                        Task = x.Task,
                        TotalTask = x.TotalTask,
                        TotalHandlingTime = x.TotalHandlingTime,
                        AverageHandlingTime = x.AverageHandlingTime
                    });
                }

                // for Totals ---------
                List<spParameter> spParameters1 = new List<spParameter>()
                {
                new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
                new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@UserId", Value = userId },
                new spParameter() { Name = "@TeamId", Value = teamId.ToString() }

                };
                IEnumerable<TaskTotals> totals = uow.GetRepository<TaskTotals>().GetSP("SpGetAgentWiseAverageTaskReportTotals", spParameters1);

                if (totals != null)
                {
                    totals = totals.Select(x => new TaskTotals()
                    {

                        TotalTaskCount = x.TotalTaskCount,
                        TotalHandlingTime = x.TotalHandlingTime,
                        TotalAverageHandlingTime = x.TotalAverageHandlingTime
                    });
                }

                DataSet ds = new DataSet();
                DataTable dtresult = new DataTable("EmployeeData");
                dtresult = ToDataTable<AgentTaskAverageReport>(result);
                ds.Tables.Add(dtresult);

                DataTable dttotals = new DataTable("Totals");
                dttotals = ToDataTable<TaskTotals>(totals);
                ds.Tables.Add(dttotals);
                //-------------------

                return ds;

            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
