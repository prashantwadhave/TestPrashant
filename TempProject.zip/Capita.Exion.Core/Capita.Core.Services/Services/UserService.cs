﻿namespace Capita.Core.Services.Services
{
    using Capita.Core.Contracts;
    using Capita.Core.Models;
    using Capita.Core.Models.CustomModels;
    using Capita.Core.Models.DataModels;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;

    public class UserService : IUser
    {
        private readonly IUnitOfWork _uow = null;

        private IDataContext _dataContext = null;

        private IAuxCode _AuxCodeCodeService = null;

        private IGenericRepository<UserPrimaryDetails> _UserRepository = null;

        private IGenericRepository<UserLoggedIn> _UserLoginRepository = null;

        private IGenericRepository<UserCurrentActivity> _UserCurrentActivityRepository = null;

        private IGenericRepository<UserLogs> _UserLogsRepository = null;

        private IGenericRepository<MappingUserDepartment> _UserDepartmentRepository = null;
        private IGenericRepository<MstDepartment> _DepartmentRepository = null;

        public UserService(IUnitOfWork uow, IAuxCode auxCodeService)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
            _AuxCodeCodeService = auxCodeService;
            _UserRepository = _uow.GetRepository<UserPrimaryDetails>();
        }

        private int GetMaxId()
        {
            return _UserRepository.Get().Max(x => x.Id) + 1;
        }

        public IEnumerable<UserPrimaryDetails> GetAllUsers()
        {
            IEnumerable<UserPrimaryDetails> lstUsers = _UserRepository.Get();
            return lstUsers;
        }

        public IEnumerable<UserPrimaryDetails> GetAllUsersByDepartmentId(int departmentId)
        {
            _UserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            IQueryable<int> queryAssignedUserList = _UserDepartmentRepository.Get().Where(x => x.DepartmentId == departmentId).Select(x => x.UserId).Distinct();
            var assignedUserList = queryAssignedUserList.ToList();

            IEnumerable<UserPrimaryDetails> lstUsers = _UserRepository.Get().Where(u => assignedUserList.Contains(u.Id)).OrderBy(u => u.FirstName).ThenBy(u => u.LastName);
            return lstUsers;
        }

        public List<UserPrimaryDetails> GetUnassignedUserList(int departmentId)
        {
            _UserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            IQueryable<int> queryAssignedUserList = _UserDepartmentRepository.Get().Where(x => x.DepartmentId == departmentId).Select(x => x.UserId).Distinct();
            var assignedUserList = queryAssignedUserList.ToList();

            List<UserPrimaryDetails> lstUsers = _UserRepository.Get().Where(u => u.DepartmentId == departmentId && !assignedUserList.Contains(u.Id)).OrderBy(u => u.FirstName).ThenBy(u => u.LastName).ToList();
            return lstUsers;
        }

        public UserPrimaryDetails GetUserById(int id)
        {
            UserPrimaryDetails user = _UserRepository.Get().Where(x => x.Id == id).FirstOrDefault();
            return user;
        }

        public int GetUserIdFromLanId(string lanId)
        {
            int userId = _UserRepository.Get().Where(x => x.LanId == lanId).Select(x => x.Id).FirstOrDefault();
            return userId;
        }

        public UserPrimaryDetails GetUserDetailsFromLanId(string lanId)
        {
            return _UserRepository.Get().Where(x => x.LanId == lanId).FirstOrDefault();
        }

        public bool AddUser(UserPrimaryDetails user, int createdByUserId)
        {
            user.Id = this.GetMaxId();
            user.CreatedBy = user.ModifiedBy = createdByUserId;
            user.ModifiedDate = user.CreatedDate = DateTimeHelper.Now;
            _UserRepository.Add(user);
            return this.CommitToDB();
        }

        public bool AddUserAndDept(UserDetails userdetails)
        {
            UserPrimaryDetails user = new UserPrimaryDetails();

            var date = DateTimeHelper.Now;

            UserPrimaryDetails existingUser = _UserRepository.Get().Where(x => x.IsActive == false && x.EmployeeId == userdetails.EmployeeId).FirstOrDefault();

            // update info for deactvivated employee if exist
            if (existingUser != null)
            {
                existingUser.FirstName = userdetails.FirstName;
                existingUser.LastName = userdetails.LastName;
                existingUser.EmployeeId = userdetails.EmployeeId;
                existingUser.EmailId = userdetails.EmailId;
                existingUser.LanId = userdetails.LanId;
                existingUser.DepartmentId = userdetails.DepartmentId;
                existingUser.TimeZone = userdetails.TimeZone;
                existingUser.IsActive = userdetails.IsActive;
                existingUser.ModifiedBy = userdetails.CreatedByUserId;
                existingUser.ModifiedDate = DateTimeHelper.Now;
                _UserRepository.Update(existingUser);

            }
            else
            {
                user.Id = this.GetMaxId();
                user.CreatedBy = user.ModifiedBy = userdetails.CreatedByUserId;
                user.ModifiedDate = user.CreatedDate = date;
                user.DepartmentId = userdetails.DepartmentId;
                user.TeamId = userdetails.TeamId;
                user.EmailId = userdetails.EmailId;
                user.EmployeeId = userdetails.EmployeeId;
                user.FirstName = userdetails.FirstName;
                user.LastName = userdetails.LastName;
                user.ManagerId = userdetails.ManagerId;
                user.TimeZone = userdetails.TimeZone;
                user.IsActive = userdetails.IsActive;
                user.LanId = userdetails.LanId;

                _UserRepository.Add(user);
            }
            return this.CommitToDB();
        }

        public bool CheckUserExists(string employeeId, string lanId)
        {
            return _UserRepository.Get().Where(x => x.EmployeeId.ToLower().Trim() == employeeId.ToLower().Trim() && x.IsActive == true).Any();
        }
        public bool CheckUserExists(UserPrimaryDetails user)
        {
            return _UserRepository.Get().Where(x => (x.EmployeeId.ToLower().Trim() == user.EmployeeId.ToLower().Trim() ||
                                                    x.LanId.ToLower().Trim() == user.LanId.ToLower().Trim()
                                               ) && x.Id != user.Id).Any();
        }

        public bool UpdateUserAndDept(UserPrimaryDetails user, int modifiedByUserId)
        {
            bool status = false;
            UserPrimaryDetails existingUser = this.GetUserById(user.Id);

            if (existingUser != null)
            {
                existingUser.FirstName = user.FirstName;
                existingUser.LastName = user.LastName;
                existingUser.EmployeeId = user.EmployeeId;
                existingUser.EmailId = user.EmailId;
                existingUser.LanId = user.LanId;
                existingUser.DepartmentId = user.DepartmentId;
                existingUser.TimeZone = user.TimeZone;
                existingUser.IsActive = user.IsActive;
                existingUser.ModifiedBy = modifiedByUserId;
                existingUser.ModifiedDate = DateTimeHelper.Now;
                _UserRepository.Update(existingUser);
                status = this.CommitToDB();
            }

            return status;
        }

        public bool DeleteUserById(int id, int modifiedByUserId)
        {
            bool status = false;
            UserPrimaryDetails existingUser = this.GetUserById(id);

            if (existingUser != null)
            {
                if (existingUser.IsActive)
                {
                    existingUser.IsActive = false;
                    existingUser.ModifiedBy = modifiedByUserId;
                    existingUser.ModifiedDate = DateTimeHelper.Now;

                    _UserRepository.Update(existingUser);
                    status = this.CommitToDB();
                }
                else
                    status = true;
            }

            return status;
        }

        public void AddOrUpdateCurrentActivity(int userId, string activity, int auxCodeId, int departmentId, string coreSubActivityName, int? teamId)
        {
            _UserCurrentActivityRepository = _uow.GetRepository<UserCurrentActivity>();
            UserCurrentActivity userActivity = _UserCurrentActivityRepository.FindBy(x => x.UserId == userId).FirstOrDefault();
            string activityName = string.Empty;

            if (userActivity != null)
            {
                if (auxCodeId == 0)//// for core activty
                    activityName = coreSubActivityName;
                else
                    activityName = _AuxCodeCodeService.GetAuxCodeById(auxCodeId).ActivityName;

                userActivity.Activity = activity;
                userActivity.TeamId = teamId;
                userActivity.SubActivity = activityName;
                userActivity.StartTime = DateTimeHelper.Now;
                userActivity.DepartmentId = departmentId;

                _UserCurrentActivityRepository.Update(userActivity);
            }
            else
            {
                activityName = _AuxCodeCodeService.GetAuxCodeById(Settings.Constants.IdleActivityId).ActivityName;
                userActivity = new UserCurrentActivity() { Activity = Settings.Constants.NonCoreActivity, StartTime = DateTimeHelper.Now, SubActivity = activityName, UserId = userId, DepartmentId = departmentId, TeamId = teamId };
                _UserCurrentActivityRepository.Add(userActivity);
            }
        }

        private bool CommitToDB()
        {
            return _uow.Commit();
        }

        public IEnumerable<UserCurrentActivity> GetCurrentActivity(int departmentId)
        {
            _UserCurrentActivityRepository = _uow.GetRepository<UserCurrentActivity>();
            return _UserCurrentActivityRepository.FindBy(x => x.DepartmentId == departmentId);
        }
        public IEnumerable<ViewCurrentActivity> GetCurrentUsersActivity(int departmentId, string lanId,int teamId)
        {
            //List<ViewCurrentActivity> oView = new List<ViewCurrentActivity>();
            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            string timeZone = _UserRepository.FindBy(x => x.LanId == lanId).FirstOrDefault().TimeZone;
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            IEnumerable<DisplayCurrentActivity> result = _uow.GetRepository<DisplayCurrentActivity>().GetSP("spDisplayCurrentActivity", spParameters);
            
            var oResult = result.Select(x => new ViewCurrentActivity()
            {
                Activity = x.Activity,
                Name = x.Name,
                SubActivity = x.SubActivity,
                Elapsed = x.Elapsed,
                Started = (x.Started.HasValue == false) ? string.Empty : (TimeZoneInfo.ConvertTimeFromUtc(x.Started.Value, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime)),
                LoggedInSince = (x.LoggedInSince.HasValue == false) ? string.Empty : (TimeZoneInfo.ConvertTimeFromUtc(x.LoggedInSince.Value, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime)),
                LoggedOutSince = (x.LoggedOutSince.HasValue == false) ? string.Empty : (TimeZoneInfo.ConvertTimeFromUtc(x.LoggedOutSince.Value, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime)),
                LoginStatus = x.LoginStatus,
                TeamName=x.TeamName
            });

            return oResult;

        }

        public IEnumerable<UserLoggedIn> GetLoggedInUserDetails(int departmentId)
        {
            _UserLoginRepository = _uow.GetRepository<UserLoggedIn>();
            return _UserLoginRepository.FindBy(x => x.DepartmentId == departmentId);
        }

        public IEnumerable<UserLogsCustom> GetUserLogs(int departmentId, DateTime startDate, DateTime endDate, string lanId)
        {
            IEnumerable<UserLogs> userLogs = null;
            IEnumerable<UserLogsCustom> userLogsCustom = null;
            _UserLogsRepository = _uow.GetRepository<UserLogs>();
            _UserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            string timeZone = _UserRepository.FindBy(x => x.LanId == lanId).FirstOrDefault().TimeZone;

            List<int> lstUsers = _UserDepartmentRepository.FindBy(x => x.DepartmentId == departmentId).Select(x => x.UserId).ToList();

            if (lstUsers.Count > 0)
            {
                TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
                startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
                endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

                userLogs = _UserLogsRepository.FindBy(x => lstUsers.Contains(x.UserId) && x.LoginTime > startDate && x.LoginTime < endDate);

                userLogsCustom = userLogs.Select(x => new UserLogsCustom()
                {
                    ActivityName = x.ActivityName,
                    LoginTime = TimeZoneInfo.ConvertTimeFromUtc(x.LoginTime, userTimeZone),
                    StrLoginTime = TimeZoneInfo.ConvertTimeFromUtc(x.LoginTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                    UserName = x.UserName,
                    LogOutTime = x.LogOutTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.LogOutTime), userTimeZone) : x.LogOutTime,
                    StrLogOutTime = x.LogOutTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.LogOutTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.LogOutTime.ToString(),
                    Duration = x.Duration
                    //EndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone) : x.EndTime,
                });
            }

            return userLogsCustom;
        }

        public void AddUserLog(UserLogs user)
        {
            _UserLogsRepository = _uow.GetRepository<UserLogs>();
            _UserLogsRepository.Add(user);
        }

        public void UpdateUserLog(UserLogs user)
        {
            _UserLogsRepository = _uow.GetRepository<UserLogs>();
            _UserLogsRepository.Update(user);
        }

        public UserLogs GetUserLog(int id)
        {
            _UserLogsRepository = _uow.GetRepository<UserLogs>();
            return _UserLogsRepository.GetByID(id);
        }

        public List<UserDeptLoggedInDetail> GetActiveSessionOfUsers(int departmentId, UserPrimaryDetails user)
        {
            string timeZone = _UserRepository.Get().Where(x => x.LanId == user.LanId).FirstOrDefault().TimeZone;
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            _UserLoginRepository = _uow.GetRepository<UserLoggedIn>();
            _DepartmentRepository = _uow.GetRepository<MstDepartment>();

            IQueryable<UserPrimaryDetails> lstUsers = _UserRepository.Get();
            IQueryable<MstDepartment> lstDepartment = _DepartmentRepository.Get();

            IQueryable<UserLoggedIn> activeSessionOfUserList = _UserLoginRepository.Get().Where(x => x.DepartmentId == departmentId && x.LoggedOut == null && x.UserId != user.Id);

            var userList = activeSessionOfUserList.Join(lstUsers,
                        x => x.UserId,
                        y => y.Id,
                        (x, y) => new
                        {
                            Id = x.Id,
                            FirstName = y.FirstName,
                            LastName = y.LastName,
                            LanId = y.LanId,
                            EmployeeId = y.EmployeeId,
                            LoggedIn = x.LoggedIn,
                            DepartmentId = x.DepartmentId
                        }).Join(lstDepartment,
                        z => z.DepartmentId,
                        d => d.Id,
                        (z, d) => new UserDeptLoggedInDetail()
                        {
                            UserLoggedInId = z.Id,
                            FirstName = z.FirstName,
                            LastName = z.LastName,
                            LanId = z.LanId,
                            EmployeeId = z.EmployeeId,
                            LoggedIn = z.LoggedIn,
                            DepartmentName = d.Name
                        }).ToList();
            var users = userList.Select(x => new UserDeptLoggedInDetail()
            {
                UserLoggedInId = x.UserLoggedInId,
                FirstName = x.FirstName,
                LastName = x.LastName,
                LanId = x.LanId,
                EmployeeId = x.EmployeeId,
                StrLoggedIn = x.LoggedIn != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.LoggedIn), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.LoggedIn.ToString(),
                DepartmentName = x.DepartmentName
            }).OrderByDescending(z => z.LoggedIn).ToList();

            return users;
        }

        public List<KeyValuePair> GetEmployeesByManagerIdAndDepartmentId(int departmentId, int managerId)
        {
            bool isManager = this.IsManager(departmentId, managerId);
            List<KeyValuePair> users = new List<KeyValuePair>();

            if (isManager)
            {
                IQueryable<KeyValuePair> lstUsers = _UserRepository.Get()
                                                                   .Where(u => u.DepartmentId == departmentId)
                                                                   .Select(u => new KeyValuePair() { Key = u.Id.ToString(), Value = u.FirstName + " " + u.LastName + " (" + u.EmployeeId + ")" })
                                                                   .OrderBy(u => u.Value);
                users = lstUsers.ToList();

                if (users.Count > 0)
                    users.Insert(0, new KeyValuePair() { Key = "0", Value = "All" });
            }

            return users;
        }

        private bool IsManager(int departmentId, int managerId)
        {
            _UserDepartmentRepository = _uow.GetRepository<MappingUserDepartment>();
            var roleIds = _UserDepartmentRepository.Get().Where(x => x.UserId == managerId && x.DepartmentId == departmentId).Select(x => x.RoleId).ToList();
            if (roleIds.Count > 0)
            {
                if (roleIds.Contains(3))
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public List<KeyValuePair> GetUsersByDepartmentId(int departmentId)
        {
            IQueryable<KeyValuePair> lstUsers = _UserRepository.Get()
                                                      .Where(u => u.DepartmentId == departmentId)
                                                      .Select(u => new KeyValuePair() { Key = u.Id.ToString(), Value = u.FirstName + " " + u.LastName + " (" + u.EmployeeId + ")" })
                                                      .OrderBy(u => u.Value);

            return lstUsers.ToList();
        }

        public DynamicDataTable GetUserDataForToday(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            DynamicDataTable dynamicDataTable = new DynamicDataTable();
            List<DynamicColumnDataTable> lstDynamicColumnDataTable = new List<DynamicColumnDataTable>();
            DataTable dtEmployees = new DataTable();

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = "0".ToString()},
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            List<UserDataForToday> result = _uow.GetRepository<UserDataForToday>().GetSP("spGetUserDataForToday", spParameters);

            if (result.Count > 0)
            {
                var columns = result.Select(x => x.ActivityName).Distinct().OrderBy(x => x).ToList();
                var empList = result.Select(x => x.EmployeeName).Distinct().OrderBy(x => x).ToList();

                if (columns.Count > 0)
                {
                    dtEmployees.Columns.Add("EmployeeName");
                    lstDynamicColumnDataTable.Add(new DynamicColumnDataTable() { data = "EmployeeName", title = "EmployeeName" });

                    foreach (var col in columns)
                    {
                        dtEmployees.Columns.Add(col);
                        lstDynamicColumnDataTable.Add(new DynamicColumnDataTable() { data = col, title = col });
                    }
                    foreach (var emp in empList)
                    {
                        DataRow drRow = dtEmployees.NewRow();

                        drRow["EmployeeName"] = emp;

                        var dataRowsForEmp = result.Where(x => x.EmployeeName == emp).ToList();

                        foreach (var row in dataRowsForEmp)
                        {
                            drRow[row.ActivityName] = getTime(row.Hours);
                        }

                        dtEmployees.Rows.Add(drRow);
                    }
                }
            }

            dynamicDataTable.DtEmployees = dtEmployees;
            dynamicDataTable.LstDynamicColumnDataTable = lstDynamicColumnDataTable;

            return dynamicDataTable;
        }
        public string getTime(double seconds)
        {
            return TimeSpan.FromSeconds(seconds).ToString(@"hh\:mm\:ss");
        }

        public IEnumerable<UserPrimaryDetails> RemoveUserFromDepartment(int userId, int updatedBy)
        {
            //List<ViewCurrentActivity> oView = new List<ViewCurrentActivity>();
            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@userId", Value = userId.ToString() },
               new spParameter() { Name = "@updatedBy", Value = updatedBy.ToString() },
            };

            return _uow.GetRepository<UserPrimaryDetails>().GetSP("SpRemoveUserFromDepartment", spParameters);
        }
    }
}
