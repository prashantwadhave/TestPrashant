﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity.Infrastructure;
using System.Linq;
using Capita.Core.Contracts;
using Capita.Core.Models;
using Capita.Core.Models.CustomModels;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services.Services
{
    public class DashboardService : IDashboard
    {
        private readonly IUnitOfWork _uow = null;
        private IDataContext _dataContext = null;

        public DashboardService(IUnitOfWork uow)
        {
            _uow = uow;
            _dataContext = uow.DbContext;
        }

        public List<RealTimeDashboard> GetRealTimeDashboard(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);


            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = userId.ToString()},
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            IEnumerable<RealTimeDashboard> result = _uow.GetRepository<RealTimeDashboard>().GetSP("spRealTimeDashboard", spParameters);

            result = result.Select(x => new RealTimeDashboard()
                            {
                                ActivityName = x.ActivityName,
                                Name = x.Name,
                                Comment = x.Comment,
                                ConsumeTime = x.ConsumeTime,
                                StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                                StrEndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.EndTime.ToString(),
                            });
            return result.ToList();
        }

        public List<RealTimeDashboard> GetRealTimeDashboardLM(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int skip, int pageSize, string searchValue,int teamId, out int totalCount)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);
            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = userId.ToString()},
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            IEnumerable<RealTimeDashboard> result = _uow.GetRepository<RealTimeDashboard>().GetSP("spRealTimeDashboard", spParameters);

            if (result != null)
            {
                result = result.Select(x => new RealTimeDashboard()
                {
                    ActivityName = x.ActivityName,
                    Name = x.Name,
                    Comment = x.Comment,
                    ConsumeTime = x.ConsumeTime,
                    StrStartTime = TimeZoneInfo.ConvertTimeFromUtc(x.StartTime, userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime),
                    StrEndTime = x.EndTime != null ? TimeZoneInfo.ConvertTimeFromUtc(Convert.ToDateTime(x.EndTime), userTimeZone).ToString(Settings.AppSetting.DisplayDateFormatWithTime) : x.EndTime.ToString(),
                });
                if (!string.IsNullOrWhiteSpace(searchValue))
                {
                    result = result.Where(x => x.Name.ToLower().Contains(searchValue.ToLower()));
                }
                totalCount = result.Count();
                return result.Skip(skip).Take(pageSize).ToList();
            }
            else
            {
                totalCount = 0;
                return null;
            }
            
        }

        public ProductiveNonProductiveHours GetProductiveNonProductive(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            ProductiveNonProductiveHours productiveNonProductiveHours = new ProductiveNonProductiveHours();

            using (IDbConnection oaConnection = _uow.DbContext.Database.Connection)
            {
                using (IDbCommand oaCommand = oaConnection.CreateCommand())
                {
                    oaCommand.CommandType = CommandType.StoredProcedure;
                    oaCommand.CommandText = "spGetProductiveNonProductiveHours";

                    IDbDataParameter UserIdDbParameter = oaCommand.CreateParameter();
                    UserIdDbParameter.ParameterName = "@UserId";
                    UserIdDbParameter.Value = userId;
                    oaCommand.Parameters.Add(UserIdDbParameter);


                    IDbDataParameter DepartmentIdDbParameter = oaCommand.CreateParameter();
                    DepartmentIdDbParameter.ParameterName = "@DepartmentId";
                    DepartmentIdDbParameter.Value = departmentId;
                    oaCommand.Parameters.Add(DepartmentIdDbParameter);

                    IDbDataParameter TeamIdDbParameter = oaCommand.CreateParameter();
                    TeamIdDbParameter.ParameterName = "@TeamId";
                    TeamIdDbParameter.Value = teamId;
                    oaCommand.Parameters.Add(TeamIdDbParameter);

                    IDbDataParameter StartDateDbParameter = oaCommand.CreateParameter();
                    StartDateDbParameter.ParameterName = "@StartDate";
                    StartDateDbParameter.Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime);
                    oaCommand.Parameters.Add(StartDateDbParameter);

                    IDbDataParameter EndDateDbParameter = oaCommand.CreateParameter();
                    EndDateDbParameter.ParameterName = "@EndDate";
                    EndDateDbParameter.Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime);
                    oaCommand.Parameters.Add(EndDateDbParameter);

                    _uow.DbContext.Database.Connection.Open();
                    using (IDataReader dataReader = oaCommand.ExecuteReader())
                    {
                        var NonProductive = ((IObjectContextAdapter)_uow.DbContext).ObjectContext.Translate<string>(dataReader as DbDataReader).FirstOrDefault();
                        dataReader.NextResult();
                        var Productive = ((IObjectContextAdapter)_uow.DbContext).ObjectContext.Translate<string>(dataReader as DbDataReader).FirstOrDefault();

                        productiveNonProductiveHours.TotalTimeProductive =Productive;
                        productiveNonProductiveHours.TotalTimeNonProductive = NonProductive;
                        productiveNonProductiveHours.Name = "Task Type";
                        //dataReader.NextResult();
                        //productiveNonProductiveTime = ((IObjectContextAdapter)dataContext).ObjectContext.Translate<ProductiveNonProductiveTime>(dataReader as DbDataReader).ToList();
                        //dataReader.NextResult();
                    }
                    _uow.DbContext.Database.Connection.Close();
                }
            }
            return productiveNonProductiveHours;
        }

        public List<CoreNonCoreTime> GetCoreNonCoreTime(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId",  Value = userId.ToString()},
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
                new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            IEnumerable<CoreNonCoreTime> result = _uow.GetRepository<CoreNonCoreTime>().GetSP("spGetCoreNonCoreTime", spParameters);

            if (result==null)
            {
                return null;
            }
            return result.ToList();
        }

        public List<EmployeesCoreNonCoreData> GetEmployeesCoreNonCoreData(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId", Value = userId.ToString() },
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };
            IEnumerable<EmployeesCoreNonCoreData> result = _uow.GetRepository<EmployeesCoreNonCoreData>().GetSP("spGetEmployeesCoreNonCoreData", spParameters);
            if (result!=null && result.Count()>0)
            {
                return result.ToList();
            }
            return null;
        }

        public List<UserCurrentStatistics> GetUserCurrentStatistic(int userId, int departmentId, string timeZone, DateTime startDate, DateTime endDate, int teamId)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.FindSystemTimeZoneById(timeZone);

            startDate = TimeZoneInfo.ConvertTimeToUtc(startDate, userTimeZone);
            endDate = TimeZoneInfo.ConvertTimeToUtc(endDate.AddDays(1), userTimeZone);

            List<UserCurrentStatistics> result = new List<UserCurrentStatistics>();

            List<spParameter> spParameters = new List<spParameter>()
            {
               new spParameter() { Name = "@UserId", Value = userId.ToString() },
               new spParameter() { Name = "@DepartmentId", Value = departmentId.ToString() },
               new spParameter() { Name = "@StartDate", Value = startDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@EndDate", Value = endDate.ToString(Settings.AppSetting.DisplayDateFormatWithTime) },
               new spParameter() { Name = "@TeamId", Value = teamId.ToString() }
            };

            var spResult =  _uow.GetRepository<UserCurrentStatistics>().GetSP("spGetUserCurrentStatistics", spParameters);

            if (spResult.Count > 1)
            {
                result = spResult.Where(x => x.ActivityType.ToLower().Trim() != "none".Trim()).OrderBy(x=> x.ActivityType).ToList();
            }

            return result;
        }
    }
}
