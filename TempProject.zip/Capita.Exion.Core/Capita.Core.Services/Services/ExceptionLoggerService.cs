﻿using System;
using System.Collections.Generic;
using Capita.Core.Contracts;
using Capita.Core.Models;
using System.Linq;
using System.Web;
using Capita.Core.Models.DataModels;

namespace Capita.Core.Services
{
    public class ExceptionLoggerService : ILogger
    {

        private readonly IUnitOfWork uow;
        private IDataContext dataContext;
        IGenericRepository<AppException> repository;
        public ExceptionLoggerService(IUnitOfWork uow)
        {
            this.uow = uow;
            this.dataContext = uow.DbContext;
            repository = uow.GetRepository<AppException>();
        }

        public IEnumerable<AppException> Get()
        {
            var result = repository.Get();
            return result;
        }
        public IEnumerable<AppException> Get(int records)
        {
            List<AppException> lstExceptionLog = repository.Get().Take(records).ToList();
            return lstExceptionLog;
        }
        public int Log(Exception entity, string uid)
        {
            HttpContext ctxObject = HttpContext.Current;
            string strReqURL = (ctxObject.Request.Url != null) ? ctxObject.Request.Url.ToString() : String.Empty;
            string strUserAgent = (ctxObject.Request.UserAgent != null) ? ctxObject.Request.UserAgent : String.Empty;
            string strUserIP = (ctxObject.Request.UserHostAddress != null) ? ctxObject.Request.UserHostAddress : String.Empty;
            AppException oApp = new AppException();
            oApp.Message = entity.Message;
            oApp.StackTrace = entity.StackTrace;
            oApp.RequestURL = strReqURL;
            oApp.UserIP = strUserIP;
            oApp.UserAgent = strUserAgent;
            oApp.UserId = (string.IsNullOrEmpty(uid)) ? ctxObject.User.Identity.Name : uid;
            oApp.Created = DateTimeHelper.Now;
            repository.Add(oApp);
            uow.Commit();
            return oApp.Id;
        }
        public int Log(string info, string uid)
        {
            AppException oApp = new AppException
            {
                Message = info,
                StackTrace = string.Empty,
                RequestURL = string.Empty,
                UserIP = string.Empty,
                UserAgent = string.Empty,
                UserId = (string.IsNullOrEmpty(uid)) ? HttpContext.Current.User.Identity.Name : uid,
                Created = DateTimeHelper.Now
            };
            repository.Add(oApp);
            uow.Commit();
            return oApp.Id;
        }
        public int Log(AppException entity)
        {
            HttpContext OHttpContext = HttpContext.Current;
            string strReqURL = (OHttpContext.Request.Url != null) ? OHttpContext.Request.Url.ToString() : String.Empty;
            string strUserAgent = (OHttpContext.Request.UserAgent != null) ? OHttpContext.Request.UserAgent : String.Empty;
            string strUserIP = (OHttpContext.Request.UserHostAddress != null) ? OHttpContext.Request.UserHostAddress : String.Empty;
            AppException oApp = new AppException()
            {
                Message = entity.Message,
                StackTrace = entity.StackTrace,
                RequestURL = entity.RequestURL,
                UserIP = strUserIP,
                UserAgent = strUserAgent,
                UserId = HttpContext.Current.User.Identity.Name,              
                Created = DateTimeHelper.Now
            };
            repository.Add(oApp);
            uow.Commit();
            return oApp.Id;
        }
    }
}
